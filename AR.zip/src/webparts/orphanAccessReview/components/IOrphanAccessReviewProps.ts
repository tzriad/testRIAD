export interface IOrphanAccessReviewProps {
  description: string;
}
