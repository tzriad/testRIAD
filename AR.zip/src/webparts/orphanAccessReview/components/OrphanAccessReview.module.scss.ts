/* tslint:disable */
require("./OrphanAccessReview.module.css");
const styles = {
  orphanAccessReview: 'orphanAccessReview_4afb6e10',
  container: 'container_4afb6e10',
  row: 'row_4afb6e10',
  column: 'column_4afb6e10',
  'ms-Grid': 'ms-Grid_4afb6e10',
  title: 'title_4afb6e10',
  subTitle: 'subTitle_4afb6e10',
  description: 'description_4afb6e10',
  button: 'button_4afb6e10',
  label: 'label_4afb6e10'
};

export default styles;
/* tslint:enable */