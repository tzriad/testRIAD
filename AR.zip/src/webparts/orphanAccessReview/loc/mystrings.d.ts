declare interface IOrphanAccessReviewWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'OrphanAccessReviewWebPartStrings' {
  const strings: IOrphanAccessReviewWebPartStrings;
  export = strings;
}
