declare interface IShareBoxReviewWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ShareBoxReviewWebPartStrings' {
  const strings: IShareBoxReviewWebPartStrings;
  export = strings;
}
