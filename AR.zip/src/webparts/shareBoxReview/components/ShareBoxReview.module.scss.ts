/* tslint:disable */
require("./ShareBoxReview.module.css");
const styles = {
  TD: 'TD_a48cee4e',
  TD2: 'TD2_a48cee4e',
  container: 'container_a48cee4e',
  TDG: 'TDG_a48cee4e',
  tg: 'tg_a48cee4e',
  paddingB: 'paddingB_a48cee4e',
  paddingL: 'paddingL_a48cee4e',
  InfoCard: 'InfoCard_a48cee4e',
  FormHeader: 'FormHeader_a48cee4e',
  Icon: 'Icon_a48cee4e',
  fullPan: 'fullPan_a48cee4e',
  button: 'button_a48cee4e',
  errorMessage: 'errorMessage_a48cee4e',
  link: 'link_a48cee4e'
};

export default styles;
/* tslint:enable */