import * as React from 'react';
import styles from './OrphanRecertification.module.scss';
import { IOrphanRecertificationProps } from './IOrphanRecertificationProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { Link, MessageBar, MessageBarType, Persona } from 'office-ui-fabric-react';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { UrlQueryParameterCollection } from '@microsoft/sp-core-library';
import { PrimaryButton } from '@microsoft/office-ui-fabric-react-bundle';
import { LivePersona } from "@pnp/spfx-controls-react/lib/LivePersona";
import { Spinner } from 'office-ui-fabric-react/lib/Spinner';
import { Checkbox} from 'office-ui-fabric-react/lib/Checkbox';

import { sp } from "@pnp/sp"; 

import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/fields";
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import * as moment from 'moment';

const ApproveIcon: IIconProps = { iconName: 'Accept' };

export interface IControls
{
  title : string;
  Members:any[];
  SelectedOwners : any[];
  OwnersCertifiedRevokeRole :any[] ,
  OwnersCertifiedMaintainRole :any[] ,
  SiteType: string;
  url : string;
  created : string;
  currentUser : number;
  CurrentUserCertified : boolean;
  ReviewRequestStatus: string;
  Target : boolean;
  DisplayWarningOrphan : boolean;
  Strategy : string;
  Max2 : boolean;
  exist : boolean;
  OwnerRoleLabel:string;
  OwnerRoleCertified : boolean
  ChooseOwnerRole:boolean;
  
}


export default class OrphanRecertification extends React.Component<IOrphanRecertificationProps, IControls> {
  
  componentWillMount() {
    this._logicLanding();
  }

  constructor(props: IOrphanRecertificationProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      title : '',
      Members:[],
      SelectedOwners : [],
      OwnersCertifiedRevokeRole :[] ,
      OwnersCertifiedMaintainRole :[] ,
      SiteType: '',
      url : '',
      created : '',
      currentUser : 0,
      ReviewRequestStatus: 'In Progress',
      CurrentUserCertified : false,
      Target : false,
      DisplayWarningOrphan : false,
      Strategy : '',
      Max2: false,
      exist : true,
      OwnerRoleLabel: "Promote me as a owner",
      OwnerRoleCertified : true,
      ChooseOwnerRole : false
    }
  }

  private async RevisionSite(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
    var tempValues = this.state.OwnersCertifiedMaintainRole;
  if(tempValues == null) {tempValues = [];}

  var tempValues2 =  this.state.OwnersCertifiedRevokeRole;
  if(tempValues2 == null) {tempValues2 = [];}

  
    if(checked) {
      this.setState({OwnerRoleCertified:true});
      this.setState({OwnerRoleLabel:"Promote me as a owner"});

      if( tempValues.indexOf(this.state.currentUser) == -1)  {tempValues.push( this.state.currentUser);}
      var index = tempValues2.indexOf(this.state.currentUser);
      if( index > -1)  {  tempValues2.splice(index,1);  }
  
   }else{
    this.setState({OwnerRoleCertified:false});
    this.setState({OwnerRoleLabel:"I refuse to be promoted as a owner"});

    if( tempValues2.indexOf(this.state.currentUser) == -1)  {tempValues2.push( this.state.currentUser);}
    var index = tempValues.indexOf(this.state.currentUser);
    if( index > -1)  {  tempValues.splice(index,1);  }
   }
  
   this.setState({OwnersCertifiedMaintainRole:tempValues});
   this.setState({OwnersCertifiedRevokeRole:tempValues2});
 

    }

  private  async _logicLanding(){

    const myprofile = await sp.profiles.myProperties.get();
    let result = await sp.web.ensureUser(myprofile.AccountName.replace("i:0#.f|membership|",""));

    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
     if(queryParameters.getValue("ReviewID")){
      var ReviewId = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);
      var WorkspaceId = queryParameters.getValue("ReviewID").split('_')[1];

      const userRequest = await sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).get();
      
      // information sur le site
      this.setState({title: userRequest["Title"]});
      this.setState({url: userRequest["SiteUrl"]});
      this.setState({SiteType: userRequest["SiteType"]});
      this.setState({created: moment(userRequest["SiteCreatedDate"]).format('DD/MM/YYYY')});
      this.setState({ReviewRequestStatus : userRequest["Status"]});
      this.setState({Strategy : userRequest["OrphanStrategy"]});


      var currentIdUser = 0;
      var ownersI :string[] = new Array() ;

      var OwnersCR :number[] = userRequest["OwnersCertifiedMaintainRoleId"];
      var OwnersRR :number[] = userRequest["OwnersCertifiedRevokeRoleId"];

      await Promise.all(userRequest["OwnersId"].map(async (element)=>{
        let user = await sp.web.getUserById(parseInt(element)).get();

        let selU = "0";
        if(OwnersCR != null)
        { if(OwnersCR.indexOf(user.Id)> -1) {selU = "1"} }
        
        ownersI.push( user.Id +";" + user.Title+ ";" + selU);

        if(myprofile.AccountName == user.LoginName)
         {
           this.setState({Target:true}); 
           this.setState({currentUser: parseInt(element)}); 
           currentIdUser = parseInt(element);
        }
       }));

       if(currentIdUser !=0)   // Request for the user
       {
        this.setState({OwnersCertifiedMaintainRole:OwnersCR});
        this.setState({OwnersCertifiedRevokeRole:OwnersRR});
        this.setState({SelectedOwners:ownersI});

        if(OwnersCR != null)
        if(OwnersCR.indexOf(currentIdUser)> -1 )
        {
          this.setState({ChooseOwnerRole:true});
          this.setState({OwnerRoleLabel :"Promote me as a owner" });
          this.setState({OwnerRoleCertified :true});
        }
        
        if(OwnersRR != null)
        if(OwnersRR.indexOf(currentIdUser)> -1 )
        {
          this.setState({ChooseOwnerRole:true});
          this.setState({OwnerRoleLabel :"I refuse to be promoted as a owner" });
          this.setState({OwnerRoleCertified :false});
        }

      
       if(ownersI.length == 1)  { 
        this.setState({DisplayWarningOrphan: true})
        this.setState({ReviewRequestStatus: 'Blocked'}) 
      }
       if(ownersI.length <= 2)  { 
        this.setState({Max2: true}) ;
        var tempValues = [];
        tempValues.push(currentIdUser);
        this.setState({OwnersCertifiedMaintainRole:tempValues});

      }
    }else{
      this.setState({exist: false});
     
    }
  }
}

private async _SavePromote(){

  var queryParameters  = new UrlQueryParameterCollection(window.location.href);
  var ReviewId  = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);
  var ReviewRequestStatus = "Closed"
  var ownersL: number = 0; if(this.state.SelectedOwners != null) ownersL = this.state.SelectedOwners.length;
  var ownersRL: number = 0; if(this.state.OwnersCertifiedRevokeRole != null) ownersRL = this.state.OwnersCertifiedRevokeRole.length;
  var ownersML: number = 0; if(this.state.OwnersCertifiedMaintainRole != null) ownersML = this.state.OwnersCertifiedMaintainRole.length;
  if(ownersL > ownersRL+ ownersML ){ReviewRequestStatus = "In Progress";}
 
  console.log(this.state.OwnersCertifiedRevokeRole);
  console.log(this.state.OwnersCertifiedMaintainRole);

  if(!this.state.OwnerRoleCertified)
  {
    var localOwn : any[] = this.state.OwnersCertifiedRevokeRole;
    if(localOwn  == null){localOwn = new Array();}
    localOwn.push(this.state.currentUser);
   sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).update({
     Status : ReviewRequestStatus,
     Synch : true,
     OwnersCertifiedRevokeRoleId : { results: localOwn }
    });
   }else{
     var localOwn : any[] = this.state.OwnersCertifiedMaintainRole;
     if(localOwn  == null){localOwn = new Array();}
     localOwn.push(this.state.currentUser);
    sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).update({
      Status : ReviewRequestStatus,
      Synch : true,
      OwnersCertifiedMaintainRoleId :  { results: localOwn } 
     });
   }

  this._logicLanding();  

}
  
private async _SavePromoteVOTE(){

  var queryParameters  = new UrlQueryParameterCollection(window.location.href);
  var ReviewId  = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);
  var ReviewRequestStatus = "Closed"
  var ownersL: number = 0; if(this.state.SelectedOwners != null) ownersL = this.state.SelectedOwners.length;
  var ownersRL: number = 0; if(this.state.OwnersCertifiedRevokeRole != null) ownersRL = this.state.OwnersCertifiedRevokeRole.length;
  var ownersML: number = 0; if(this.state.OwnersCertifiedMaintainRole != null) ownersML = this.state.OwnersCertifiedMaintainRole.length;
  if(ownersL > ownersRL+ ownersML){ReviewRequestStatus = "In Progress";}


    sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).update({
      Status : ReviewRequestStatus,
      Synch : true,
      OwnersCertifiedMaintainRoleId :  { results: this.state.OwnersCertifiedMaintainRole } 
     });

  this.setState({ChooseOwnerRole : true})  ;  
  this._logicLanding();  

}

private _onChange(ev: React.FormEvent<HTMLElement>, isChecked: boolean) {
  
  var tempValues = this.state.OwnersCertifiedMaintainRole;
  if(tempValues == null) {tempValues = [];}

  var UserSelected = ev.currentTarget.title;

 if(isChecked)
  {
    if( tempValues.indexOf(UserSelected) == -1)  {tempValues.push( UserSelected);}

  }else{
    var index = tempValues.indexOf(UserSelected);
    if( index > -1)  {  tempValues.splice(index,1);  }
  }
  
  this.setState({OwnersCertifiedMaintainRole:tempValues});
  
}

  public render(): React.ReactElement<IOrphanRecertificationProps> {
    return (
      <div>
        <div  style={{ display: ((this.state.exist) ? 'block' : 'none') }}>
        <div  style={{ display: ((this.state.Target) ? 'block' : 'none') }}>
        <div className={styles.InfoCard} >
        <header className={styles.FormHeader}><Icon iconName="CommunicationDetails"  className={styles.Icon}/>INFORMATIONS</header>
        <MessageBar messageBarType={MessageBarType.info}><a href={this.state.url}  target='_blank'>{this.state.url}</a></MessageBar> 
        <table>
        <tr>
        <td  valign='top' width="40%">
           <table>
              <tr>
                <td  valign='top'  className={styles.TD}>TITLE</td>
                <td  valign='top'  className={styles.TD2}>{this.state.title}</td>
              </tr>
              <tr>
                <td  valign='top'  className={styles.TD}>CREATED</td>
                <td  valign='top'  className={styles.TD2}>{this.state.created}</td>
              </tr>
              <tr>
                <td  valign='top'  className={styles.TD}>TYPE</td>
                <td  valign='top'  className={styles.TD2}>{this.state.SiteType}</td>
              </tr>
            </table>
        </td></tr></table>
        
        </div>
        <MessageBar messageBarType={MessageBarType.warning} isMultiline>
       This site has no owner and is considered Orphan. meaning no one can  manage membership, access and governance.
       </MessageBar>
       <br/>
      <div className= {styles.container} style={{ display: (this.state.Max2 ? 'block' : 'none') }}> 
      <header className={styles.FormHeader}><Icon iconName="UserFollowed"  className={styles.Icon}/>PROMOTE NEW OWNERS</header>
     
      <div>
        You have been temporary promoted as a owner of this {this.state.SiteType}, based on a defined strategy by your entity: <strong>{this.state.Strategy}</strong>
      </div><br/>
      <Toggle disabled={this.state.ChooseOwnerRole} inlineLabel onChange={this.RevisionSite.bind(this)} className={styles.tg}  checked={this.state.OwnerRoleCertified}/> <div>{this.state.OwnerRoleLabel}</div>
      
      <div style={{ display: (this.state.OwnerRoleCertified ? 'none' : 'block') }}>
       <br/>
       <MessageBar isMultiline messageBarType={MessageBarType.error}> If this {this.state.SiteType} still remain orphaned at the end of the recertification process, an access limitation will be applied up to and including its deletion.</MessageBar>
      </div>
      <br/>
      <div style={{ display: (this.state.DisplayWarningOrphan ? 'block' : 'none') }}>
       <MessageBar isMultiline messageBarType={MessageBarType.severeWarning}> You are the only promoted owner. it is recommended to promote at least one other, and  prevent your {this.state.SiteType} to become orphaned again.</MessageBar>
      </div>
      
      <br/><div  className={styles.fullPan} style={{ display: (this.state.ChooseOwnerRole ? 'none' : 'block') }}><DefaultButton  className={styles.button} iconProps={ApproveIcon} text="Save" onClick={this._SavePromote.bind(this)} ></DefaultButton></div> 
      <div style={{ display: (this.state.ChooseOwnerRole ? 'block' : 'none') }}>
       <br/>
       <MessageBar isMultiline messageBarType={MessageBarType.success}> Your choice has been saved..</MessageBar>
      </div>
      </div>
      <div className= {styles.container} style={{ display: (this.state.Max2 ? 'none' : 'block') }}> 
      <header className={styles.FormHeader}><Icon iconName="UserFollowed"  className={styles.Icon}/>PROMOTE NEW OWNERS</header>
      <div className={styles.bordercontainer}>
      <strong>You are a member of this orphan {this.state.SiteType}.</strong> You must choose at least 2 members from this list in order to promote them as owners.
       <br/><br/>
      {this.state.SelectedOwners.map(m =>
       <div> <Checkbox label={m.split(';')[1]} title={m.split(';')[0]} defaultChecked={Boolean(Number(m.split(';')[2]))}  onChange={this._onChange.bind(this)} /> <br/></div>
         )}
        </div>
        <div  className={styles.fullPan}  style={{ display: (this.state.ReviewRequestStatus == "Closed"  ? 'none' : 'block') }}><DefaultButton  className={styles.button} iconProps={ApproveIcon} text="Save" onClick={this._SavePromoteVOTE.bind(this)} ></DefaultButton></div> 
        <br/>
        <div style={{ display: (this.state.ReviewRequestStatus == "Closed" ? 'block' : 'none') }}><MessageBar isMultiline messageBarType={MessageBarType.success}> Thanks for the recertification. the site is not orphaned anymore.</MessageBar></div>
        <div style={{ display: (this.state.ReviewRequestStatus != "Closed" ? 'block' : 'none') }}><MessageBar isMultiline messageBarType={MessageBarType.error}> If this {this.state.SiteType} still remain orphaned at the end of the recertification process, an access limitation will be applied up to and including its deletion.</MessageBar></div>
        <div style={{ display: (this.state.ChooseOwnerRole ? 'block' : 'none') }}>
       <br/>
       <MessageBar isMultiline messageBarType={MessageBarType.success}> Your choice has been saved..</MessageBar>
      </div>
      </div>
        </div>
        <div  style={{ display: ((!this.state.Target) ? 'block' : 'none') }}>
            <Spinner label="Loading Access review request.." />
       </div>
       </div>
        <div  style={{ display: ((!this.state.exist) ? 'block' : 'none') }}>
        <MessageBar messageBarType={MessageBarType.error} isMultiline>
        The request is not found. This can be due to several reasons:<br/>
          - Wrong reference submitted.<br/>
          - Request already certified and cleaned
          
          </MessageBar>
        </div>
      </div>
    );
  }
}
