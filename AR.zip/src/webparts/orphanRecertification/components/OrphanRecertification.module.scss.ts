/* tslint:disable */
require("./OrphanRecertification.module.css");
const styles = {
  TD: 'TD_39f3c504',
  TD2: 'TD2_39f3c504',
  container: 'container_39f3c504',
  TDG: 'TDG_39f3c504',
  tg: 'tg_39f3c504',
  paddingB: 'paddingB_39f3c504',
  paddingL: 'paddingL_39f3c504',
  InfoCard: 'InfoCard_39f3c504',
  bordercontainer: 'bordercontainer_39f3c504',
  FormHeader: 'FormHeader_39f3c504',
  Icon: 'Icon_39f3c504',
  fullPan: 'fullPan_39f3c504',
  button: 'button_39f3c504',
  errorMessage: 'errorMessage_39f3c504',
  link: 'link_39f3c504'
};

export default styles;
/* tslint:enable */