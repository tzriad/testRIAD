declare interface IOrphanRecertificationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'OrphanRecertificationWebPartStrings' {
  const strings: IOrphanRecertificationWebPartStrings;
  export = strings;
}
