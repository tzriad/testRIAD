declare interface ITeamShareBoxReviewWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'TeamShareBoxReviewWebPartStrings' {
  const strings: ITeamShareBoxReviewWebPartStrings;
  export = strings;
}
