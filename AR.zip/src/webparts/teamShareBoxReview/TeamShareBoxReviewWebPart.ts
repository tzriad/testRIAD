import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'TeamShareBoxReviewWebPartStrings';
import TeamShareBoxReview from './components/TeamShareBoxReview';
import { ITeamShareBoxReviewProps } from './components/ITeamShareBoxReviewProps';

export interface ITeamShareBoxReviewWebPartProps {
  description: string;
}

export default class TeamShareBoxReviewWebPart extends BaseClientSideWebPart<ITeamShareBoxReviewWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ITeamShareBoxReviewProps> = React.createElement(
      TeamShareBoxReview,
      {
        description: this.properties.description,
        context:this.context
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
