import * as React from 'react';
import styles from './TeamShareBoxReview.module.scss';
import { ITeamShareBoxReviewProps } from './ITeamShareBoxReviewProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { Link, MessageBar, MessageBarType, Persona } from 'office-ui-fabric-react';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { PrimaryButton } from '@microsoft/office-ui-fabric-react-bundle';
import { LivePersona } from "@pnp/spfx-controls-react/lib/LivePersona";
import { Spinner } from 'office-ui-fabric-react/lib/Spinner';

import { sp } from "@pnp/sp"; 

import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/fields";
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { UrlQueryParameterCollection } from '@microsoft/sp-core-library';
import * as moment from 'moment';

const ApproveIcon: IIconProps = { iconName: 'Accept' };

export interface IControls
{
  title : string;
  ShareBOXType : string;
  owners:any[];
  members : any[];
  url : string;
  reportUrl:string;
  created : string;
  securityGroup : string;
  currentUser : number;
  MembershipCertifiedDate : Date;
  MembershipCertifiedBy : string;
  MembershipCertified : boolean;
  ShareLinksCertified : boolean;
  DisplayWarningOrphan : boolean;
  MembershipCertifiedLabel :string;
  SharedLinksCertifiedLabel:string;
  ReviewRequestStatus: string;
  Target:boolean;
  exist : boolean;
  Error : boolean;
}



export default class TeamShareBoxReview extends React.Component<ITeamShareBoxReviewProps,  IControls> {
  
   componentWillMount() {
    this._logicLanding();
  }
  
  constructor(props: ITeamShareBoxReviewProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      title : '',
      owners:[],
      members : [],
      url : '',
      reportUrl : '',
      created : '',
      securityGroup : '',
      currentUser : 0,
      MembershipCertifiedDate : null,
      MembershipCertifiedBy : '',
      MembershipCertified : false,
      ShareLinksCertified : false,
      MembershipCertifiedLabel: '',
      SharedLinksCertifiedLabel:'Shared Links not yet reviewed',
      ReviewRequestStatus:'In Progress',
      Target:false,
      DisplayWarningOrphan : false,
      exist : true,
      Error : false,
      ShareBOXType : 'Team ShareBOX'
     
    }
  }
  
  private  async _logicLanding(){
    const myprofile = await sp.profiles.myProperties.get();
    let result = await sp.web.ensureUser(myprofile.AccountName.replace("i:0#.f|membership|",""));

    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
     if(queryParameters.getValue("ReviewID")){
      var ReviewId = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);
      var WorkspaceId = queryParameters.getValue("ReviewID").split('_')[1];

      const userRequest = await sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).get();
      
      // information sur le site
      this.setState({title: userRequest["Title"]});
      this.setState({url: userRequest["SiteUrl"]});
      this.setState({reportUrl: (userRequest["SiteUrl"] + "/ShareBOX_Audit")});
      this.setState({securityGroup: userRequest["AdditionalInformation"]});
      this.setState({created: moment(userRequest["SiteCreatedDate"]).format('DD/MM/YYYY')});
      this.setState({ReviewRequestStatus : userRequest["Status"]});

      if(userRequest["SiteType"] == 'ShareBOX Ex')  {this.setState({ShareBOXType : "Team ShareBOX Ex"});}

      var currentIdUser = 0;
      var ownersI :string[] = new Array() ;
      await Promise.all(userRequest["OwnersId"].map(async (element)=>{
        let user = await sp.web.getUserById(parseInt(element)).get();
        ownersI.push( user.LoginName.replace("i:0#.f|membership|","") +";" + user.Title);
        if(myprofile.AccountName == user.LoginName)
         {
           this.setState({Target:true}); 
           this.setState({currentUser: parseInt(element)}); 
           currentIdUser = parseInt(element);
        }
       }));

       if(currentIdUser !=0)   // Request for the user
       {
        this.setState({owners: ownersI});

        if(ownersI.length == 1)  { 
          this.setState({DisplayWarningOrphan: true}) 
          this.setState({ReviewRequestStatus: 'Blocked'}) 
        }

        var membersI :string[] = new Array() ;
        await Promise.all(userRequest["MembersId"].map(async (element)=>{
          let user = await sp.web.getUserById(parseInt(element)).get();
          membersI.push( user.LoginName.replace("i:0#.f|membership|","") +";" + user.Title);
          
         }));

         this.setState({members: membersI});

         if(userRequest["MembershipCertified"] == false)
         {
           this.setState({MembershipCertified : false});
           this.setState({MembershipCertifiedLabel : "Team ShareBOX membership not yet certified"});
         }else {
           this.setState({MembershipCertified : true});
           this.setState({MembershipCertifiedLabel : "Membership certified"});
           this.setState({MembershipCertifiedDate : userRequest["MembershipCertifiedDate"]});
           let MCUser = await sp.web.getUserById(parseInt(userRequest["MembershipCertifiedById"])).get();
           this.setState({MembershipCertifiedBy : (MCUser.LoginName.replace("i:0#.f|membership|","") +";" + MCUser.Title) });
         }

       }
     }
     else{
      this.setState({exist: false});
     }

  }

  private async RevisionSite(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
    if(checked) {
     this.setState({MembershipCertified:true});
     this.setState({MembershipCertifiedLabel:"Team ShareBOX membership certified"});
   }else{
    this.setState({MembershipCertified:false});
    this.setState({MembershipCertifiedLabel:"Team ShareBOX membership not yet certified"});
   }
  
    }

    private async RevisionSharedLinks(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
      if( checked) {
       this.setState({ShareLinksCertified:true});
       this.setState({SharedLinksCertifiedLabel:"Shared Links reviewed"});
     }else{
      this.setState({ShareLinksCertified:false});
      this.setState({SharedLinksCertifiedLabel:"Shared Links not yet reviewed"});
     }
    
      }

    private async _SaveMembership(){
      if(this.state.MembershipCertified && this.state.ShareLinksCertified)
      {
      var queryParameters  = new UrlQueryParameterCollection(window.location.href);
      var ReviewId  = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);
      this.setState({Error : false});
      sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).update({
        MembershipCertifiedDate:(new Date()),
        MembershipCertified: true,
        MembershipCertifiedById:this.state.currentUser,
        Synch : true,
        Status : "Closed"
    });
  
    this._logicLanding();
    }else {
      this.setState({Error : true});
    }

    }

  public render(): React.ReactElement<ITeamShareBoxReviewProps> {
    return (
      <div>
       <div  style={{ display: ((this.state.exist) ? 'block' : 'none') }}>
        <div  style={{ display: ((this.state.Target) ? 'block' : 'none') }}>

        <div className={styles.InfoCard} >
        <header className={styles.FormHeader}><Icon iconName="CommunicationDetails"  className={styles.Icon}/>{this.state.ShareBOXType}</header>
        <MessageBar messageBarType={MessageBarType.info}><a href={this.state.url}  target='_blank'>{this.state.url}</a></MessageBar> 
        
        <table>
        <tr>
        <td  valign='top' width="40%">
           <table>
              <tr>
                <td  valign='top'  className={styles.TD}>TITLE</td>
                <td  valign='top'  className={styles.TD2}>{this.state.title}</td>
              </tr>
              <tr>
                <td  valign='top'  className={styles.TD}>CREATED</td>
                <td  valign='top'  className={styles.TD2}>{this.state.created}</td>
              </tr>
              <tr>
                <td  valign='top'  className={styles.TD}>SECURITY GROUP</td>
                <td  valign='top'  className={styles.TD2}>{this.state.securityGroup}</td>
              </tr>
            </table>
        </td>
        <td valign='top' className={styles.paddingL}>
         <div  className={styles.TD}> OWNERS </div><br/>
         {this.state.owners.map(m =>
        <span className={styles.paddingB}>
        <LivePersona upn={m.split(';')[0]}
         template={
          <>
          <Persona text={m.split(';')[1]} coinSize={35} /> 
          </>
          }
         serviceScope={this.context.serviceScope}
        />
        </span>
         )}<br/><br/>
        <br/>
       <div  className={styles.TD}> MEMBERS </div><br/>
         {this.state.members.map(m =>
        <span className={styles.paddingB}>
        <LivePersona upn={m.split(';')[0]}
         template={
          <>
          <Persona text={m.split(';')[1]} coinSize={35} /> 
          </>
          }
         serviceScope={this.context.serviceScope}
        />
        </span>
         )}
        </td></tr></table>
        
        </div>

      <div className= {styles.container} > 
      <header className={styles.FormHeader}><Icon iconName="ReminderGroup"  className={styles.Icon}/>CERTIFY TEAM MEMBERSHIP</header>
      <div style={{ display: ((this.state.MembershipCertifiedBy.length > 1) ? 'none' : 'block') }}>
       <MessageBar messageBarType={MessageBarType.warning} isMultiline>
       Your are one of the TEAM ShareBOX owners. For compliance reasons you must certify membership. A lack of certification will result in blocking any access to the ShareBOX. <br/><br/>
        <br/><div  style={{ display: (this.state.DisplayWarningOrphan ? 'none' : 'block') }}> <Icon iconName="UserSync"  className={styles.Icon}/>Manage your <strong>{this.state.securityGroup}</strong> membership  <a  className={ styles.link }  rel="noopener noreferrer" data-interception="off"  target="_blank" href="https://admin.exchange.microsoft.com/?page=groups#">here</a> </div>
       </MessageBar>
       <br/>
      <div style={{ display: (this.state.DisplayWarningOrphan ? 'block' : 'none') }}>
     <MessageBar isMultiline messageBarType={MessageBarType.error}>
      You are the only active owner. You cannot certify until promoting addtional ones, and  prevent your sharebox to become orphaned.<br/><br/>
      <Icon iconName="UserSync"  className={styles.Icon}/>Manage your <strong>{this.state.securityGroup}</strong> membership  <a  className={ styles.link }  rel="noopener noreferrer" data-interception="off"  target="_blank" href="https://admin.exchange.microsoft.com/?page=groups#">here</a>
      <br/>
      Note that once the remediation has been carried out, you will have to wait up to 1 hour before you can proceed with recertification.
     </MessageBar>
     <br/>
    
      </div>
      <Toggle disabled= {this.state.DisplayWarningOrphan }  inlineLabel onChange={this.RevisionSite.bind(this)} className={styles.tg}  checked={this.state.MembershipCertified}/> <div>{this.state.MembershipCertifiedLabel}</div>

      </div>
      <div style={{ display: ((this.state.MembershipCertifiedBy.length > 1) ? 'block' : 'none') }}>
          <span style={{paddingTop:'7px',paddingLeft:'10px',paddingRight:'10px',float:'left'}}> Certified at {moment(this.state.MembershipCertifiedDate).format('DD/MM/YYYY')} by </span>
            <LivePersona  upn={this.state.MembershipCertifiedBy.split(';')[0]} 
                          template={<><Persona text={this.state.MembershipCertifiedBy.split(';')[1]} coinSize={35} /> </> }
                          serviceScope={this.context.serviceScope}/>
      </div>
      <br/>
      </div>
      <div className= {styles.container} > 
      <header className={styles.FormHeader}><Icon iconName="Share"  className={styles.Icon}/>GUEST ACCESS & SHARING REVIEW</header>
      <div style={{ display: ((this.state.MembershipCertifiedBy.length > 1) ? 'none' : 'block') }}>
        <MessageBar messageBarType={MessageBarType.warning} isMultiline>
        To ensure data security, you must check external users access  and revoke unnecessary ones.<br/>
        You can view <a  className={ styles.link }  rel="noopener noreferrer" data-interception="off"  target="_blank" href={this.state.reportUrl}>this report</a> for shared links with external users. 
       </MessageBar>
       <br/>
       <Toggle  disabled= {this.state.DisplayWarningOrphan } inlineLabel onChange={this.RevisionSharedLinks.bind(this)} className={styles.tg}  checked={this.state.ShareLinksCertified}/> <div>{this.state.SharedLinksCertifiedLabel}</div>
      <br/>
      </div>
      <div style={{ display: ((this.state.MembershipCertifiedBy.length > 1) ? 'block' : 'none') }}>
          <span style={{paddingTop:'7px',paddingLeft:'10px',paddingRight:'10px',float:'left'}}> Certified at {moment(this.state.MembershipCertifiedDate).format('DD/MM/YYYY')} by </span>
            <LivePersona  upn={this.state.MembershipCertifiedBy.split(';')[0]} 
                          template={<><Persona text={this.state.MembershipCertifiedBy.split(';')[1]} coinSize={35} /> </> }
                          serviceScope={this.context.serviceScope}/>
      </div>
      </div>
      <table>
        <tr>
          <td className={styles.TDG}>
               <div  style={{ display: ((this.state.Error ) ? 'block' : 'none') }}>
                 <MessageBar isMultiline messageBarType={MessageBarType.error}>You must certify both sections.</MessageBar>
                </div>
          </td>
          <td className={styles.fullPan}>
          <div  style={{ display: ((this.state.ReviewRequestStatus != "In Progress") ? 'none' : 'block') }}><DefaultButton  className={styles.button} iconProps={ApproveIcon} text="Save" onClick={this._SaveMembership.bind(this)} ></DefaultButton></div> 
          </td>
        </tr>
      </table>
      <br/>

      <div  style={{ display: ((this.state.ShareBOXType == "Team ShareBOX") ? 'block' : 'none') }}> <Icon iconName="Delete"  className={styles.Icon}/>Team ShareBOX no needed anymore ? request deletion <a  className={ styles.link }  rel="noopener noreferrer" data-interception="off"  target="_blank" href="https://axa365.sharepoint.com/sites/ShareBOX/sitepages/Request-deletion-TeamShareBOX.aspx">here</a> </div>
      <div  style={{ display: ((this.state.ShareBOXType == "Team ShareBOX Ex") ? 'block' : 'none') }}> <Icon iconName="Delete"  className={styles.Icon}/>Team ShareBOX Ex no needed anymore ? Contact your local security team </div>
     
      </div>
      <div  style={{ display: ((!this.state.Target) ? 'block' : 'none') }}>
            <Spinner label="Loading Access review request.." />
       </div>
       </div>
        <div  style={{ display: ((!this.state.exist) ? 'block' : 'none') }}>
        <MessageBar messageBarType={MessageBarType.error} isMultiline>
        The request is not found. This can be due to several reasons:<br/>
          - Wrong reference submitted.<br/>
          - Request already certified and cleaned
          
          </MessageBar>
        </div>
      </div>
    );
  } 
}
