/* tslint:disable */
require("./TeamShareBoxReview.module.css");
const styles = {
  TD: 'TD_00069558',
  TD2: 'TD2_00069558',
  container: 'container_00069558',
  TDG: 'TDG_00069558',
  tg: 'tg_00069558',
  paddingB: 'paddingB_00069558',
  paddingL: 'paddingL_00069558',
  InfoCard: 'InfoCard_00069558',
  FormHeader: 'FormHeader_00069558',
  Icon: 'Icon_00069558',
  fullPan: 'fullPan_00069558',
  button: 'button_00069558',
  errorMessage: 'errorMessage_00069558',
  link: 'link_00069558'
};

export default styles;
/* tslint:enable */