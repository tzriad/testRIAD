/* tslint:disable */
require("./Recertification.module.css");
const styles = {
  TD: 'TD_5b9651e9',
  TD2: 'TD2_5b9651e9',
  container: 'container_5b9651e9',
  tg: 'tg_5b9651e9',
  paddingB: 'paddingB_5b9651e9',
  paddingL: 'paddingL_5b9651e9',
  InfoCard: 'InfoCard_5b9651e9',
  FormHeader: 'FormHeader_5b9651e9',
  Icon: 'Icon_5b9651e9',
  fullPan: 'fullPan_5b9651e9',
  button: 'button_5b9651e9',
  errorMessage: 'errorMessage_5b9651e9'
};

export default styles;
/* tslint:enable */