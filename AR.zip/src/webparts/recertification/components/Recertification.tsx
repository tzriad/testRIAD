import * as React from 'react';
import styles from './Recertification.module.scss';
import { IRecertificationProps } from './IRecertificationProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { Dialog,DialogType,DialogFooter } from 'office-ui-fabric-react/lib/Dialog'; 
import { UrlQueryParameterCollection } from '@microsoft/sp-core-library';
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { Link, MessageBar, MessageBarType, Persona } from 'office-ui-fabric-react';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { PrimaryButton } from '@microsoft/office-ui-fabric-react-bundle';
import { LivePersona } from "@pnp/spfx-controls-react/lib/LivePersona";


import { sp } from "@pnp/sp"; 

import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/fields";
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import * as moment from 'moment';

const ApproveIcon: IIconProps = { iconName: 'Accept' };

export interface IControls
{
  title: string;
  url : string;
  created : string;
  owners: any[] ; 
  currentUser : number;
  SiteType :string;
  MembershipCertified : boolean;
  OwnerRoleCertified:boolean;
  ChooseOwnerRole : boolean;
  OwnerRoleCertifiedLabel:string;
  MembershipCertifiedDate : Date;
  MembershipCertifiedBy : string;
  PublicSite : boolean;
  PublicCertified : boolean;
  RevokePublicAccess : boolean;
  PublicCertifiedDate: string;
  PublicCertifiedBy : string;
  CampaingType: string;
  Target:boolean;
  MembershipCampaign : boolean;
  PublicCampaign : boolean;
  OwnerRoleCampaign:boolean;
  MembershipCertifiedLabel:string;
  PublicCertifiedLabel: string;
  DisplayWarningOrphan:boolean;
  ReviewRequestStatus : string;
  PublicJustification:string;
  OwnersCertifiedRevokeRole :any[] ;
  OwnersCertifiedMaintainRole :any[] ;
  errorDesc:boolean;
}

export default class Recertification extends React.Component<IRecertificationProps, IControls> {
  componentWillMount() {
    this._logicLanding();
  }
  constructor(props: IRecertificationProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      title: '', 
      url:'',
      Target:false,
      created : '',
      owners: [] ,
      OwnersCertifiedRevokeRole :[] ,
      OwnersCertifiedMaintainRole :[] ,
      ChooseOwnerRole:false,
      currentUser : 0,
      SiteType :'',
      MembershipCertified : false,
      OwnerRoleCertified:true,
      MembershipCertifiedDate : null,
      MembershipCertifiedBy : '',
      PublicSite : false,
      PublicCertified : false,
      RevokePublicAccess : false,
      PublicCertifiedDate: '',
      PublicCertifiedBy : '',
      MembershipCertifiedLabel:'',
      PublicCertifiedLabel:'',
      CampaingType:'',
      MembershipCampaign : false,
      PublicCampaign : false,
      OwnerRoleCampaign:false,
      DisplayWarningOrphan : false,
      ReviewRequestStatus:'In Progress',
      PublicJustification:'',
      errorDesc:false,
      OwnerRoleCertifiedLabel:'Maintain this role'
    }
  }

  private  async _logicLanding(){
    const myprofile = await sp.profiles.myProperties.get();
    let result = await sp.web.ensureUser(myprofile.AccountName.replace("i:0#.f|membership|",""));

    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
     if(queryParameters.getValue("ReviewID")){
      var ReviewId = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);
      var WorkspaceId = queryParameters.getValue("ReviewID").split('_')[1];

      const userRequest = await sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).get();
      
      // information sur le site
      this.setState({title: userRequest["Title"]});
      this.setState({url: userRequest["SiteUrl"]});
      this.setState({SiteType: userRequest["SiteType"]});
      this.setState({CampaingType: userRequest["CampaingType"]});
      this.setState({created: moment(userRequest["SiteCreatedDate"]).format('DD/MM/YYYY')});
      this.setState({ReviewRequestStatus : userRequest["Status"]});

      var currentIdUser = 0;
      var ownersI :string[] = new Array() ;
      await Promise.all(userRequest["OwnersId"].map(async (element)=>{
        let user = await sp.web.getUserById(parseInt(element)).get();
        ownersI.push( user.LoginName.replace("i:0#.f|membership|","") +";" + user.Title);
        if(myprofile.AccountName == user.LoginName)
         {
           this.setState({Target:true}); 
           this.setState({currentUser: parseInt(element)}); 
           currentIdUser = parseInt(element);
        }
       }));

       var OwnersCR :number[] = userRequest["OwnersCertifiedMaintainRoleId"];
       var OwnersRR :number[] = userRequest["OwnersCertifiedRevokeRoleId"];

       this.setState({OwnersCertifiedMaintainRole:OwnersCR});
       this.setState({OwnersCertifiedRevokeRole:OwnersRR});

       if(OwnersCR != null)
       if(OwnersCR.indexOf(currentIdUser)> -1 )
       {
         this.setState({ChooseOwnerRole:true});
         this.setState({OwnerRoleCertifiedLabel :"Maintain this role" });
         this.setState({OwnerRoleCertified :true});
       }
       
       if(OwnersRR != null)
       if(OwnersRR.indexOf(currentIdUser)> -1 )
       {
         this.setState({ChooseOwnerRole:true});
         this.setState({OwnerRoleCertifiedLabel :"Revoke this role" });
         this.setState({OwnerRoleCertified :false});
       }

       if(ownersI.length == 1)  { this.setState({DisplayWarningOrphan: true}) }

      this.setState({PublicSite : userRequest["isPublic"]});
      this.setState({PublicCertified : userRequest["PublicCertified"]});
      this.setState({owners: ownersI});
      this.setState({CampaingType: userRequest["CampaignType"]});
     
     
      if(userRequest["MembershipCertified"] == false)
      {
        this.setState({MembershipCertified : false});
        this.setState({MembershipCertifiedLabel : "Membership not yet certified"});
      }else {
        this.setState({MembershipCertified : true});
        this.setState({MembershipCertifiedLabel : "Membership certified"});
        this.setState({MembershipCertifiedDate : userRequest["MembershipCertifiedDate"]});
        let MCUser = await sp.web.getUserById(parseInt(userRequest["MembershipCertifiedById"])).get();
        this.setState({MembershipCertifiedBy : (MCUser.LoginName.replace("i:0#.f|membership|","") +";" + MCUser.Title) });
      }

      if(userRequest["RevokePublicAccess"] == false)
      { this.setState({PublicCertifiedLabel:"Maintain Public access"});}
      else{this.setState({PublicCertifiedLabel:"Revoke Public access"});}

      this.setState({PublicCertified : userRequest["PublicCertified"]});
      if(userRequest["PublicCertified"] == true)
      {
        this.setState({PublicCertifiedDate : userRequest["PublicCertifiedDate"]});
        this.setState({RevokePublicAccess : userRequest["RevokePublicAccess"]});
        let MCUser = await sp.web.getUserById(parseInt(userRequest["PublicCertifiedById"])).get();
        this.setState({PublicCertifiedBy : (MCUser.LoginName.replace("i:0#.f|membership|","") +";" + MCUser.Title) });
      }

    

      var CampaignTypeInfo :string[] = new Array() ;
      CampaignTypeInfo = userRequest["CampaignType"];
      if(CampaignTypeInfo.indexOf("Membership") > -1){ this.setState({MembershipCampaign : true});}
      if(CampaignTypeInfo.indexOf("Public site") > -1){ this.setState({PublicCampaign : true});}
      if(CampaignTypeInfo.indexOf("Owner role") > -1){ this.setState({OwnerRoleCampaign : true});}

    }
   }

  private async RevisionOwnerRole (ev: React.MouseEvent<HTMLElement>, checked: boolean) {
    if( checked) {
     this.setState({OwnerRoleCertified:true});
     this.setState({OwnerRoleCertifiedLabel:"Maintain this role"});
   }else{
    this.setState({OwnerRoleCertified:false});
    this.setState({OwnerRoleCertifiedLabel:"Revoke this role"});
   }
 }
  private async RevisionSite(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
  if( checked) {
   this.setState({MembershipCertified:true});
   this.setState({MembershipCertifiedLabel:"Membership certified"});
 }else{
  this.setState({MembershipCertified:false});
  this.setState({MembershipCertifiedLabel:"Membership not yet certified"});
 }

  }

  private async RevisionPublicSite(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
    this.setState({PublicCertified:true});
    if( checked) {
   this.setState({PublicCertifiedLabel:"Maintain Public access"});
   this.setState({RevokePublicAccess:false});
 }else{
  this.setState({PublicCertifiedLabel:"Revoke Public acess"});
  this.setState({RevokePublicAccess:true});
 }

  }

  private async _SaveMembership(){
    if(this.state.MembershipCertified)
    {
    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
    var ReviewId  = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);
    var ReviewRequestStatus = "Closed"
    var ownersL: number = 0; if(this.state.owners != null) ownersL = this.state.owners.length;
    var ownersRL: number = 0; if(this.state.OwnersCertifiedRevokeRole != null) ownersRL = this.state.OwnersCertifiedRevokeRole.length;
    var ownersML: number = 0; if(this.state.OwnersCertifiedMaintainRole != null) ownersML = this.state.OwnersCertifiedMaintainRole.length;

    if(ownersL > ownersRL+ ownersML){ReviewRequestStatus = "In Progress";}
    if(!this.state.MembershipCertified) {ReviewRequestStatus = "In Progress";}
    if(this.state.PublicSite){
       if(!this.state.PublicCertified) {ReviewRequestStatus = "In Progress";}
    }
   
    sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).update({
      MembershipCertifiedDate:(new Date()),
      MembershipCertified: true,
      MembershipCertifiedById:this.state.currentUser,
      Synch : true,
      Status : ReviewRequestStatus
  });
    }
    this._logicLanding();
  }

  private async _SavePublic(){
    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
    var ReviewId  = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);

    var ReviewRequestStatus = "Closed"
    var stop = false;
    var justify = "";
    var ownersL: number = 0; if(this.state.owners != null) ownersL = this.state.owners.length;
    var ownersRL: number = 0; if(this.state.OwnersCertifiedRevokeRole != null) ownersRL = this.state.OwnersCertifiedRevokeRole.length;
    var ownersML: number = 0; if(this.state.OwnersCertifiedMaintainRole != null) ownersML = this.state.OwnersCertifiedMaintainRole.length;

    if(ownersL > ownersRL+ ownersML){ReviewRequestStatus = "In Progress";}
    if(!this.state.MembershipCertified) {ReviewRequestStatus = "In Progress";}
    if(this.state.PublicSite){
      if(!this.state.PublicCertified) {ReviewRequestStatus = "In Progress";}
      if(!this.state.RevokePublicAccess)
       {
        justify = this.state.PublicJustification.trim();
        if(this.state.PublicJustification.trim().length == 0){ this.setState({errorDesc:true}); stop = true }
       }
      }

  if(!stop)
  {
   sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).update({
      PublicCertifiedDate:(new Date()),
      PublicCertified: true,
      PublicCertifiedById:this.state.currentUser,
      RevokePublicAccess : this.state.RevokePublicAccess,
      Status : ReviewRequestStatus,
      Synch : true,
      PublicJustification : justify
    });

    this._logicLanding();
  }
  }

  private async _SaveOwnerRole(){
    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
    var ReviewId  = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);
    var ReviewRequestStatus = "Closed"

    var ownersL: number = 0; if(this.state.owners != null) ownersL = this.state.owners.length;
    var ownersRL: number = 0; if(this.state.OwnersCertifiedRevokeRole != null) ownersRL = this.state.OwnersCertifiedRevokeRole.length;
    var ownersML: number = 0; if(this.state.OwnersCertifiedMaintainRole != null) ownersML = this.state.OwnersCertifiedMaintainRole.length;

    if(ownersL > ownersRL+ ownersML){ReviewRequestStatus = "In Progress";}
    if(!this.state.MembershipCertified) {ReviewRequestStatus = "In Progress";}
    if(this.state.PublicSite){
       if(!this.state.PublicCertified) {ReviewRequestStatus = "In Progress";}
    }

   if(this.state.OwnerRoleCertifiedLabel == 'Revoke this role')
   {
     var localOwn : any[] = this.state.OwnersCertifiedRevokeRole;
     if(localOwn  == null){localOwn = new Array();}
     localOwn.push(this.state.currentUser);
    sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).update({
      Status : ReviewRequestStatus,
      Synch : true,
      OwnersCertifiedRevokeRoleId : { results: localOwn }
     });
    }else{
      var localOwn : any[] = this.state.OwnersCertifiedMaintainRole;
      if(localOwn  == null){localOwn = new Array();}
      localOwn.push(this.state.currentUser);
     sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).update({
       Status : ReviewRequestStatus,
       Synch : true,
       OwnersCertifiedMaintainRoleId :  { results: localOwn } 
      });
    }



  this._logicLanding();  
  }


  private _JustificationContentchange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
    if(newValue.length > 0)
    {this.setState({PublicJustification: newValue})}
  }

  public render(): React.ReactElement<IRecertificationProps> {
    return (
      <div>
        <div  style={{ display: ((this.state.Target && this.state.ReviewRequestStatus != "Expired") ? 'block' : 'none') }}>
        <div className={styles.InfoCard} >
        <header className={styles.FormHeader}><Icon iconName="CommunicationDetails"  className={styles.Icon}/>INFORMATIONS</header>
        <MessageBar messageBarType={MessageBarType.info}><a href={this.state.url}  target='_blank'>{this.state.url}</a></MessageBar> 
        <table>
        <tr>
        <td  valign='top' width="40%">
           <table>
              <tr>
                <td  valign='top'  className={styles.TD}>Title</td>
                <td  valign='top'  className={styles.TD2}>{this.state.title}</td>
              </tr>
              <tr>
                <td  valign='top'  className={styles.TD}>Created</td>
                <td  valign='top'  className={styles.TD2}>{this.state.created}</td>
              </tr>
              <tr>
                <td  valign='top'  className={styles.TD}>Type</td>
                <td  valign='top'  className={styles.TD2}>{this.state.SiteType}</td>
              </tr>
            </table>
        </td>
        <td valign='top' className={styles.paddingL}>
         <span  className={styles.TD}> Owners </span><br/><br/>
         {this.state.owners.map(m =>
        <span className={styles.paddingB}>
        <LivePersona upn={m.split(';')[0]}
         template={
          <>
          <Persona text={m.split(';')[1]} coinSize={35} /> 
          </>
          }
         serviceScope={this.context.serviceScope}
        />
        </span>
         )}
        </td></tr></table>
        </div>

      <div className= {styles.container}  style={{ display: (this.state.OwnerRoleCampaign ? 'block' : 'none') }}>
        <header className={styles.FormHeader}><Icon iconName="LocalAdmin"  className={styles.Icon}/>CERTIFY MY OWNER ROLE</header>
        <div style={{ display: ((this.state.ChooseOwnerRole) ? 'none' : 'block') }}>
        <MessageBar messageBarType={MessageBarType.warning} isMultiline>
       Your are one of the {this.state.SiteType} owners. For compliance reasons you must certify you still use this role.<br/>
       Without any answer from your side, you role will be revoked from this {this.state.SiteType}.
       </MessageBar>
        <br/>
        <Toggle  inlineLabel onChange={this.RevisionOwnerRole.bind(this)} className={styles.tg}  checked={this.state.OwnerRoleCertified}/> <div>{this.state.OwnerRoleCertifiedLabel}</div>
        <div  className={styles.fullPan} style={{ display: ((this.state.ReviewRequestStatus != "In Progress") ? 'none' : 'block') }}><DefaultButton  className={styles.button} iconProps={ApproveIcon} text="Save" onClick={this._SaveOwnerRole.bind(this)} ></DefaultButton></div> 
        </div>
        <div style={{ display: ((this.state.ChooseOwnerRole) ? 'block' : 'none') }}>
        <span style={{paddingTop:'7px',paddingLeft:'10px',paddingRight:'10px',float:'left'}}> Your already certified to {this.state.OwnerRoleCertifiedLabel.toLowerCase()}. </span><br/>
        </div>
        <br/>
      </div>

    <div style={{display : (this.state.OwnerRoleCampaign && this.state.OwnerRoleCertifiedLabel == 'Revoke this role' ? 'none':'block')}}>
      <div className= {styles.container}  style={{ display: (this.state.MembershipCampaign ? 'block' : 'none') }}>
      <header className={styles.FormHeader}><Icon iconName="ReminderGroup"  className={styles.Icon}/>CERTIFY MEMBERSHIP</header>
      <div style={{ display: ((this.state.MembershipCertifiedBy.length > 1) ? 'none' : 'block') }}>
       <MessageBar messageBarType={MessageBarType.warning} isMultiline>
       Your are one of the {this.state.SiteType} owners. For compliance reasons you must certify membership of your {this.state.SiteType}.<br/>
       A lack of certification will result in restricting and/or blocking access to your {this.state.SiteType}.
       </MessageBar>
        <br/>
        <Toggle  inlineLabel onChange={this.RevisionSite.bind(this)} className={styles.tg}  checked={this.state.MembershipCertified}/> <div>{this.state.MembershipCertifiedLabel}</div>
        <div  className={styles.fullPan}    style={{ display: ((this.state.ReviewRequestStatus != "In Progress") ? 'none' : 'block') }}><DefaultButton  className={styles.button} iconProps={ApproveIcon} text="Save" onClick={this._SaveMembership.bind(this)} ></DefaultButton></div> 
        </div>
         <div style={{ display: (( this.state.MembershipCertifiedBy.length > 1) ? 'block' : 'none') }}>
          <span style={{paddingTop:'7px',paddingLeft:'10px',paddingRight:'10px',float:'left'}}> Certified at {moment(this.state.MembershipCertifiedDate).format('DD/MM/YYYY')} by </span>
            <LivePersona  upn={this.state.MembershipCertifiedBy.split(';')[0]} 
                          template={<><Persona text={this.state.MembershipCertifiedBy.split(';')[1]} coinSize={35} /> </> }
                          serviceScope={this.context.serviceScope}/>
         </div>
         <br/>
       </div>

       <div className= {styles.container} style={{ display: ((this.state.PublicCampaign && this.state.PublicSite)? 'block' : 'none') }}>
        <header className={styles.FormHeader}><Icon iconName="BlockedSite"  className={styles.Icon}/>CERTIFY PRIVACY</header>
        <div style={{ display: ((this.state.PublicCertifiedBy.length > 1) ? 'none' : 'block') }}>
       <MessageBar messageBarType={MessageBarType.warning} isMultiline>
       Your are one of the {this.state.SiteType} owners. For compliance reasons you must certify if your {this.state.SiteType} still need to be public.<br/>
       A lack of certification will result in revoking public access.
       </MessageBar>
      
        <br/>
        <Toggle  inlineLabel onChange={this.RevisionPublicSite.bind(this)} className={styles.tg}  checked={!this.state.RevokePublicAccess}/> <div>{this.state.PublicCertifiedLabel}</div>
        <br/>
         <div style={{ display: ((!this.state.RevokePublicAccess)? 'block' : 'none'), width:'500px',padding:'20px'}}>
          <TextField required underlined multiline placeholder='Justification'  onChange={this._JustificationContentchange.bind(this)} />
          <div className={styles.errorMessage} style={{ display: (this.state.errorDesc ? 'block' : 'none') }}>REQUIRED</div>
          </div>
        <br/><div  className={styles.fullPan}   style={{ display: ((this.state.ReviewRequestStatus != "In Progress") ? 'none' : 'block') }}><DefaultButton  className={styles.button} iconProps={ApproveIcon} text="Save" onClick={this._SavePublic.bind(this)} ></DefaultButton></div> 
        <br/>
        </div>
        <div style={{ display: ((this.state.PublicCertifiedBy.length > 1) ? 'block' : 'none') }}>
          <span style={{paddingTop:'7px',paddingLeft:'10px',paddingRight:'10px',float:'left'}}> Certified at {moment(this.state.PublicCertifiedDate).format('DD/MM/YYYY')} to {this.state.PublicCertifiedLabel.toLowerCase()} by </span>
            <LivePersona  upn={this.state.PublicCertifiedBy.split(';')[0]} 
                          template={<><Persona text={this.state.PublicCertifiedBy.split(';')[1]} coinSize={35} /> </> }
                          serviceScope={this.context.serviceScope}/>
         </div>
       </div>
       </div>
     <div style={{ display: (this.state.DisplayWarningOrphan ? 'block' : 'none') }}>
     <MessageBar isMultiline messageBarType={MessageBarType.severeWarning}>
      You are the only active owner. It is strongly recommended to promote other owners in order to simplify the administration and to prevent it from becoming potentially orphaned.
     </MessageBar>
      </div>
        </div>
        <div  style={{ display: ((!this.state.Target && this.state.ReviewRequestStatus != "Expired") ? 'block' : 'none') }}>
          <MessageBar messageBarType={MessageBarType.error}>
            This site has already been certified by a site owner. No futher action is required. For more information or queries, please contact your local M365 Access Review Campaign Manager.
          </MessageBar>
        </div>
        <div  style={{ display: (this.state.ReviewRequestStatus == "Expired" ? 'block' : 'none') }}>
          <MessageBar messageBarType={MessageBarType.error}>
            The access review has expired.
          </MessageBar>
        </div>
        <div  style={{ display: (this.state.ReviewRequestStatus == "Closed" ? 'block' : 'none') }}>
          <MessageBar messageBarType={MessageBarType.info}>
            This access review is already archived. You cannot certify anymore this request.
          </MessageBar>
        </div>
      </div>
    );
  }
}
