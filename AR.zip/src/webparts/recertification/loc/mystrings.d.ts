declare interface IRecertificationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'RecertificationWebPartStrings' {
  const strings: IRecertificationWebPartStrings;
  export = strings;
}
