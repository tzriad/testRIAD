import { WebPartContext } from '@microsoft/sp-webpart-base';  
export interface IDeletionRequestProps {
  description: string;
  context: WebPartContext; 
}
