/* tslint:disable */
require("./DeletionRequest.module.css");
const styles = {
  container: 'container_3f0235f4',
  button1: 'button1_3f0235f4',
  button: 'button_3f0235f4',
  ConfirmMessage: 'ConfirmMessage_3f0235f4',
  BtnContainer: 'BtnContainer_3f0235f4'
};

export default styles;
/* tslint:enable */