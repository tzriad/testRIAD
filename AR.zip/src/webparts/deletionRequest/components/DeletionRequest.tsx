import * as React from 'react';
import styles from './DeletionRequest.module.scss';
import { IDeletionRequestProps } from './IDeletionRequestProps';
import { UrlQueryParameterCollection } from '@microsoft/sp-core-library';
import { escape } from '@microsoft/sp-lodash-subset';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { Link, MessageBar, MessageBarType, Persona } from 'office-ui-fabric-react';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';


import { sp } from "@pnp/sp"; 

import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/fields";
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from '@pnp/sp/lists';

const ConfirmIcon: IIconProps = { iconName: 'Accept' };
const CancelIcon: IIconProps = { iconName: 'Cancel' };

export interface IControls
{
  title: string;
  url : string;
  owners: any[] ; 
  currentUser : number;
  Target:boolean;
  SiteType :string;
  AlreadyRequested:boolean;
  ReviewID : string;
  ConfirmDeletion : boolean;
  display : boolean;
 }

export default class DeletionRequest extends React.Component<IDeletionRequestProps, IControls> {

  constructor(props: IDeletionRequestProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      title: '', 
      url:'',
      owners: [] ,
      Target:false,
      currentUser:0,
      SiteType :'',
      AlreadyRequested:false,
      ReviewID : '',
      ConfirmDeletion: false,
      display:false
    }
  }

  componentWillMount() { 
    this._logicLanding(); 
  }
  private  async _logicLanding(){
    const myprofile = await sp.profiles.myProperties.get();
    let result = await sp.web.ensureUser(myprofile.AccountName.replace("i:0#.f|membership|",""));
    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
     if(queryParameters.getValue("ReviewID")){
      var ReviewId = parseInt(queryParameters.getValue("ReviewID").split('_')[0]);
      this.setState({ReviewID : queryParameters.getValue("ReviewID")});

      const r: ICamlQuery = {  ViewXml: "<View>><Query><Where><Eq><FieldRef Name='ReviewID'/> <Value Type='Text'>" + queryParameters.getValue("ReviewID") + "</Value></Eq></Where></Query></View>"  };
      let reqst : any[] = await sp.web.lists.getByTitle("DeletionREQUEST").getItemsByCAMLQuery(r); 
 
      if(reqst.length > 0)  { 
        this.setState({AlreadyRequested:true});
        return;
      }
 

      const userRequest = await sp.web.lists.getByTitle("Site_AccessReview").items.getById(ReviewId).get();
      
      // information sur le site
      this.setState({title: userRequest["Title"]});
      this.setState({url: userRequest["SiteUrl"]});
      this.setState({SiteType: userRequest["SiteType"]});
      this.setState({owners: userRequest["OwnersId"]});

      var currentIdUser = 0;
      var ownersI :string[] = new Array() ;
      await Promise.all(userRequest["OwnersId"].map(async (element)=>{
        let user = await sp.web.getUserById(parseInt(element)).get();
        ownersI.push( user.LoginName.replace("i:0#.f|membership|","") +";" + user.Title);
        if(myprofile.AccountName == user.LoginName)
         {
           this.setState({Target:true}); 
           this.setState({currentUser: parseInt(element)}); 
           currentIdUser = parseInt(element);
        }
       }));

     }
   this.setState({display:true});
    }

   private async _Confirm(){
    sp.web.lists.getByTitle("DeletionREQUEST").items.add({
      Title:this.state.title,
      SiteType: this.state.SiteType,
      Url : this.state.url,
      ReviewID : this.state.ReviewID,
      OwnersId: { results: this.state.owners } 
  });
 this.setState({ConfirmDeletion : true});
   }

   private async _Cancel(){
    window.location.href = this.props.context.pageContext.web.absoluteUrl;
  }

  public render(): React.ReactElement<IDeletionRequestProps> {
    return (
      <div style={{ display: (this.state.display  ? 'block' : 'none') }}>
        <div  style={{ textAlign: "center", paddingBottom:"20px" }}><img src={this.props.context.pageContext.web.absoluteUrl + "/siteAssets/DeletionRequestPic.png"} /></div>
           <div  style={{ display: (this.state.AlreadyRequested  ? 'block' : 'none') }}>
           <MessageBar messageBarType={MessageBarType.error}>
            You already raised this request.
          </MessageBar>
           </div>
           <div  style={{ display: (!this.state.AlreadyRequested && !this.state.Target ? 'block' : 'none') }}>
           <MessageBar messageBarType={MessageBarType.error}>
            You are not allowed to raise this request.
          </MessageBar>
           </div>
           <div  style={{ display: (this.state.ConfirmDeletion ? 'block' : 'none') }}>
           <MessageBar messageBarType={MessageBarType.success}>
           Your deletion request is recorded and will be processed as soon as possible
          </MessageBar>
           </div>
           <div  style={{ display: (!this.state.AlreadyRequested && this.state.Target && !this.state.ConfirmDeletion  ? 'block' : 'none') }}>
           <div className= {styles.container}>
           <MessageBar messageBarType={MessageBarType.warning} isMultiline>
           You have requested the deletion of this {this.state.SiteType} : <a target='_blank' rel='' href={this.state.url}>{this.state.title}</a>.
       </MessageBar>
        <br/>
        <div  style={{ textAlign: "center", paddingBottom:"10px" }}><img width="100" src={this.props.context.pageContext.web.absoluteUrl + "/siteAssets/DeletionRequestIcon.png"} /></div>
        <div className={styles.ConfirmMessage} >Are you sure you want to confirm this deletion ?</div><br/>
       <div   className={styles.BtnContainer}>
      <DefaultButton  className={styles.button1} iconProps={ConfirmIcon} text="Confirm deletion" onClick={this._Confirm.bind(this)} ></DefaultButton>
       <DefaultButton  className={styles.button} iconProps={CancelIcon} text="Cancel" onClick={this._Cancel.bind(this)} ></DefaultButton>
       </div><br/>
       <MessageBar messageBarType={MessageBarType.info}>
        After deletion, the {this.state.SiteType} will be retained for 93 days. Period during which you can request its restoration by contacting your local support team.
       </MessageBar>
           </div>
           </div>
      </div>
    );
  }
}
