declare interface IDeletionRequestWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DeletionRequestWebPartStrings' {
  const strings: IDeletionRequestWebPartStrings;
  export = strings;
}
