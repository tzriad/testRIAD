import * as React from 'react';
import { IOrphanAccessReviewProps } from './IOrphanAccessReviewProps';
export default class OrphanAccessReview extends React.Component<IOrphanAccessReviewProps, {}> {
    render(): React.ReactElement<IOrphanAccessReviewProps>;
}
//# sourceMappingURL=OrphanAccessReview.d.ts.map