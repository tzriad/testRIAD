export interface IOrphanAccessReviewProps {
    description: string;
}
//# sourceMappingURL=IOrphanAccessReviewProps.d.ts.map