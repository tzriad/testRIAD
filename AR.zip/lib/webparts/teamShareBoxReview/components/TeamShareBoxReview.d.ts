import * as React from 'react';
import { ITeamShareBoxReviewProps } from './ITeamShareBoxReviewProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    ShareBOXType: string;
    owners: any[];
    members: any[];
    url: string;
    reportUrl: string;
    created: string;
    securityGroup: string;
    currentUser: number;
    MembershipCertifiedDate: Date;
    MembershipCertifiedBy: string;
    MembershipCertified: boolean;
    ShareLinksCertified: boolean;
    DisplayWarningOrphan: boolean;
    MembershipCertifiedLabel: string;
    SharedLinksCertifiedLabel: string;
    ReviewRequestStatus: string;
    Target: boolean;
    exist: boolean;
    Error: boolean;
}
export default class TeamShareBoxReview extends React.Component<ITeamShareBoxReviewProps, IControls> {
    componentWillMount(): void;
    constructor(props: ITeamShareBoxReviewProps);
    private _logicLanding;
    private RevisionSite;
    private RevisionSharedLinks;
    private _SaveMembership;
    render(): React.ReactElement<ITeamShareBoxReviewProps>;
}
//# sourceMappingURL=TeamShareBoxReview.d.ts.map