import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface ITeamShareBoxReviewProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=ITeamShareBoxReviewProps.d.ts.map