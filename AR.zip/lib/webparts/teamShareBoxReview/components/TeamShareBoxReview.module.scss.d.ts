declare const styles: {
    TD: string;
    TD2: string;
    container: string;
    TDG: string;
    tg: string;
    paddingB: string;
    paddingL: string;
    InfoCard: string;
    FormHeader: string;
    Icon: string;
    fullPan: string;
    button: string;
    errorMessage: string;
    link: string;
};
export default styles;
//# sourceMappingURL=TeamShareBoxReview.module.scss.d.ts.map