declare const styles: {
    TD: string;
    TD2: string;
    container: string;
    tg: string;
    paddingB: string;
    paddingL: string;
    InfoCard: string;
    FormHeader: string;
    Icon: string;
    fullPan: string;
    button: string;
    errorMessage: string;
};
export default styles;
//# sourceMappingURL=Recertification.module.scss.d.ts.map