import * as React from 'react';
import { IRecertificationProps } from './IRecertificationProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    url: string;
    created: string;
    owners: any[];
    currentUser: number;
    SiteType: string;
    MembershipCertified: boolean;
    OwnerRoleCertified: boolean;
    ChooseOwnerRole: boolean;
    OwnerRoleCertifiedLabel: string;
    MembershipCertifiedDate: Date;
    MembershipCertifiedBy: string;
    PublicSite: boolean;
    PublicCertified: boolean;
    RevokePublicAccess: boolean;
    PublicCertifiedDate: string;
    PublicCertifiedBy: string;
    CampaingType: string;
    Target: boolean;
    MembershipCampaign: boolean;
    PublicCampaign: boolean;
    OwnerRoleCampaign: boolean;
    MembershipCertifiedLabel: string;
    PublicCertifiedLabel: string;
    DisplayWarningOrphan: boolean;
    ReviewRequestStatus: string;
    PublicJustification: string;
    OwnersCertifiedRevokeRole: any[];
    OwnersCertifiedMaintainRole: any[];
    errorDesc: boolean;
}
export default class Recertification extends React.Component<IRecertificationProps, IControls> {
    componentWillMount(): void;
    constructor(props: IRecertificationProps);
    private _logicLanding;
    private RevisionOwnerRole;
    private RevisionSite;
    private RevisionPublicSite;
    private _SaveMembership;
    private _SavePublic;
    private _SaveOwnerRole;
    private _JustificationContentchange;
    render(): React.ReactElement<IRecertificationProps>;
}
//# sourceMappingURL=Recertification.d.ts.map