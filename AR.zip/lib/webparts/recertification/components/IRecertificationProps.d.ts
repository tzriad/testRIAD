import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IRecertificationProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IRecertificationProps.d.ts.map