declare const styles: {
    container: string;
    button1: string;
    button: string;
    ConfirmMessage: string;
    BtnContainer: string;
};
export default styles;
//# sourceMappingURL=DeletionRequest.module.scss.d.ts.map