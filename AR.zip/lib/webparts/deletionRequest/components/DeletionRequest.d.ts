import * as React from 'react';
import { IDeletionRequestProps } from './IDeletionRequestProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    url: string;
    owners: any[];
    currentUser: number;
    Target: boolean;
    SiteType: string;
    AlreadyRequested: boolean;
    ReviewID: string;
    ConfirmDeletion: boolean;
    display: boolean;
}
export default class DeletionRequest extends React.Component<IDeletionRequestProps, IControls> {
    constructor(props: IDeletionRequestProps);
    componentWillMount(): void;
    private _logicLanding;
    private _Confirm;
    private _Cancel;
    render(): React.ReactElement<IDeletionRequestProps>;
}
//# sourceMappingURL=DeletionRequest.d.ts.map