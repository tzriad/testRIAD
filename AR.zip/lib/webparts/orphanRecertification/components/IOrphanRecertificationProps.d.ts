import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IOrphanRecertificationProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IOrphanRecertificationProps.d.ts.map