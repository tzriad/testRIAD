import * as React from 'react';
import { IOrphanRecertificationProps } from './IOrphanRecertificationProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    Members: any[];
    SelectedOwners: any[];
    OwnersCertifiedRevokeRole: any[];
    OwnersCertifiedMaintainRole: any[];
    SiteType: string;
    url: string;
    created: string;
    currentUser: number;
    CurrentUserCertified: boolean;
    ReviewRequestStatus: string;
    Target: boolean;
    DisplayWarningOrphan: boolean;
    Strategy: string;
    Max2: boolean;
    exist: boolean;
    OwnerRoleLabel: string;
    OwnerRoleCertified: boolean;
    ChooseOwnerRole: boolean;
}
export default class OrphanRecertification extends React.Component<IOrphanRecertificationProps, IControls> {
    componentWillMount(): void;
    constructor(props: IOrphanRecertificationProps);
    private RevisionSite;
    private _logicLanding;
    private _SavePromote;
    private _SavePromoteVOTE;
    private _onChange;
    render(): React.ReactElement<IOrphanRecertificationProps>;
}
//# sourceMappingURL=OrphanRecertification.d.ts.map