import * as React from 'react';
import { IShareBoxReviewProps } from './IShareBoxReviewProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    ShareBOXType: string;
    owners: any[];
    url: string;
    reportUrl: string;
    created: string;
    currentUser: number;
    MembershipCertifiedDate: Date;
    MembershipCertifiedBy: string;
    MembershipCertified: boolean;
    SharedLinksCertifiedLabel: string;
    ReviewRequestStatus: string;
    Target: boolean;
    exist: boolean;
    Error: boolean;
}
export default class ShareBoxReview extends React.Component<IShareBoxReviewProps, IControls> {
    componentWillMount(): void;
    constructor(props: IShareBoxReviewProps);
    private _logicLanding;
    private RevisionSharedLinks;
    private _SaveMembership;
    render(): React.ReactElement<IShareBoxReviewProps>;
}
//# sourceMappingURL=ShareBoxReview.d.ts.map