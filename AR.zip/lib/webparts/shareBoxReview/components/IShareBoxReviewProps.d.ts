import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IShareBoxReviewProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IShareBoxReviewProps.d.ts.map