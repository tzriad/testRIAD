import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IShareBoxReviewWebPartProps {
    description: string;
}
export default class ShareBoxReviewWebPart extends BaseClientSideWebPart<IShareBoxReviewWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=ShareBoxReviewWebPart.d.ts.map