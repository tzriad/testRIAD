import * as React from 'react';
import styles from './RenameTeamShareBox.module.scss';
import { IRenameTeamShareBoxProps } from './IRenameTeamShareBoxProps';
import * as strings from 'RenameTeamShareBoxWebPartStrings';
import { escape } from '@microsoft/sp-lodash-subset';

import { Link, MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import {Dropdown, IDropdownOption} from 'office-ui-fabric-react/lib/Dropdown';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { _Web } from '@pnp/sp/webs/types';

const ApproveIcon: IIconProps = { iconName: 'Accept' };

const webUrl = `${window.location.protocol}//${window.location.hostname}/sites/ShareBOX`;
const SBX = new _Web(webUrl);
const GSBXUrls: IDropdownOption[] = [];

export interface IControls
{
  OldTitle: string;
  NewTitle : string;
  TeamShareBOXUrl:string;
  pendingRequest : boolean;
  Owner : boolean;
  FoundTeamShareBOX: boolean;
  errorTitle:boolean;
  Finish : boolean;
  DisplayDetails : boolean;
}


export default class RenameTeamShareBox extends React.Component<IRenameTeamShareBoxProps, IControls> {
  
  public componentWillMount() {     this._getUserGSBX();  }
  
  constructor(props: IRenameTeamShareBoxProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      OldTitle: '',
      NewTitle : '',
      TeamShareBOXUrl:'',
      pendingRequest : false,
      Owner : false,
      FoundTeamShareBOX: true,
      errorTitle : false,
      Finish : false,
      DisplayDetails:false
    }
  }

  private async _getUserGSBX(){

    const profile = await sp.profiles.myProperties.get();
    var props = {};
    profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
    profile.userProperties = props;

    // From Standard ShareBOX
    const Own: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Contains><FieldRef Name='Owners'/> <Value Type='Text'>"+ profile.DisplayName + "</Value></Contains><IsNull><FieldRef Name='DeletionDate' /></IsNull></And></Where></Query></View>"  };
    let OwnList : any[] = await SBX.lists.getByTitle("REF_TEAM_SHAREBOX").getItemsByCAMLQuery(Own); 
   for (let i = 0; i < OwnList.length; i++)
    {GSBXUrls.push({key:OwnList[i]["TeamShareBOXUrl"], text:OwnList[i]["Title"]}); }

    // From eX ShareBOX
    const Own_ex: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Contains><FieldRef Name='Owners'/> <Value Type='Text'>"+ profile.DisplayName + "</Value></Contains><IsNull><FieldRef Name='DeletionDate' /></IsNull></And></Where></Query></View>"  };
    let OwnList_ex : any[] = await SBX.lists.getByTitle("REF_TEAM_SHAREBOX_Exception").getItemsByCAMLQuery(Own_ex); 
   for (let i = 0; i < OwnList_ex.length; i++)
    {GSBXUrls.push({key:OwnList_ex[i]["TeamShareBOXUrl"], text:OwnList_ex[i]["Title"]}); }


  }
  
  private _NewNamechange(newValueInput: any): void {
    let newValue: string =  newValueInput.target.defaultValue;
    if(newValue.length > 0){ 
    this.setState({NewTitle: newValue});
    this.setState({errorTitle: false});
    }else{
      this.setState({NewTitle: ""});
      this.setState({errorTitle: true});
    }
  }

  private async _MyTeamsonChange(newValue: any): Promise<void> { 
     
    if(newValue.key.length <3){
      this.setState({DisplayDetails:false});
    }else{
      this.setState({TeamShareBOXUrl: newValue.key});
      this.setState({OldTitle: newValue.text});
      this.setState({NewTitle: ""});
      this.setState({DisplayDetails:true});
      this.setState({Finish:false});
      // Pending requests ?
      const r: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Eq><FieldRef Name='TeamShareBOXUrl'/> <Value Type='Text'>" + newValue.key + "</Value></Eq><Eq><FieldRef Name='Status' /><Value Type='Choice'>Pending</Value></Eq></And></Where></Query></View>"  };
      let reqst : any[] = await SBX.lists.getByTitle("RenameTeamShareBOX").getItemsByCAMLQuery(r); 
      if(reqst.length > 0)  {  
        this.setState({pendingRequest:true});
    }else{
      this.setState({pendingRequest:false});
     }
    }
  
    }

  private async _Request(){

    var stop = false;
    if(this.state.NewTitle.length == 0){this.setState({errorTitle: true});stop= true;}
    if(stop) return; 

       SBX.lists.getByTitle('RenameTeamShareBOX').items.add({
         Title: this.state.OldTitle,
         NewTitle : this.state.NewTitle,
         TeamShareBOXUrl : this.state.TeamShareBOXUrl
        });
      
        this.setState({Finish:true});
     }
 
  public render(): React.ReactElement<IRenameTeamShareBoxProps> {
    return (
      <div className={ styles.container }>
      <Dropdown label="my TEAM ShareBOX"  required  options={GSBXUrls} onChanged={this._MyTeamsonChange.bind(this)} />
      <br/>
      <div  style={{ display: ((this.state.DisplayDetails ) ? 'block' : 'none') }}>

      <div style={{ display: this.state.Finish ? 'none' : 'block'}} >
      <div style={{ display: !this.state.pendingRequest ? 'block' : 'none'}} >
      <MessageBar  messageBarType={MessageBarType.info}    isMultiline={true}>
          {this.state.TeamShareBOXUrl}
        </MessageBar><br/>

      <TextField  label={strings.NewTitle} required  onChange={this._NewNamechange.bind(this)}  />
      <div className={styles.errorMessage} style={{ display: (this.state.errorTitle? 'block' : 'none') }}>{strings.REQUIRED}</div>
      <br/>
     <div className={styles.Btn}><DefaultButton title={strings.REQUESTRENAME}  iconProps={ApproveIcon} text={strings.REQUESTRENAME} onClick={this._Request.bind(this)} ></DefaultButton></div> 
      </div>

      <div style={{ display: this.state.pendingRequest  ? 'block' : 'none'}} >
        <MessageBar messageBarType={MessageBarType.error}  isMultiline={true}>
            {strings.PendingMessage}
        </MessageBar><br/>
      </div>
      </div>
      <div style={{ display: this.state.Finish ? 'block' : 'none'}} >
          <MessageBar messageBarType={MessageBarType.success}  isMultiline={true}>
              {strings.FinalMessage}
          </MessageBar><br/>
        </div>
      </div>
      </div>
    );
  }
}


