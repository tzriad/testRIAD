/* tslint:disable */
require("./RenameTeamShareBox.module.css");
const styles = {
  container: 'container_55837413',
  errorMessage: 'errorMessage_55837413',
  Btn: 'Btn_55837413'
};

export default styles;
/* tslint:enable */