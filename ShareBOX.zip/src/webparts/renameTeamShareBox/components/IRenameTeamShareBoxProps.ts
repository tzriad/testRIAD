import { WebPartContext } from '@microsoft/sp-webpart-base';  
export interface IRenameTeamShareBoxProps {
  description: string;
  context: WebPartContext; 
}
