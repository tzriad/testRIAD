declare interface IRenameTeamShareBoxWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  PendingMessage : string;
  NoShareBOX : string;
  Title: string;
  NewTitle : string;
  REQUIRED : string;
  REQUESTRENAME :string;
  FinalMessage:string;
}

declare module 'RenameTeamShareBoxWebPartStrings' {
  const strings: IRenameTeamShareBoxWebPartStrings;
  export = strings;
}
