declare interface IRequestTeamDeletionWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  PendingMessage : string;
  NoShareBOX : string;
  Title: string;
  NewTitle : string;
  REQUIRED : string;
  REQUESTDELETION :string;
  FinalMessage:string;
  JUSTIFICATION:string;
}

declare module 'RequestTeamDeletionWebPartStrings' {
  const strings: IRequestTeamDeletionWebPartStrings;
  export = strings;
}
