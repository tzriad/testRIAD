import * as React from 'react';
import styles from './RequestTeamDeletion.module.scss';
import * as strings from 'RequestTeamDeletionWebPartStrings';
import { IRequestTeamDeletionProps } from './IRequestTeamDeletionProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { Link, MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import {Dropdown, IDropdownOption} from 'office-ui-fabric-react/lib/Dropdown';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { _Web } from '@pnp/sp/webs/types';

const ApproveIcon: IIconProps = { iconName: 'Accept' };

const webUrl = `${window.location.protocol}//${window.location.hostname}/sites/ShareBOX`;
const SBX = new _Web(webUrl);

const GSBXUrls: IDropdownOption[] = [];

export interface IControls
{
  Title: string;
  TeamShareBOXUrl:string;
  pendingRequest : boolean;
  Justification : string;
  Owner : boolean;
  Owners: any[] ; 
  FoundTeamShareBOX: boolean;
  Finish : boolean;
  errorDesc : boolean;
  DisplayDetails : boolean;
 }


export default class RequestTeamDeletion extends React.Component<IRequestTeamDeletionProps, IControls> {
  public componentWillMount() {     this._getUserGSBX();  }
  
  constructor(props: IRequestTeamDeletionProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      Title: '',
      TeamShareBOXUrl:'',
      Justification : '',
      pendingRequest : false,
      Owner : false,
      Owners :[],
      FoundTeamShareBOX: true,
      Finish : false,
      errorDesc : false,
      DisplayDetails:false
    }
  }

  private async _getUserGSBX(){

    const profile = await sp.profiles.myProperties.get();
    var props = {};
    profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
    profile.userProperties = props;

    const Own: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Contains><FieldRef Name='Owners'/> <Value Type='Text'>"+ profile.DisplayName + "</Value></Contains><IsNull><FieldRef Name='DeletionDate' /></IsNull></And></Where></Query></View>"  };
     
    let OwnList : any[] = await SBX.lists.getByTitle("REF_TEAM_SHAREBOX").getItemsByCAMLQuery(Own); 

    for (let i = 0; i < OwnList.length; i++)
    {GSBXUrls.push({key:OwnList[i]["TeamShareBOXUrl"], text:OwnList[i]["Title"]}); }

  }

  private _DescChange(newValueInput: any): void {
    let newValue: string =  newValueInput.target.defaultValue;
    if(newValue.length > 0){ 
    this.setState({Justification: newValue});
    this.setState({errorDesc: false});
    }else{
      this.setState({Justification: ""});
      this.setState({errorDesc: true});
    }
  }


  private async _Request(){

    var stop = false;
    if(this.state.Justification.length == 0){this.setState({errorDesc: true});stop= true;}
    if(stop) return; 

       SBX.lists.getByTitle('DeletionTeamREQUESTS').items.add({
         Title: this.state.Title,
         Description : this.state.Justification,
         TeamShareBOXUrl : this.state.TeamShareBOXUrl ,
         OwnersId: { results: this.state.Owners } 
        });
      
        this.setState({Finish:true});
     }
 
     private async _MyTeamsonChange(newValue: any): Promise<void> { 
     
    if(newValue.key.length <3){
      this.setState({DisplayDetails:false});
    }else{
      this.setState({TeamShareBOXUrl: newValue.key});
      this.setState({Title: newValue.text});
      this.setState({DisplayDetails:true});
      this.setState({Finish:false});
      // Pending requests ?
      const r: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Eq><FieldRef Name='TeamShareBOXUrl'/> <Value Type='Text'>" + newValue.key + "</Value></Eq><Eq><FieldRef Name='Status' /><Value Type='Choice'>Pending</Value></Eq></And></Where></Query></View>"  };
      let reqst : any[] = await SBX.lists.getByTitle("DeletionTeamREQUESTS").getItemsByCAMLQuery(r); 
      if(reqst.length > 0)  {  
        this.setState({pendingRequest:true});
    }else{
      this.setState({pendingRequest:false});
      // Get details
      const QGSBX: ICamlQuery = {  ViewXml: "<View>><Query><Where><Eq><FieldRef Name='TeamShareBOXUrl'/> <Value Type='Text'>"+ newValue.key + "</Value></Eq></Where></Query></View>"  };
      const GSBX = await SBX.lists.getByTitle("REF_TEAM_SHAREBOX").getItemsByCAMLQuery(QGSBX); 
      this.setState({Owners: GSBX[0]["OwnersId"]});
      }
    }
  
    }

  public render(): React.ReactElement<IRequestTeamDeletionProps> {
    return (
      <div className={ styles.container }>

      <Dropdown label="my TEAM ShareBOX"  required  options={GSBXUrls} onChanged={this._MyTeamsonChange.bind(this)} />
      <br/>
      <div  style={{ display: ((this.state.DisplayDetails ) ? 'block' : 'none') }}>

      <div style={{ display: this.state.Finish ? 'none' : 'block'}} >
      <div style={{ display: !this.state.pendingRequest ? 'block' : 'none'}} >
      <MessageBar  messageBarType={MessageBarType.info}    isMultiline={true}>
          {this.state.TeamShareBOXUrl}
        </MessageBar><br/>

     <TextField  label={strings.JUSTIFICATION} multiline underlined required  onChange={this._DescChange.bind(this)}  />
     <div className={styles.errorMessage} style={{ display: (this.state.errorDesc? 'block' : 'none') }}>{strings.REQUIRED}</div>
     <br/>
     <div className={styles.Btn}><DefaultButton title={strings.REQUESTDELETION}  iconProps={ApproveIcon} text={strings.REQUESTDELETION} onClick={this._Request.bind(this)} ></DefaultButton></div> 
      </div>

      <div style={{ display: this.state.pendingRequest  ? 'block' : 'none'}} >
        <MessageBar messageBarType={MessageBarType.error}  isMultiline={true}>
            {strings.PendingMessage}
        </MessageBar><br/>
      </div>
      </div>
      <div style={{ display: this.state.Finish ? 'block' : 'none'}} >
          <MessageBar messageBarType={MessageBarType.success}  isMultiline={true}>
              {strings.FinalMessage}
          </MessageBar><br/>
        </div>
      </div>
    </div>
    );
  }
}
