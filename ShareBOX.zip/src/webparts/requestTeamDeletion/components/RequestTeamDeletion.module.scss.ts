/* tslint:disable */
require("./RequestTeamDeletion.module.css");
const styles = {
  container: 'container_03bc9c86',
  errorMessage: 'errorMessage_03bc9c86',
  Btn: 'Btn_03bc9c86'
};

export default styles;
/* tslint:enable */