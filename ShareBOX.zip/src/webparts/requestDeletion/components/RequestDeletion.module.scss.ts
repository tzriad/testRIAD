/* tslint:disable */
require("./RequestDeletion.module.css");
const styles = {
  container: 'container_17f20f30',
  Btn: 'Btn_17f20f30',
  tg: 'tg_17f20f30'
};

export default styles;
/* tslint:enable */