import * as React from 'react';
import styles from './RequestDeletion.module.scss';
import * as strings from 'RequestDeletionWebPartStrings';
import { IRequestDeletionProps } from './IRequestDeletionProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { Link, MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { _Web } from '@pnp/sp/webs/types';

const ApproveIcon: IIconProps = { iconName: 'Accept' };

const webUrl = `${window.location.protocol}//${window.location.hostname}/sites/ShareBOX`;
const SBX = new _Web(webUrl);


export interface IControls
{
  User: string;  
  AccountName:string;
  Email:string;
  Manager: number ;  
  ManagerName:string;
  Justification:string ;
  Company:string;
  Disclaimer: boolean;
  errorDisclaimer : string;
  RequestForm:boolean;
  finish:boolean;
  hasShareBox:boolean;
  ShareBOXUrl:string;
  pendingRequest : boolean;
  NotOnboarded: boolean;
  SecTeamEmail: number;
}


export default class RequestDeletion extends React.Component<IRequestDeletionProps, IControls> {
  public componentWillMount() { this._getUserProfileInformation();  }
  constructor(props: IRequestDeletionProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      User: '',  
      AccountName:'',
      Email:'',
      Manager: 0,  
      ManagerName :'',
      Justification:'',
      Company:'',
      Disclaimer:false,
      errorDisclaimer:'',
      RequestForm:false,
      finish : false,
      hasShareBox:true,
      pendingRequest : false,
      NotOnboarded: false,
      ShareBOXUrl:'',
      SecTeamEmail:0,
    };

  }

  private async _getUserProfileInformation(){
       //Get User profile informations
       const profile = await sp.profiles.myProperties.get();
       this.setState({AccountName: profile.AccountName});
       var props = {};
       profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
       profile.userProperties = props;
       this.setState({Company: profile.userProperties["Office"]});
       this.setState({User: profile.userProperties["PreferredName"]});
       this.setState({Email: profile.userProperties["WorkEmail"]});
       this.setState({Manager: profile.userProperties["Manager"]});
       var ManagerN = await sp.profiles.getUserProfilePropertyFor(profile.userProperties["Manager"],"PreferredName");
       this.setState({ManagerName: ManagerN});

       console.log(ManagerN);
  //Check if user's entity is already onboarded
  const o: ICamlQuery = {  ViewXml: "<View>><Query><Where><Contains> <FieldRef Name='Names'/> <Value Type='Note'>" + profile.userProperties["Office"] + "</Value></Contains></Where></Query><RowLimit>1</RowLimit></View>"  };
  let reqop : any[] = await SBX.lists.getByTitle("OpCOs").getItemsByCAMLQuery(o); 
  if(reqop.length == 0)  { 
    this.setState({NotOnboarded:true});
    return;
  }else{
    this.setState({SecTeamEmail: reqop[0]["SecurityTeamId"]});
  }

       //Check if user already has a ShareBOX (not deleted)
       const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Eq><FieldRef Name='Title'/> <Value Type='Text'>" + profile.AccountName + "</Value></Eq><IsNull><FieldRef Name='DeletionDate' /></IsNull></And></Where></Query></View>"  };
       let refsbx : any[] = await SBX.lists.getByTitle("REF_SHAREBOX").getItemsByCAMLQuery(q); 
       if(refsbx.length > 0)  { 
        this.setState({hasShareBox:true});
        this.setState({ShareBOXUrl:refsbx[0]["ShareBoxUrl"]});
        }else {
          this.setState({hasShareBox:false});
          return;
        }
   
   
       //Check if user pending/validated request exist
       const r: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Eq><FieldRef Name='Title'/> <Value Type='Text'>" + profile.AccountName + "</Value></Eq><Or><Eq><FieldRef Name='Status' /><Value Type='Choice'>In Progress</Value></Eq><Eq><FieldRef Name='Status' /><Value Type='Choice'>Validated</Value></Eq></Or></And></Where></Query></View>"  };
       let reqst : any[] = await SBX.lists.getByTitle("DeletionREQUESTS").getItemsByCAMLQuery(r); 
   
       if(reqst.length > 0)  { 
         this.setState({pendingRequest:true});
         return;
       }
   
      
       //Display REQUEST FORM
       this.setState({RequestForm:true});
  }

  private _decriptionchange(newValue: string): void {
    if(newValue.length > 0){ 
    this.setState({Justification: newValue});
    }
  }

  private async _Request(){

    let result = await SBX.ensureUser(this.state.Manager.toString());
       
       SBX.lists.getByTitle('DeletionREQUESTS').items.add({
         Title: this.state.AccountName,
         OpCO: this.state.Company,
         Description: this.state.Justification,
         Email: this.state.Email,
         ManagerId :result.data.Id,
         SecurityApprovalId:this.state.SecTeamEmail,
         FullName: this.state.User,
         ShareBoxUrl:this.state.ShareBOXUrl
        });
      
        this.setState({RequestForm:false});
        this.setState({finish:true});
     }
 

  public render(): React.ReactElement<IRequestDeletionProps> {
    return (
      <div className={ styles.container }>
        <div  style={{ display: (this.state.RequestForm? 'block' : 'none') }} >
       <TextField  label={strings.User}  readOnly  value={this.state.User}  />
       <br/>
       <TextField  label={strings.Manager}  readOnly  value={this.state.ManagerName}  />
       <br/>
       <TextField  label={strings.Company}  readOnly  value={this.state.Company}  />
       <br/>
       <MessageBar  messageBarType={MessageBarType.info}    isMultiline={true}>
          {this.state.ShareBOXUrl}
        </MessageBar><br/>
       <TextField  placeholder={strings.JUSTIFICATION} label="" multiline underlined  onChange={this._decriptionchange.bind(this)} />
       <br/>     
       <div className={styles.Btn}><DefaultButton title={strings.REQUESTDELETION}  iconProps={ApproveIcon} text={strings.REQUESTDELETION} onClick={this._Request.bind(this)} ></DefaultButton></div> 
       </div>

       <div  style={{ display: (this.state.finish? 'block' : 'none') }} >
        <MessageBar  messageBarType={MessageBarType.warning}    isMultiline={true}>
        {strings.ValidationMessage}
        </MessageBar><br/>
     </div>

     <div  style={{ display: (this.state.hasShareBox? 'none' : 'block') }} >
     <MessageBar
           messageBarType={MessageBarType.error}
           isMultiline={true}>
       {strings.NoShareBOX}
        </MessageBar><br/>
     </div>

     <div  style={{ display: (this.state.pendingRequest? 'block' : 'none') }} >
     <MessageBar
           messageBarType={MessageBarType.error}
           isMultiline={true}>
        {strings.PendingMessage}
        </MessageBar><br/>
     </div>

     <div  style={{ display: (this.state.NotOnboarded? 'block' : 'none') }} >
     <MessageBar
           messageBarType={MessageBarType.error}
           isMultiline={true}>
        {strings.NotOnboardedMessage}
        </MessageBar><br/>
     </div>

      </div>
    );
  }
}
