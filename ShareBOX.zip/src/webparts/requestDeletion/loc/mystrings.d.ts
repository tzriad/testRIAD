declare interface IRequestDeletionWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  User:string;
  Manager: string;
  Company:string;
  JUSTIFICATION:string;
  REQUESTDELETION:string;
  ValidationMessage:string;
  NoShareBOX:string;
  PendingMessage:string;
  NotOnboardedMessage:string;

}

declare module 'RequestDeletionWebPartStrings' {
  const strings: IRequestDeletionWebPartStrings;
  export = strings;
}
