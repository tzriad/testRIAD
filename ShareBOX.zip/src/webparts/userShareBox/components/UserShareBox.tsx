import * as React from 'react';
import styles from './UserShareBox.module.scss';
import * as strings from 'UserShareBoxWebPartStrings';
import { IUserShareBoxProps } from './IUserShareBoxProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { Link, MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { _Web } from '@pnp/sp/webs/types';

const ApproveIcon: IIconProps = { iconName: 'Accept' };

const webUrl = `${window.location.protocol}//${window.location.hostname}/sites/ShareBOX`;
const SBX = new _Web(webUrl);

export interface IControls
{
  User: string;  
  AccountName:string;
  Email:string;
  Manager: number ;  
  ManagerName:string;
  Justification:string ;
  Company:string;
  Country:string;
  Disclaimer: boolean;
  errorDisclaimer : string;
  show:string;
  finish:boolean;
  hasShareBox:boolean;
  pendingRequest : boolean;
  NotOnboarded: boolean;
  errorDesc:string;
  ShareBOXUrl:string;
  SecTeamEmail: number;
  ManagerApproval : boolean;
  SecurityApproval : boolean;
  DisclaimerUrl : string;
}

export default class UserShareBox extends React.Component<IUserShareBoxProps, IControls> {
  public componentWillMount() { this._getUserProfileInformation();  }
  constructor(props: IUserShareBoxProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      User: '',  
      AccountName:'',
      Email:'',
      Manager: 0,  
      ManagerName :'',
      Justification:'',
      Company:'',
      Country:'',
      errorDesc:'',
      Disclaimer:false,
      errorDisclaimer:'',
      show:'',
      finish : false,
      hasShareBox:false,
      pendingRequest : false,
      NotOnboarded: false,
      SecTeamEmail:0,
      ShareBOXUrl:'',
      DisclaimerUrl :'https://axa365.sharepoint.com/sites/shareBOX/sitepages/disclaimer.aspx',
      ManagerApproval : true,
      SecurityApproval:true
    };

  }

  
  private async _getUserProfileInformation(){

        //Get User profile informations
    const profile = await sp.profiles.myProperties.get();
    this.setState({AccountName: profile.AccountName});
    var props = {};
    profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
    profile.userProperties = props;
    this.setState({Company: profile.userProperties["Office"]});
    this.setState({Country: profile.userProperties["ONECountry"]});
    this.setState({User: profile.userProperties["PreferredName"]});
    this.setState({Email: profile.userProperties["WorkEmail"]});
    this.setState({Manager: profile.userProperties["Manager"]});
    var ManagerN = await sp.profiles.getUserProfilePropertyFor(profile.userProperties["Manager"],"PreferredName");
    this.setState({ManagerName: ManagerN});

    //Check if user already has a ShareBOX
    const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Eq><FieldRef Name='Title'/> <Value Type='Text'>" + profile.AccountName + "</Value></Eq><IsNull><FieldRef Name='DeletionDate' /></IsNull></And></Where></Query></View>"  };

    let refsbx : any[] = await SBX.lists.getByTitle("REF_SHAREBOX").getItemsByCAMLQuery(q); 
    if(refsbx.length > 0)  { 
      this.setState({hasShareBox:true});
      this.setState({ShareBOXUrl:refsbx[0]["ShareBoxUrl"]});
      this.setState({show:"hide"});
      return;    
    }

     //Check if user pending/validated request exist
    const r: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Eq><FieldRef Name='Title'/> <Value Type='Text'>" + profile.AccountName + "</Value></Eq><Or><Eq><FieldRef Name='Status' /><Value Type='Choice'>In Progress</Value></Eq><Eq><FieldRef Name='Status' /><Value Type='Choice'>Validated</Value></Eq></Or></And></Where></Query></View>"  };

    let reqst : any[] = await SBX.lists.getByTitle("REQUESTS").getItemsByCAMLQuery(r); 
    if(reqst.length > 0)  { 
      this.setState({pendingRequest:true});
      this.setState({show:"hide"});
      return;
    }

    //Check if user's entity is already onboarded
     const o: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Contains><FieldRef Name='Names'/> <Value Type='Note'>" + profile.userProperties["Office"] + "</Value></Contains><Eq><FieldRef Name='Active'/><Value Type='Boolean'>1</Value></Eq></And></Where></Query></View>"  };
 
    let reqop : any[] = await SBX.lists.getByTitle("OpCOs").getItemsByCAMLQuery(o); 
    if(reqop.length == 0)  { 
      this.setState({NotOnboarded:true});
      this.setState({show:"hide"});
      return;
    }else{
      this.setState({SecTeamEmail: reqop[0]["SecurityTeamId"]});
      this.setState({ManagerApproval: reqop[0]["ManagerApproval"]});
      this.setState({SecurityApproval: reqop[0]["SecurityApproval"]});
      if(reqop[0]["Disclaimer"] != null)
       { this.setState({DisclaimerUrl: reqop[0]["Disclaimer"]});}
    }

    this.setState({show:"show"});
    
  }


  private _Disclaimer(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
    var elemes =  document.getElementsByClassName(styles.Btn);
    if( checked) {
      [].forEach.call(elemes, function(el) { el.style.display = "block";});
   }else{
    [].forEach.call(elemes, function(el) { el.style.display = "none";});
   }
    }

    private async _Request(){

      var stop = false;
      if(this.state.Justification.length == 0){this.setState({errorDesc: "show"});stop= true;}
      if(stop) return; 

   let result = await SBX.ensureUser(this.state.Manager.toString());
      
   SBX.lists.getByTitle('REQUESTS').items.add({
        Title: this.state.AccountName,
        OpCO: this.state.Company,
        Country:this.state.Country,
        Description: this.state.Justification,
        Email: this.state.Email,
        ManagerId :result.data.Id,
        SecurityApprovalId:this.state.SecTeamEmail,
        isManagerApproval : this.state.ManagerApproval,
        isSecurityApproval: this.state.SecurityApproval,
        FullName: this.state.User
       });
     
       this.setState({show:"hide"});
       this.setState({finish:true});
    }

    private _decriptionchange(newValueInput: any): void {
      let newValue: string =  newValueInput.target.defaultValue;
        if(newValue.length > 0){ 
        this.setState({Justification: newValue});
        this.setState({errorDesc: ""});
        }else{
          this.setState({Justification: ""});
          this.setState({errorDesc: "show"});
        }
      }

  public render(): React.ReactElement<IUserShareBoxProps> {
    return (
      <div className={ styles.container }>
       <div  style={{ display: (this.state.show  =="show"? 'block' : 'none') }} >
       <TextField  label= {strings.User}  readOnly  value={this.state.User}  />
       <br/>
       <TextField  label={strings.Manager}  readOnly  value={this.state.ManagerName}  />
       <br/>
       <TextField  label={strings.Company}  readOnly  value={this.state.Company}  />
       <br/>
       <TextField  label={strings.Country}  readOnly  value={this.state.Country}  />
       <br/>
       <TextField  placeholder={strings.Describe} required label="" multiline underlined  onChange={this._decriptionchange.bind(this)} />
       <div className={styles.errorMessage} style={{ display: (this.state.errorDesc  =="show"? 'block' : 'none') }}>{strings.REQUIRED}</div>
       <br/>
       <Toggle  inlineLabel onChange={this._Disclaimer.bind(this)} className={styles.tg}/> <a className={ styles.link } rel="noopener noreferrer" data-interception="off"  target="_blank" href={this.state.DisclaimerUrl}> Mandatory agreement of the disclaimer in order to request</a>
        <br/>
       <br/>
       <div className={styles.Btn}><DefaultButton title={strings.REQUEST_IT}  iconProps={ApproveIcon} text={strings.REQUEST_IT} onClick={this._Request.bind(this)} ></DefaultButton></div> 
     </div>
     <div  style={{ display: (this.state.finish? 'block' : 'none') }} >
     <MessageBar
           messageBarType={MessageBarType.warning}
           isMultiline={true}>
        {strings.ValidationMessage}
        </MessageBar><br/>
     </div>

     <div  style={{ display: (this.state.hasShareBox? 'block' : 'none') }} >
     <MessageBar
           messageBarType={MessageBarType.error}
           isMultiline={true}>
        {strings.AlreadyMessage}
        </MessageBar><br/>
        <br/>
       <MessageBar  messageBarType={MessageBarType.info}    isMultiline={true}>
         <a href={this.state.ShareBOXUrl} target="_blank">{this.state.ShareBOXUrl}</a>
        </MessageBar><br/>
     </div>

     <div  style={{ display: (this.state.pendingRequest? 'block' : 'none') }} >
     <MessageBar
           messageBarType={MessageBarType.error}
           isMultiline={true}>
       {strings.PendingMessage}
        </MessageBar><br/>
     </div>

     <div  style={{ display: (this.state.NotOnboarded? 'block' : 'none') }} >
     <MessageBar
           messageBarType={MessageBarType.error}
           isMultiline={true}>
       {strings.NotOnboardedMessage}
        </MessageBar><br/>
     </div>
     
      </div>
    );
  }
}
