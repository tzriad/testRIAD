/* tslint:disable */
require("./UserShareBox.module.css");
const styles = {
  container: 'container_884d25ea',
  Btn: 'Btn_884d25ea',
  tg: 'tg_884d25ea',
  errorMessage: 'errorMessage_884d25ea',
  link: 'link_884d25ea'
};

export default styles;
/* tslint:enable */