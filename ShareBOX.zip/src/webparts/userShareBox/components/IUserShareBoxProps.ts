import { WebPartContext } from '@microsoft/sp-webpart-base';  
export interface IUserShareBoxProps {
  description: string;
  context: WebPartContext; 
}
