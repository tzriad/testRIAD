declare interface IUserShareBoxWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  Disclaimer : string;
  REQUEST_IT:string;
  ValidationMessage:string;
  AlreadyMessage:string;
  PendingMessage:string;
  NotOnboardedMessage:string;
  Describe:string;
  User:string;
  Company:string;
  Country:string;
  Manager:string;
  REQUIRED:string;
}

declare module 'UserShareBoxWebPartStrings' {
  const strings: IUserShareBoxWebPartStrings;
  export = strings;
}
