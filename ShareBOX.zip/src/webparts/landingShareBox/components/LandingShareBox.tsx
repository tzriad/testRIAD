import * as React from 'react';
import styles from './LandingShareBox.module.scss';
import { ILandingShareBoxProps } from './ILandingShareBoxProps';
import { escape } from '@microsoft/sp-lodash-subset';


import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";

export interface IControls
{
  User: string;  
  AccountName:string;
  DeletionDate:string;
  pendingRequest: boolean;
  NotOnboarded:boolean;
  HasSharebox:boolean;
  RequestForm :boolean;
  ShareBOXUrl:string;
  TeamShareBOXEnabled : boolean;
}

export default class LandingShareBox extends React.Component<ILandingShareBoxProps, IControls> {
 public componentWillMount() { this._getUserProfileInformation();  }
constructor(props: ILandingShareBoxProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      User: '',  
      AccountName:'',
      DeletionDate:'',
      pendingRequest: false,
      NotOnboarded:false,
      HasSharebox:false,
      RequestForm :false,
      ShareBOXUrl:'',
      TeamShareBOXEnabled :false
    };

  }

private async _getUserProfileInformation(){
    //Get User profile informations
    const profile = await sp.profiles.myProperties.get();
    this.setState({AccountName: profile.AccountName});
    var props = {};
    profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
    profile.userProperties = props;

     //Check if user's entity is already onboarded
     const o: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Contains><FieldRef Name='Names'/> <Value Type='Note'>" + profile.userProperties["Office"] + "</Value></Contains><Eq><FieldRef Name='Active'/><Value Type='Boolean'>1</Value></Eq></And></Where></Query></View>"  };
     let reqop : any[] = await sp.web.lists.getByTitle("OpCOs").getItemsByCAMLQuery(o); 
     if(reqop.length == 0)  { 
       this.setState({NotOnboarded:true});
       return;
     }else{
        this.setState({TeamShareBOXEnabled: reqop[0]["TeamShareBOX"]});
     }
    
    //Check if user already has a ShareBOX (not deleted)
    const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Eq><FieldRef Name='Title'/> <Value Type='Text'>" + profile.AccountName + "</Value></Eq><IsNull><FieldRef Name='DeletionDate' /></IsNull></And></Where></Query></View>"  };
    let refsbx : any[] = await sp.web.lists.getByTitle("REF_SHAREBOX").getItemsByCAMLQuery(q); 
    if(refsbx.length > 0)  { 
     this.setState({HasSharebox:true});
     this.setState({ShareBOXUrl:refsbx[0]["ShareBoxUrl"]});
      return;
    }


    //Check if user pending/validated request exist
    const r: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Eq><FieldRef Name='Title'/> <Value Type='Text'>" + profile.AccountName + "</Value></Eq><Or><Eq><FieldRef Name='Status' /><Value Type='Choice'>In Progress</Value></Eq><Eq><FieldRef Name='Status' /><Value Type='Choice'>Validated</Value></Eq></Or></And></Where></Query></View>"  };
    let reqst : any[] = await sp.web.lists.getByTitle("REQUESTS").getItemsByCAMLQuery(r); 

    if(reqst.length > 0)  { 
      this.setState({pendingRequest:true});
      return;
    }

     
    //Display REQUEST FORM
    this.setState({RequestForm:true});
  }

public render(): React.ReactElement<ILandingShareBoxProps> {
    return (
      <div className={ styles.container }>
          <div  style={{ display: (this.state.HasSharebox? 'block' : 'none') }} >
          <span className={styles.leftPane}><a href={this.state.ShareBOXUrl}><img src="/sites/Sharebox/SiteAssets/GoToMySB.png" /></a></span>
          <span className={styles.rightPane}><a href="/sites/ShareBOX/SitePages/Request-deletion-ShareBox.aspx"><img src="/sites/Sharebox/SiteAssets/RequestDeletion.png" /></a></span>
          </div>

          <div  style={{ display: (this.state.pendingRequest? 'block' : 'none') }} >
          <div className={styles.OpCoMessage}>
         <div className={styles.InnerOpCoMessage}>You already have a pending user request.<br/> Please wait for validation process</div>
         </div>
         </div>

         <div  style={{ display: (this.state.NotOnboarded? 'block' : 'none') }} >
         <div className={styles.OpCoMessage}>
         <div className={styles.InnerOpCoMessage}>Your entity is not onbarded on AXA ShareBOX yet.<br/> Please contact your local workspace team or local IT Support if you wish to access the service</div>
         </div>
         </div>

         <div  style={{ display: (this.state.RequestForm? 'block' : 'none') }} >
            <a href="/sites/ShareBOX/SitePages/Request-a-personal-ShareBox.aspx"><img src="/sites/Sharebox/SiteAssets/AskYourSBX.png" /></a>
        </div>
       <br/>
        <div  style={{ display: (this.state.TeamShareBOXEnabled? 'block' : 'none') }} >
            <a href="/sites/ShareBOX/SitePages/Request-team-ShareBox.aspx"><img src="/sites/Sharebox/SiteAssets/Request_TeamShareBOX.png" /></a>
        </div>
      </div>
    );
  }
}
