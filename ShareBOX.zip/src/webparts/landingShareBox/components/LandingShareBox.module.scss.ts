/* tslint:disable */
require("./LandingShareBox.module.css");
const styles = {
  container: 'container_67fd725e',
  OpCoMessage: 'OpCoMessage_67fd725e',
  InnerOpCoMessage: 'InnerOpCoMessage_67fd725e',
  leftPane: 'leftPane_67fd725e',
  rightPane: 'rightPane_67fd725e'
};

export default styles;
/* tslint:enable */