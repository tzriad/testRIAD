declare interface ILandingShareBoxWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'LandingShareBoxWebPartStrings' {
  const strings: ILandingShareBoxWebPartStrings;
  export = strings;
}
