declare interface IAccessReportsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AccessReportsWebPartStrings' {
  const strings: IAccessReportsWebPartStrings;
  export = strings;
}
