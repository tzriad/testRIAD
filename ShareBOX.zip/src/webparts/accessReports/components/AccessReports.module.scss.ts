/* tslint:disable */
require("./AccessReports.module.css");
const styles = {
  accessReports: 'accessReports_b4352e9e',
  container: 'container_b4352e9e',
  row: 'row_b4352e9e',
  column: 'column_b4352e9e',
  'ms-Grid': 'ms-Grid_b4352e9e',
  title: 'title_b4352e9e',
  subTitle: 'subTitle_b4352e9e',
  description: 'description_b4352e9e',
  button: 'button_b4352e9e',
  label: 'label_b4352e9e'
};

export default styles;
/* tslint:enable */