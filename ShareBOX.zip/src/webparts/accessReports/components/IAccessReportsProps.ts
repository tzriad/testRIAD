import { WebPartContext } from '@microsoft/sp-webpart-base';  
export interface IAccessReportsProps {
  description: string;
  context: WebPartContext; 
}
