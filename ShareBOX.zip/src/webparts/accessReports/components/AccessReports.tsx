import * as React from 'react';
import styles from './AccessReports.module.scss';
import { IAccessReportsProps } from './IAccessReportsProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";

export interface IControls
{
  Url:string;
  AccountName : string;
}

export default class AccessReports extends React.Component<IAccessReportsProps, IControls> {
  public componentWillMount() { this._getUserProfileInformation();  }
  constructor(props: IAccessReportsProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      Url: '' ,
      AccountName:''
    };
  }

  private async _getUserProfileInformation(){

    //Get User profile informations
    const profile = await sp.profiles.myProperties.get();
    this.setState({AccountName: profile.AccountName});
    var props = {};
    profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
    profile.userProperties = props;

    const o: ICamlQuery = {  ViewXml: "<View>><Query><Where><Contains> <FieldRef Name='Names'/> <Value Type='Note'>" + profile.userProperties["Office"] + "</Value></Contains></Where></Query><RowLimit>1</RowLimit></View>"  };
    let reqop : any[] = await sp.site.rootWeb.lists.getByTitle("OpCOs").getItemsByCAMLQuery(o); 

    if(reqop.length > 0)  {
      this.setState({Url: reqop[0]["Reports"].Url});
    }
  }

 
  public render(): React.ReactElement<IAccessReportsProps> {
    return (
      <div>
        <a href={this.state.Url}>
        <img src={this.props.context.pageContext.site.absoluteUrl + "/siteAssets/RedirectToReports.png"} />
      </a>
      </div>
    );


  }
}
