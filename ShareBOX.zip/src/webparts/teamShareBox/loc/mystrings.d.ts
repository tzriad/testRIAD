declare interface ITeamShareBoxWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  User:string;
  Manager: string;
  Company:string;
  Title:string;
  Describe:string;
  Owners:string;
  Members:string;
  Disclaimer:string;
  REQUEST_IT:string;
  ValidationMessage:string;
  NotOnboardedMessage:string;
  ErrorOwner : string;
  REQUIRED : string;
  Country: string;
}

declare module 'TeamShareBoxWebPartStrings' {
  const strings: ITeamShareBoxWebPartStrings;
  export = strings;
}
