/* tslint:disable */
require("./TeamShareBox.module.css");
const styles = {
  container: 'container_1ca63e79',
  Btn: 'Btn_1ca63e79',
  tg: 'tg_1ca63e79',
  errorMessage: 'errorMessage_1ca63e79',
  link: 'link_1ca63e79'
};

export default styles;
/* tslint:enable */