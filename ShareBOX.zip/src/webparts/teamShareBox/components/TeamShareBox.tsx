import * as React from 'react';
import styles from './TeamShareBox.module.scss';
import * as strings from 'TeamShareBoxWebPartStrings';
import { ITeamShareBoxProps } from './ITeamShareBoxProps';
import { Link, MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";



import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { _Web } from '@pnp/sp/webs/types';

const webUrl = `${window.location.protocol}//${window.location.hostname}/sites/ShareBOX`;
const SBX = new _Web(webUrl);

const ApproveIcon: IIconProps = { iconName: 'Accept' };
export interface IControls
{
  User: string;  
  AccountName:string;
  owners: any[] ;  
  members:any[] ;
  Manager: number ;  
  ManagerName:string;
  Justification:string ;
  Company:string;
  Country:string;
  Disclaimer: boolean;
  errorDisclaimer : string;
  show:string;
  finish:boolean;
  hasShareBox:boolean;
  pendingRequest : boolean;
  NotOnboarded: boolean;
  SecTeamEmail: number;
  TeamShareBOXEnabled : boolean;
  Title: string;
  errorOwner:string;
  errorTitle:string;
  errorDesc:string;
  NbInternalOwner:number;
  ManagerApproval : boolean;
  SecurityApproval : boolean;
  DisclaimerUrl : string;
}

export default class TeamShareBox extends React.Component<ITeamShareBoxProps, IControls> {
    public componentWillMount() { this._getUserProfileInformation();  }
   
    constructor(props: ITeamShareBoxProps) {  
      super(props);  
     
      sp.setup({  spfxContext: props.context  });
    
      this.state = {  
        User: '',  
        AccountName:'',
        owners: [] ,  
        members:[] ,
        Manager: 0,  
        ManagerName :'',
        Justification:'',
        Company:'',
        Country:'',
        Disclaimer:false,
        errorDisclaimer:'',
        show:'show',
        finish : false,
        hasShareBox:false,
        pendingRequest : false,
        NotOnboarded: false,
        SecTeamEmail:0,
        TeamShareBOXEnabled:false,
        Title:'',
        errorOwner:'',
        errorTitle:'',
        errorDesc:'',
        NbInternalOwner:0,
        DisclaimerUrl :'https://axa365.sharepoint.com/sites/shareBOX/sitepages/disclaimer.aspx',
        ManagerApproval : true,
        SecurityApproval:true
      };
  
    }
  
    
    private async _getUserProfileInformation(){
     //Get User profile informations
     const profile = await sp.profiles.myProperties.get();
     this.setState({AccountName: profile.AccountName});
     var props = {};
     profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
     profile.userProperties = props;
     this.setState({Company: profile.userProperties["Office"]});
     this.setState({Country: profile.userProperties["ONECountry"]});
     this.setState({User: profile.userProperties["PreferredName"]});
     this.setState({Manager: profile.userProperties["Manager"]});
     var ManagerN = await sp.profiles.getUserProfilePropertyFor(profile.userProperties["Manager"],"PreferredName");
     this.setState({ManagerName: ManagerN});

    //Check if user's entity is already onboarded
    const o: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Contains><FieldRef Name='Names'/> <Value Type='Note'>" + profile.userProperties["Office"] + "</Value></Contains><Eq><FieldRef Name='Active'/><Value Type='Boolean'>1</Value></Eq></And></Where></Query></View>"  };
    let reqop : any[] = await SBX.lists.getByTitle("OpCOs").getItemsByCAMLQuery(o); 
    if(reqop.length == 0)  { 
      this.setState({NotOnboarded:true});
      this.setState({show:"hide"});
      return;
    }else{
      this.setState({SecTeamEmail: reqop[0]["SecurityTeamId"]});
      this.setState({TeamShareBOXEnabled: reqop[0]["TeamShareBOX"]});
      this.setState({ManagerApproval: reqop[0]["ManagerApproval"]});
      this.setState({SecurityApproval: reqop[0]["SecurityApproval"]});
      if(reqop[0]["Disclaimer"] != null)
       { this.setState({DisclaimerUrl: reqop[0]["Disclaimer"]});}
    }

    if(reqop[0]["TeamShareBOX"])
       this.setState({show:"show"});
       else
       this.setState({show:"hide"});
    }

    private _Disclaimer(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
      var elemes =  document.getElementsByClassName(styles.Btn);
      if( checked) {
        [].forEach.call(elemes, function(el) { el.style.display = "block";});
     }else{
      [].forEach.call(elemes, function(el) { el.style.display = "none";});
     }
      }

    private _decriptionchange(newValueInput: any): void {
      let newValue: string =  newValueInput.target.defaultValue;
        if(newValue.length > 0){ 
        this.setState({Justification: newValue});
        this.setState({errorDesc: ""});
        }else{
          this.setState({Justification: ""});
          this.setState({errorDesc: "show"});
        }
      }


      private _TitleonChange(newValueInput: any): void {  
        let newValue: string =  newValueInput.target.defaultValue;
          if(newValue.length == 0){
          this.setState({errorTitle: "show"});
          this.setState({Title: ""});
        }else{  
        this.setState({Title: newValue}); 
        this.setState({errorTitle: ""});
        }
      
      }

    private async _getOwners(items: any[]){
      let tempTeamAssArr = [];  
      let NbInternalOwner : number = 0;
      for (let item in items) { 

        let result = await SBX.ensureUser("i:0#.f|membership|" + items[item].secondaryText);
        tempTeamAssArr.push(result.data.Id);  NbInternalOwner++;  
      
      }

      if(NbInternalOwner < 2){
        this.setState({errorOwner: "show"});
        this.setState({NbInternalOwner : 0});
      }
      else{
      this.setState({errorOwner: ""});
      this.setState({ owners: tempTeamAssArr });
      this.setState({NbInternalOwner : tempTeamAssArr.length}); 
      }

    }

    private async _getMembers(items: any[]) { 
      let tempTeamAssArr = [];  
      for (let item in items) {  
        let result = await SBX.ensureUser("i:0#.f|membership|" + items[item].secondaryText);
        tempTeamAssArr.push(result.data.Id); 
      }   
      this.setState({ members: tempTeamAssArr });
    }


    private async _Request(){

      var stop = false;
      if(this.state.Title.length == 0){this.setState({errorTitle: "show"});stop= true;}
      if(this.state.Justification.length == 0){this.setState({errorDesc: "show"});stop= true;}
      if(this.state.NbInternalOwner == 0){ this.setState({errorOwner: "show"});stop=true;}
      if(stop) return; 
      
      
           let result = await SBX.ensureUser(this.state.Manager.toString());
           console.log("Title :" + this.state.Title);
           SBX.lists.getByTitle('TEAM_REQUESTS').items.add({
             Title: this.state.Title,
             OpCo: this.state.Company,
             Description: this.state.Justification,
             ManagerId :result.data.Id,
             SecurityApprovalId:this.state.SecTeamEmail,
             OwnersId : {  results: this.state.owners },
             MembersId : {  results: this.state.members },
             isManagerApproval : this.state.ManagerApproval,
             isSecurityApproval: this.state.SecurityApproval,
             Country:this.state.Country
            });
          
            this.setState({show:"hide"});
            this.setState({finish:true});
       }

    public render(): React.ReactElement<ITeamShareBoxProps> {
  
    return (
      <div className={ styles.container }>
       <div  style={{ display: (this.state.show  =="show"? 'block' : 'none') }} >
       <TextField  label={strings.User}  readOnly  value={this.state.User}  />
       <br/>
       <TextField  label={strings.Manager}  readOnly  value={this.state.ManagerName}  />
       <br/>
       <TextField  label={strings.Company}  readOnly  value={this.state.Company}  />
       <br/>
       <TextField  label={strings.Country}  readOnly  value={this.state.Country}  />
       <br/>
       <TextField  label={strings.Title}  underlined required  onChange={this._TitleonChange.bind(this)}  />
       <div className={styles.errorMessage} style={{ display: (this.state.errorTitle  =="show"? 'block' : 'none') }}>{strings.REQUIRED}</div>
       <br/>
       <TextField  placeholder={strings.Describe} required label="" multiline underlined  onChange={this._decriptionchange.bind(this)} />
       <div className={styles.errorMessage} style={{ display: (this.state.errorDesc  =="show"? 'block' : 'none') }}>{strings.REQUIRED}</div>
       <br/>
       <PeoplePicker 
       required={true}
      context={this.props.context as any}
      titleText={strings.Owners}
      personSelectionLimit={10} 
      showtooltip={false} 
      disabled={false}
      onChange={this._getOwners.bind(this)}
      showHiddenInUI={false}
      ensureUser={true}
      principalTypes={[PrincipalType.User]}
      resolveDelay={1000} />
      <div className={styles.errorMessage} style={{ display: (this.state.errorOwner  =="show"? 'block' : 'none') }}>{strings.ErrorOwner}</div>
       <br/>
       <PeoplePicker 
       required={false}
      
      context={this.props.context as any}
      titleText={strings.Members}
      personSelectionLimit={10} 
      showtooltip={false} 
      disabled={false}
      onChange={this._getMembers.bind(this)}
      showHiddenInUI={false}
      ensureUser={true}
      principalTypes={[PrincipalType.User]}
      resolveDelay={1000} />
      <br/>

       <Toggle  inlineLabel onChange={this._Disclaimer.bind(this)} className={styles.tg}/> <a className={ styles.link } rel="noopener noreferrer" data-interception="off"  target="_blank" href={this.state.DisclaimerUrl}> {strings.Disclaimer}</a>
        <br/>
       <br/>
       <div className={styles.Btn}><DefaultButton title={strings.REQUEST_IT}  iconProps={ApproveIcon} text={strings.REQUEST_IT} onClick={this._Request.bind(this)} ></DefaultButton></div> 
     </div>
     <div  style={{ display: (this.state.finish? 'block' : 'none') }} >
     <MessageBar
           messageBarType={MessageBarType.warning}
           isMultiline={true}>
        {strings.ValidationMessage}
        </MessageBar><br/>
     </div>

     <div  style={{ display: (this.state.NotOnboarded? 'block' : 'none') }} >
     <MessageBar
           messageBarType={MessageBarType.error}
           isMultiline={true}>
        {strings.NotOnboardedMessage}
        </MessageBar><br/>
     </div>
     
      </div>
    );
  }
}
