import * as React from 'react';
import styles from './MyTeamsShareBox.module.scss';
import { IMyTeamsShareBoxProps } from './IMyTeamsShareBoxProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { DetailsList, DetailsListLayoutMode, Selection, IColumn } from 'office-ui-fabric-react/lib/DetailsList';



import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { _Web } from '@pnp/sp/webs/types';
import { Icon } from 'office-ui-fabric-react/lib/Icon';


const webUrl = `${window.location.protocol}//${window.location.hostname}/sites/ShareBOX`;
const SBX = new _Web(webUrl);

export interface IControls
{
  items : iDetailTeamSBX[];
  empty : boolean;
}

export interface iDetailTeamSBX {
  name: string;
  url :string;
  owner : string;
}

export default class MyTeamsShareBox extends React.Component<IMyTeamsShareBoxProps, IControls> {

  public componentWillMount() {     this._getUserGSBX();  }
  
  private async _getUserGSBX(){

    const profile = await sp.profiles.myProperties.get();
    var props = {};
    profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
    profile.userProperties = props;

    const Own: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Contains><FieldRef Name='Owners'/> <Value Type='Text'>"+ profile.DisplayName + "</Value></Contains><IsNull><FieldRef Name='DeletionDate' /></IsNull></And></Where></Query></View>"  };
    const Mem: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Contains><FieldRef Name='Members'/> <Value Type='Text'>"+ profile.DisplayName + "</Value></Contains><IsNull><FieldRef Name='DeletionDate' /></IsNull></And></Where></Query></View>"  };
     
    let OwnList : any[] = await SBX.lists.getByTitle("REF_TEAM_SHAREBOX").getItemsByCAMLQuery(Own); 
    let MemList : any[] = await SBX.lists.getByTitle("REF_TEAM_SHAREBOX").getItemsByCAMLQuery(Mem); 

    const _allItems : iDetailTeamSBX[] = [];

    for (let i = 0; i < OwnList.length; i++) {
      _allItems.push({
        name: OwnList[i]["Title"],
        url: OwnList[i]["TeamShareBOXUrl"],
        owner: 'block'
        
      });
    }

    for (let i = 0; i < MemList.length; i++) {

      let found = false;
      for (let j = 0; j < _allItems.length; j++) {
        if(MemList[i]["Title"] == _allItems[j].name) {found = true; break;}
      }
      
      if(!found){
      _allItems.push({
        name: MemList[i]["Title"],
        url: MemList[i]["TeamShareBOXUrl"],
        owner: 'none'
      });
    }
    }
    this.setState({items : _allItems});

    if(_allItems.length == 0){
      this.setState({empty: true})
    }else{this.setState({empty: false})}

   
  }
 
  constructor(props: IMyTeamsShareBoxProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });
  
    this.state = {  
      empty:true,
      items : []
    };

  }
 
  public  render(): React.ReactElement<IMyTeamsShareBoxProps> {

    return (
      <div className={ styles.myTeamsShareBox } style={{ display: (this.state.empty ? 'none' : 'block') }}>
        <table cellPadding='0' cellSpacing='0' style={{width:'80%'}}>
          <tr><td style={{width:'170', verticalAlign:'top'}}>
           <img width="150" src={this.props.context.pageContext.web.absoluteUrl + "/siteAssets/MyTeamShareBOXsIcon.png"} /> 
        </td>
        <td>
        <h3>My Team ShareBOX</h3>
        <table cellPadding='0' cellSpacing='0' style={{width:'100%'}}>
        {this.state.items.map(TBX => (  
          <tr>
            <td className={styles.tdStyle1}><Icon  iconName="LocalAdmin"  className={styles.Icon} style={{ display: TBX.owner }}/></td>
            <td className={styles.tdStyle}><a className={ styles.link } rel="noopener noreferrer" data-interception="off"  target='_blank' href={TBX.url}>{TBX.name}</a></td>
          </tr>  
        ))}  
        </table>
        </td></tr>
        </table>
      </div>
    );
  }
}
