/* tslint:disable */
require("./MyTeamsShareBox.module.css");
const styles = {
  myTeamsShareBox: 'myTeamsShareBox_96cc958d',
  link: 'link_96cc958d',
  Icon: 'Icon_96cc958d',
  tdStyle: 'tdStyle_96cc958d',
  tdStyle1: 'tdStyle1_96cc958d'
};

export default styles;
/* tslint:enable */