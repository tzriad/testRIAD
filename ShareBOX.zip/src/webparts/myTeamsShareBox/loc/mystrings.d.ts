declare interface IMyTeamsShareBoxWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MyTeamsShareBoxWebPartStrings' {
  const strings: IMyTeamsShareBoxWebPartStrings;
  export = strings;
}
