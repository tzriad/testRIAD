define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PendingMessage":"Vous avez déjà une demande de suppression en cours.",
    "NoShareBOX":"Vous n'avez pas de ShareBOX",
    "Title" : "Titre",
    "NewTitle" : "Nouveau titre",
    "REQUIRED":"Obligatoire",
    "REQUESTDELETION":"DEMANDER LA SUPPRESSION",
    "JUSTIFICATION":"JUSTIFICATION",
    "FinalMessage": "Votre demande est prise en compte"
  }
});