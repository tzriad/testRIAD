define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "User":"User",
  "Manager": "Manager",
  "Company":"Company",
  "JUSTIFICATION":"JUSTIFICATION",
  "REQUESTDELETION":"REQUEST DELETION",
  "ValidationMessage":"Your deletion request has been taken into account and will be processed once validated by your local security team",
  "NoShareBOX":"You do not have a ShareBOX to delete.",
  "PendingMessage":"You already have a pending deletion request.",
  "NotOnboardedMessage":"You entity is not yet onboarded.",
  }
});