define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "Disclaimer":"Verplicht akkoord te gaan met de disclaimer om aan te vragen",
    "REQUEST_IT":"Aanvragen",
    "ValidationMessage":"Uw aanvraag voor ShareBOX is goed ontvangen en zal spoedig behandeld worden",
    "AlreadyMessage":"U beschikt al over een ShareBOX.",
    "PendingMessage":"U heeft al een lopende aanvraag voor een ShareBOX.",
    "NotOnboardedMessage":"Uw entiteit is nog niet ingestapt.",
    "Describe":"Beschrijf uw behoefte",
    "User":"Gebruiker",
    "Manager":"Manager",
    "Company":"Bedrijf",
    "Country":"Land",
    "REQUIRED":"VERPLICHT"
  }
});