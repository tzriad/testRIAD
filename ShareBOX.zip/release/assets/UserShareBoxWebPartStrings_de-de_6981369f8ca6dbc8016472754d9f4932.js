define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "Disclaimer":"Obligatorische Zustimmung zum Haftungsausschluss, um Ihre ShareBOX anzufordern",
    "REQUEST_IT":"FORDERE ES AN",
    "ValidationMessage":"Deine ShareBOX wird gerade erstellt.",
    "AlreadyMessage":"Du nutzt bereits eine ShareBOX.",
    "PendingMessage":"Du hast bereits eine Anfrage gestellt, diese wird gerade geprüft.",
    "NotOnboardedMessage":"Deine Gesellschaft nutzt ShareBOX noch nicht.",
    "Describe":"Beschreiben Sie Ihre Bedürfnisse",
    "User":"Benutzer",
    "Manager":"Manager",
    "Company":"Unternehmen",
    "Country":"Land",
    "REQUIRED":"ERFORDERLICH"
  }
});