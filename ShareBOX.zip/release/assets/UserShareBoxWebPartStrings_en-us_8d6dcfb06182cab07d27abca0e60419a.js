define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "Disclaimer":"Mandatory agreement of the disclaimer in order to request",
    "REQUEST_IT":"REQUEST IT",
    "ValidationMessage":"Your ShareBOX request has been taken into account and will be provisioned quickly",
    "AlreadyMessage":" You already have a ShareBOX.",
    "PendingMessage":"You already have a pending request.",
    "NotOnboardedMessage":"You entity is not yet onboarded.",
    "Describe":"Describe your need",
    "User":"User",
    "Manager":"Manager",
    "Company":"Company",
    "Country": "Country",
    "REQUIRED":"REQUIRED"
  }
});