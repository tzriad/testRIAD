define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "User":"Utilisateur",
    "Manager":"Responsable hiérarchique",
    "Company":"Entité",
    "Country": "Pays",
    "Title":"Titre",
    "Describe":"Décrivez votre besoin",
    "Owners":"Propriétaires",
    "Members":"Membres",
    "Disclaimer":"Confirmez l'accepation des conditions d'utilisation avant d'effectuer votre demande",
    "REQUEST_IT":"DEMANDEZ VOTRE SHAREBOX",
    "ValidationMessage":"Votre requête a bien été prise en compte.",
    "NotOnboardedMessage":"Votre entité n'est pas encore configurée pour utiliser l'application",
    "ErrorOwner":"Merci de renseigner deux propriétaires ",
    "REQUIRED":"Obligatoire"
  }
});