define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PendingMessage":"You already have a pending  request.",
    "NoShareBOX":"You do not have a ShareBOX to delete.",    
    "Title" : "Title",
    "NewTitle" : "New title",
    "REQUIRED":"REQUIRED",
    "REQUESTRENAME":"Confirm rename",
    "FinalMessage": "Your request is saved and will be processed."
  }
});