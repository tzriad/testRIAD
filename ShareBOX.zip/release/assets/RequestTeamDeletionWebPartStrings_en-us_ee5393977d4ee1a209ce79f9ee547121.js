define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PendingMessage":"You already have a pending deletion request.",
    "NoShareBOX":"You do not have a ShareBOX to delete.",    
    "Title" : "Title",
    "NewTitle" : "New title",
    "REQUIRED":"REQUIRED",
    "JUSTIFICATION":"JUSTIFICATION",
    "REQUESTDELETION":"REQUEST DELETION",
    "FinalMessage": "Your request is saved and will be processed."
  }
});