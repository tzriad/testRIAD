define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PendingMessage":"Vous avez déjà une demande en cours.",
    "NoShareBOX":"Vous n'avez pas de ShareBOX",
    "Title" : "Titre",
    "NewTitle" : "Nouveau titre",
    "REQUIRED":"Obligatoire",
    "REQUESTRENAME":"Confirmer le renommage",
    "FinalMessage": "Votre demande est prise en compte"
  }
});