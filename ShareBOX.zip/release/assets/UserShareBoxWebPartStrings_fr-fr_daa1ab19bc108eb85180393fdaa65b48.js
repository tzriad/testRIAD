define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "Disclaimer":"Confirmez l'acceptation des conditions d'utilisation avant d'effectuer votre demande",
    "REQUEST_IT":"DEMANDEZ VOTRE SHAREBOX",
    "ValidationMessage":"Votre requête a bien été prise en compte.",
    "AlreadyMessage":"Vous avez déjà une ShareBOX",
    "PendingMessage":"Vous avez déjà une demande en cours de traitement",
    "NotOnboardedMessage":"Votre entité n'est pas encore configurée pour utiliser l'application",
    "Describe":"Décrivez votre besoin",
    "User":"Utilisateur",
    "Manager":"Responsable hiérarchique",
    "Company":"Entité",
    "Country": "Pays",
    "REQUIRED":"Obligatoire"
  }
});