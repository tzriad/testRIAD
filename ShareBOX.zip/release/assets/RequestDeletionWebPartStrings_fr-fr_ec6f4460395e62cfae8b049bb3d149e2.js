define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "User":"Utilisateur",
    "Manager":"Responsable hiérarchique",
    "Company":"Entité",
  "JUSTIFICATION":"JUSTIFICATION",
  "REQUESTDELETION":"DEMANDER LA SUPPRESSION",
  "ValidationMessage":"Votre demande de suppression a bien été prise en compte.",
  "NoShareBOX":"Vous n'avez pas de ShareBOX",
  "PendingMessage":"Vous avez déjà une demande de suppression en cours.",
  "NotOnboardedMessage":"Votre entité n'est pas encore configurée pour utiliser l'application",
  }
});