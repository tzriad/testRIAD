define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "User":"User",
    "Manager": "Manager",
    "Company":"Company",
    "Country": "Country",
    "Title":"Title",
    "Describe":"Describe your need",
    "Owners":"Owners",
    "Members":"Members",
    "Disclaimer":"Mandatory agreement of the disclaimer in order to request",
    "REQUEST_IT":"REQUEST IT",
    "ValidationMessage":"Your Team ShareBOX request has been taken into account and will be provisioned quickly.",
    "NotOnboardedMessage":"You entity is not yet onboarded.",
    "ErrorOwner":"YOU MUST PROVIDE AT LEAST TWO OWNERS",
    "REQUIRED":"REQUIRED"
  }
});