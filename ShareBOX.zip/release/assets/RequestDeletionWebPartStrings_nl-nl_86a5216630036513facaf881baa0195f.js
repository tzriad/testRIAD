define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "User":"Gebruiker",
  "Manager": "Manager",
  "Company":"Bedrijf",
  "JUSTIFICATION":"REDEN",
  "REQUESTDELETION":"VERWIJDERING Aanvragen",
  "ValidationMessage":"Uw aanvraag is goed ontvangen",
  "NoShareBOX":"You do not have a ShareBOX to delete.",
  "PendingMessage":"U heeft al een lopende aanvraag voor een ShareBOX.",
  "NotOnboardedMessage":"Uw entiteit is nog niet ingestapt.",
  }
});