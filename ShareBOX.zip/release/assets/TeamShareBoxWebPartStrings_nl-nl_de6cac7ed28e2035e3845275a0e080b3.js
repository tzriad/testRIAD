define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "User":"Gebruiker",
    "Manager": "Manager",
    "Company":"Bedrijf",
    "Country":"Land",
    "Title":"Titel",
    "Describe":"Beschrijf uw behoefte",
    "Owners":"Eigenaars (Owners)",
    "Members":"Leden (Members)",
    "Disclaimer":"Verplicht akkoord te gaan met de disclaimer om aan te vragen",
    "REQUEST_IT":"Aanvragen",
    "ValidationMessage":"Uw aanvraag voor ShareBOX is goed ontvangen en zal spoedig behandeld worden.",
    "NotOnboardedMessage":"Uw entiteit is nog niet ingestapt.",
    "ErrorOwner":"U MOET TEN MINSTE TWEE EIGENAARS (OWNERS) VOORZIEN",
    "REQUIRED":"VERPLICHT"
  }
});