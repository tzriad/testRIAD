define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "User":"Benutzer",
    "Manager":"Manager",
    "Company":"Unternehmen",
    "Country":"Land",
    "Title":"Titel",
    "Describe":"Beschreiben Sie Ihre Bedürfnisse",
    "Owners":"Eigentümer",
    "Members":"Mitglieder",
    "Disclaimer":"Obligatorische Zustimmung zum Haftungsausschluss, um Ihre ShareBOX anzufordern",
    "REQUEST_IT":"FORDERE ES AN",
    "ValidationMessage":"Deine ShareBOX wird gerade erstellt.",
    "NotOnboardedMessage":"Deine Gesellschaft nutzt ShareBOX noch nicht.",
    "ErrorOwner":"SIE MÜSSEN MINDESTENS ZWEI EIGENTÜMER ANGEBEN",
    "REQUIRED":"ERFORDERLICH"
  }
});