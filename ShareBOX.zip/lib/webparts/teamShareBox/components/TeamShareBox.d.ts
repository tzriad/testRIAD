import * as React from 'react';
import { ITeamShareBoxProps } from './ITeamShareBoxProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    User: string;
    AccountName: string;
    owners: any[];
    members: any[];
    Manager: number;
    ManagerName: string;
    Justification: string;
    Company: string;
    Country: string;
    Disclaimer: boolean;
    errorDisclaimer: string;
    show: string;
    finish: boolean;
    hasShareBox: boolean;
    pendingRequest: boolean;
    NotOnboarded: boolean;
    SecTeamEmail: number;
    TeamShareBOXEnabled: boolean;
    Title: string;
    errorOwner: string;
    errorTitle: string;
    errorDesc: string;
    NbInternalOwner: number;
    ManagerApproval: boolean;
    SecurityApproval: boolean;
    DisclaimerUrl: string;
}
export default class TeamShareBox extends React.Component<ITeamShareBoxProps, IControls> {
    componentWillMount(): void;
    constructor(props: ITeamShareBoxProps);
    private _getUserProfileInformation;
    private _Disclaimer;
    private _decriptionchange;
    private _TitleonChange;
    private _getOwners;
    private _getMembers;
    private _Request;
    render(): React.ReactElement<ITeamShareBoxProps>;
}
//# sourceMappingURL=TeamShareBox.d.ts.map