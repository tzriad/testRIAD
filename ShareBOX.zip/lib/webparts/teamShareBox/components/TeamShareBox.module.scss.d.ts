declare const styles: {
    container: string;
    Btn: string;
    tg: string;
    errorMessage: string;
    link: string;
};
export default styles;
//# sourceMappingURL=TeamShareBox.module.scss.d.ts.map