import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface ITeamShareBoxProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=ITeamShareBoxProps.d.ts.map