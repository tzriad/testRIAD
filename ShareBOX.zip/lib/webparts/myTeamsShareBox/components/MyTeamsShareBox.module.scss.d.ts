declare const styles: {
    myTeamsShareBox: string;
    link: string;
    Icon: string;
    tdStyle: string;
    tdStyle1: string;
};
export default styles;
//# sourceMappingURL=MyTeamsShareBox.module.scss.d.ts.map