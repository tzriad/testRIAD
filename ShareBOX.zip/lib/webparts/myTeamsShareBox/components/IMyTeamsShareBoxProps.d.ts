import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IMyTeamsShareBoxProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IMyTeamsShareBoxProps.d.ts.map