import * as React from 'react';
import { IMyTeamsShareBoxProps } from './IMyTeamsShareBoxProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    items: iDetailTeamSBX[];
    empty: boolean;
}
export interface iDetailTeamSBX {
    name: string;
    url: string;
    owner: string;
}
export default class MyTeamsShareBox extends React.Component<IMyTeamsShareBoxProps, IControls> {
    componentWillMount(): void;
    private _getUserGSBX;
    constructor(props: IMyTeamsShareBoxProps);
    render(): React.ReactElement<IMyTeamsShareBoxProps>;
}
//# sourceMappingURL=MyTeamsShareBox.d.ts.map