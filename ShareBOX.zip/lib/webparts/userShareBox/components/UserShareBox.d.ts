import * as React from 'react';
import { IUserShareBoxProps } from './IUserShareBoxProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    User: string;
    AccountName: string;
    Email: string;
    Manager: number;
    ManagerName: string;
    Justification: string;
    Company: string;
    Country: string;
    Disclaimer: boolean;
    errorDisclaimer: string;
    show: string;
    finish: boolean;
    hasShareBox: boolean;
    pendingRequest: boolean;
    NotOnboarded: boolean;
    errorDesc: string;
    ShareBOXUrl: string;
    SecTeamEmail: number;
    ManagerApproval: boolean;
    SecurityApproval: boolean;
    DisclaimerUrl: string;
}
export default class UserShareBox extends React.Component<IUserShareBoxProps, IControls> {
    componentWillMount(): void;
    constructor(props: IUserShareBoxProps);
    private _getUserProfileInformation;
    private _Disclaimer;
    private _Request;
    private _decriptionchange;
    render(): React.ReactElement<IUserShareBoxProps>;
}
//# sourceMappingURL=UserShareBox.d.ts.map