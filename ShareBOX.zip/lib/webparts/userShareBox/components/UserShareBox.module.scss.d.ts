declare const styles: {
    container: string;
    Btn: string;
    tg: string;
    errorMessage: string;
    link: string;
};
export default styles;
//# sourceMappingURL=UserShareBox.module.scss.d.ts.map