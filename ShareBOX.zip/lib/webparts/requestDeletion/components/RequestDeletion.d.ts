import * as React from 'react';
import { IRequestDeletionProps } from './IRequestDeletionProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    User: string;
    AccountName: string;
    Email: string;
    Manager: number;
    ManagerName: string;
    Justification: string;
    Company: string;
    Disclaimer: boolean;
    errorDisclaimer: string;
    RequestForm: boolean;
    finish: boolean;
    hasShareBox: boolean;
    ShareBOXUrl: string;
    pendingRequest: boolean;
    NotOnboarded: boolean;
    SecTeamEmail: number;
}
export default class RequestDeletion extends React.Component<IRequestDeletionProps, IControls> {
    componentWillMount(): void;
    constructor(props: IRequestDeletionProps);
    private _getUserProfileInformation;
    private _decriptionchange;
    private _Request;
    render(): React.ReactElement<IRequestDeletionProps>;
}
//# sourceMappingURL=RequestDeletion.d.ts.map