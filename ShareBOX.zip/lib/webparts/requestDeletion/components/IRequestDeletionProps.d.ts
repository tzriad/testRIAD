import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IRequestDeletionProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IRequestDeletionProps.d.ts.map