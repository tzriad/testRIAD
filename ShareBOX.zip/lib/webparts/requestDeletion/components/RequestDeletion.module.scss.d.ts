declare const styles: {
    container: string;
    Btn: string;
    tg: string;
};
export default styles;
//# sourceMappingURL=RequestDeletion.module.scss.d.ts.map