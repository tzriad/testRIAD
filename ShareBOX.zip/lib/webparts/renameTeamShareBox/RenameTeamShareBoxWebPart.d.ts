import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IRenameTeamShareBoxWebPartProps {
    description: string;
}
export default class RenameTeamShareBoxWebPart extends BaseClientSideWebPart<IRenameTeamShareBoxWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=RenameTeamShareBoxWebPart.d.ts.map