declare const styles: {
    container: string;
    errorMessage: string;
    Btn: string;
};
export default styles;
//# sourceMappingURL=RenameTeamShareBox.module.scss.d.ts.map