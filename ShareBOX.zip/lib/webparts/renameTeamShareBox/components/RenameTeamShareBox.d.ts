import * as React from 'react';
import { IRenameTeamShareBoxProps } from './IRenameTeamShareBoxProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    OldTitle: string;
    NewTitle: string;
    TeamShareBOXUrl: string;
    pendingRequest: boolean;
    Owner: boolean;
    FoundTeamShareBOX: boolean;
    errorTitle: boolean;
    Finish: boolean;
    DisplayDetails: boolean;
}
export default class RenameTeamShareBox extends React.Component<IRenameTeamShareBoxProps, IControls> {
    componentWillMount(): void;
    constructor(props: IRenameTeamShareBoxProps);
    private _getUserGSBX;
    private _NewNamechange;
    private _MyTeamsonChange;
    private _Request;
    render(): React.ReactElement<IRenameTeamShareBoxProps>;
}
//# sourceMappingURL=RenameTeamShareBox.d.ts.map