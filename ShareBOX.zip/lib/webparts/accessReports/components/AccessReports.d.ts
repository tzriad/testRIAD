import * as React from 'react';
import { IAccessReportsProps } from './IAccessReportsProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    Url: string;
    AccountName: string;
}
export default class AccessReports extends React.Component<IAccessReportsProps, IControls> {
    componentWillMount(): void;
    constructor(props: IAccessReportsProps);
    private _getUserProfileInformation;
    render(): React.ReactElement<IAccessReportsProps>;
}
//# sourceMappingURL=AccessReports.d.ts.map