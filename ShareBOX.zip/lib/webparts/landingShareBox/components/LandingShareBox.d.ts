import * as React from 'react';
import { ILandingShareBoxProps } from './ILandingShareBoxProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    User: string;
    AccountName: string;
    DeletionDate: string;
    pendingRequest: boolean;
    NotOnboarded: boolean;
    HasSharebox: boolean;
    RequestForm: boolean;
    ShareBOXUrl: string;
    TeamShareBOXEnabled: boolean;
}
export default class LandingShareBox extends React.Component<ILandingShareBoxProps, IControls> {
    componentWillMount(): void;
    constructor(props: ILandingShareBoxProps);
    private _getUserProfileInformation;
    render(): React.ReactElement<ILandingShareBoxProps>;
}
//# sourceMappingURL=LandingShareBox.d.ts.map