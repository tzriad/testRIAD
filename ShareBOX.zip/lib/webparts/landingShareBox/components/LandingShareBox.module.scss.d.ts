declare const styles: {
    container: string;
    OpCoMessage: string;
    InnerOpCoMessage: string;
    leftPane: string;
    rightPane: string;
};
export default styles;
//# sourceMappingURL=LandingShareBox.module.scss.d.ts.map