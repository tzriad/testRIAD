import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface ILandingShareBoxProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=ILandingShareBoxProps.d.ts.map