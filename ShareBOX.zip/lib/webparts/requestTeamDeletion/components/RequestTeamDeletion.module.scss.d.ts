declare const styles: {
    container: string;
    errorMessage: string;
    Btn: string;
};
export default styles;
//# sourceMappingURL=RequestTeamDeletion.module.scss.d.ts.map