import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IRequestTeamDeletionProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IRequestTeamDeletionProps.d.ts.map