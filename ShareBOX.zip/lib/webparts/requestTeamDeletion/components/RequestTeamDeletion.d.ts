import * as React from 'react';
import { IRequestTeamDeletionProps } from './IRequestTeamDeletionProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    Title: string;
    TeamShareBOXUrl: string;
    pendingRequest: boolean;
    Justification: string;
    Owner: boolean;
    Owners: any[];
    FoundTeamShareBOX: boolean;
    Finish: boolean;
    errorDesc: boolean;
    DisplayDetails: boolean;
}
export default class RequestTeamDeletion extends React.Component<IRequestTeamDeletionProps, IControls> {
    componentWillMount(): void;
    constructor(props: IRequestTeamDeletionProps);
    private _getUserGSBX;
    private _DescChange;
    private _Request;
    private _MyTeamsonChange;
    render(): React.ReactElement<IRequestTeamDeletionProps>;
}
//# sourceMappingURL=RequestTeamDeletion.d.ts.map