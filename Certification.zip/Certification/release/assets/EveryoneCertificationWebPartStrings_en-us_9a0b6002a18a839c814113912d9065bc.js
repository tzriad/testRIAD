define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "DeleteSite" : "Delete this site",
  "ActiveSite" : "Active site",
  "PublicAccessLabel" : "Maintain site public access",
  "RevokeAccessLabel" : "Revoke site public access",
  "NoSponsor": "Not designated",
  "FormTitle" : "PUBLIC ACCESS / CERTIFICATION FORM",
  "CreationDate": "Creation date",
  "Usage":"Usage (GB)",
  "Sponsor":"Sponsor",
  "Owners":"Owners",
  "WarningMessage1": 'Your are one of the site owners. For compliance reasons you must certify once a year that you still need the public access for this site.',
  "WarningMessage2": 'Without a response from your side within 30 days, public access will be revoked.',
  "WarningMessage3": 'If this site is not used anymore and can be deleted, uncheck the "Active site" option, the site will be deleted.',
  "Certify":"CERTIFY",
  "PopupTitle":"Delete this site ?",
  "PopupMessage" : "Do you confirm that this site is not used anymore and can be deleted ?",
  "PopupButton1" :"Confirm",
  "PopupButton2" :"Cancel",
  "NotToYou":"Wait ! this certification request did not send to you.",
  "NotOwnerList" : "wait ! it looks like you are no longer one of the site owners.",
  "ValidationMessage": "certified public access to this site  at"
  }
});