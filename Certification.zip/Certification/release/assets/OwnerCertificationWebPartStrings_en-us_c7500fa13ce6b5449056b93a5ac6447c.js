define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "DeleteSite" : "Delete this site",
  "ActiveSite" : "Active site",
  "OwnerLabel" : "I'm site owner",
  "NotOwnerLabel" : "I'm not site owner anymore",
  "NoSponsor": "Not designated",
  "FormTitle" : "SITE OWNERS / CERTIFICATION FORM",
  "CreationDate": "Creation date",
  "Usage":"Usage (GB)",
  "Sponsor":"Sponsor",
  "Owners":"Owners",
  "WarningMessage1": 'Your are one of the site owners. For compliance reasons you must certify once a year that you still own the site.',
  "WarningMessage2": 'Without a response from your side within 30 days, your owner rights will be removed.',
  "WarningMessage3": 'If this site is not used anymore and can be deleted, uncheck the "Active site" option, the site will be deleted.',
  "Certify":"CERTIFY",
  "PopupTitle":"Delete this site ?",
  "PopupMessage" : "Do you confirm that this site is not used anymore and can be deleted ?",
  "PopupButton1" :"Confirm",
  "PopupButton2" :"Cancel",
  "NotToYou":"Wait ! this certification request did not send to you.",
  "NotOwnerList" : "wait ! it looks like you are no longer one of the site owners.",
  "ValidationMessage": "You certified your access to this site  at"
  }
});