define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "DeleteSite" : "Site à supprimer",
  "ActiveSite" : "Site actif",
  "PublicAccessLabel" : "Maintenir l'accès public du site",
  "RevokeAccessLabel" : "Révoquer l'accès public du site",
  "NoSponsor": "Not renseigné",
  "FormTitle" : "ACCES PUBLIC DU SITE / FORMULAIRE DE CERTIFICATION",
  "CreationDate": "Date de création",
  "Usage":"Volumétrie (GO)",
  "Sponsor":"Sponsor",
  "Owners":"Propriétaires",
  "WarningMessage1": 'Vous êtes un des propriétaires de ce site, dont l\'accès est public. Pour des raisons de conformité vous devez certifier une fois de maintenir ou pas cet accès public.',
  "WarningMessage2": 'Sans retour de votre part d\'ici 30 jours, L\'accès public sera révoqué.',
  "WarningMessage3": 'Si vous n\'utilisez plus ce site, merci de décocher la case "Site actif". Le site sera ainsi supprimé.',
  "Certify":"ENREGISTRER",
  "PopupTitle":"Supprimer ce site ?",
  "PopupMessage" : "Confirmez vous que ce site n'est plus utilisé et qu'il peut être supprimé ?",
  "PopupButton1" :"Confirmer",
  "PopupButton2" :"Annuler",
  "NotToYou":"Cette demande de certification nous vous est pas assignée",
  "NotOwnerList" : "Il semble que vous ne soyez plus propriétaire de ce site",
  "ValidationMessage": "a certifié l'accès public de ce site le "
  }
});