import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IEveryoneCertificationProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IEveryoneCertificationProps.d.ts.map