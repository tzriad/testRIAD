import * as React from 'react';
import { IEveryoneCertificationProps } from './IEveryoneCertificationProps';
import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
import "@pnp/sp/items";
import "@pnp/sp/lists";
export interface IControls {
    sponsor: string;
    url: string;
    siteId: string;
    creationDate: string;
    currentOwner: boolean;
    usage: string;
    owners: string;
    PublicAccess: boolean;
    activeSite: boolean;
    Certified: string;
    PublicAccessLabel: string;
    SiteLabel: string;
    myForm: boolean;
    displayError: boolean;
    validated: boolean;
    Confirmation: boolean;
    OwnerName: string;
}
export default class EveryoneCertification extends React.Component<IEveryoneCertificationProps, IControls> {
    constructor(props: IEveryoneCertificationProps);
    private Confirm;
    private Ignore;
    private hiddenWindow;
    private _logicLanding;
    private RevisionPublicAccess;
    private RevisionSite;
    private _Request;
    render(): React.ReactElement<IEveryoneCertificationProps>;
}
//# sourceMappingURL=EveryoneCertification.d.ts.map