declare const styles: {
    leftPan: string;
    rightPan: string;
    fullPan: string;
    TD: string;
    TD2: string;
    bg: string;
    bg2: string;
    tg: string;
    button: string;
    Icon: string;
    FormHeader: string;
};
export default styles;
//# sourceMappingURL=EveryoneCertification.module.scss.d.ts.map