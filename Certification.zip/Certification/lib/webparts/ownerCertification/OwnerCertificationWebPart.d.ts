import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IOwnerCertificationWebPartProps {
    description: string;
}
export default class OwnerCertificationWebPart extends BaseClientSideWebPart<IOwnerCertificationWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=OwnerCertificationWebPart.d.ts.map