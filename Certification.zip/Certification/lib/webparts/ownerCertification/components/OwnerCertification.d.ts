import * as React from 'react';
import { IOwnerCertificationProps } from './IOwnerCertificationProps';
import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
import "@pnp/sp/items";
import "@pnp/sp/lists";
export interface IControls {
    sponsor: string;
    url: string;
    siteId: string;
    creationDate: string;
    currentOwner: boolean;
    usage: string;
    owners: string;
    SiteOwner: boolean;
    activeSite: boolean;
    Certified: string;
    OwnerLabel: string;
    SiteLabel: string;
    myForm: boolean;
    displayError: boolean;
    validated: boolean;
    Confirmation: boolean;
}
export default class OwnerCertification extends React.Component<IOwnerCertificationProps, IControls> {
    constructor(props: IOwnerCertificationProps);
    private Confirm;
    private Ignore;
    private hiddenWindow;
    private _logicLanding;
    private RevisionOwner;
    private RevisionSite;
    private _Request;
    render(): React.ReactElement<IOwnerCertificationProps>;
}
//# sourceMappingURL=OwnerCertification.d.ts.map