import * as React from 'react';
import styles from './EveryoneCertification.module.scss';
import { IEveryoneCertificationProps } from './IEveryoneCertificationProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as strings from 'EveryoneCertificationWebPartStrings';


import { Dialog,DialogType,DialogFooter } from 'office-ui-fabric-react/lib/Dialog'; 
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { Link, MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';

import { sp } from "@pnp/sp";

import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import "@pnp/sp/items";  
import "@pnp/sp/lists";
import { UrlQueryParameterCollection } from '@microsoft/sp-core-library';
import { ICamlQuery } from "@pnp/sp/lists";
import { PrimaryButton } from '@microsoft/office-ui-fabric-react-bundle';
import * as moment from 'moment';

export interface IControls
{
  sponsor: string;  
  url:string ;
  siteId : string;
  creationDate:string;
  currentOwner :boolean;
  usage : string;
  owners: string ;  
  PublicAccess : boolean;
  activeSite : boolean;
  Certified:string;
  PublicAccessLabel:string;
  SiteLabel:string;
  myForm: boolean;
  displayError: boolean;
  validated : boolean;
  Confirmation : boolean;
  OwnerName:string;
}

const ApproveIcon: IIconProps = { iconName: 'Accept' };

export default class EveryoneCertification extends React.Component<IEveryoneCertificationProps, IControls> {

  constructor(props: IEveryoneCertificationProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      sponsor: '',  
      url:'',
      creationDate:'',
      usage:'',
      owners: '',  
      siteId : '',
      currentOwner:true,
      PublicAccess : true,
      activeSite:true,
      Certified :'',
      PublicAccessLabel:'',
      SiteLabel:'',
      myForm : false,
      displayError: false,
      validated: false,
      Confirmation: false,
      OwnerName:''
    };  

    this._logicLanding();
  }  
 
  private Confirm(){
    this.setState({activeSite:false});
    this.setState({Confirmation:false});
    this.setState({SiteLabel : strings.DeleteSite});
  }

  private Ignore(){
    this.setState({Confirmation:false});
    this.setState({activeSite:true});
    this.setState({SiteLabel : strings.ActiveSite});
  }

  private hiddenWindow(){
    this.setState({Confirmation:true});
  }


  private  async _logicLanding(){
   // try{
    const myprofile = await sp.profiles.myProperties.get();
    let result = await sp.web.ensureUser(myprofile.Email);

    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
     if(queryParameters.getValue("UserID")){
      var UserID : number = parseInt(queryParameters.getValue("UserID"));

      const userRequest = await sp.web.lists.getByTitle("PublicAccess_Certification").items.getById(UserID).get();
      console.log(userRequest);
      var owner : number = parseInt(userRequest["OwnerId"]);
      this.setState({url : userRequest["Title"]});
      var SiteID : number = parseInt(userRequest["SiteID"]);

      if(userRequest["Status"] == "Revoke public access")
      {
        this.setState({PublicAccess : false});
        this.setState({PublicAccessLabel : strings.RevokeAccessLabel});
      }else {
        this.setState({PublicAccess : true});
        this.setState({PublicAccessLabel : strings.PublicAccessLabel});
      }

    if(userRequest["SiteStatus"] == "Active site")
      {
        this.setState({activeSite : true});
        this.setState({SiteLabel : strings.ActiveSite});
      }else {
        this.setState({activeSite : false});
        this.setState({SiteLabel : strings.DeleteSite});
      }


      const SiteRequest = await sp.web.lists.getByTitle("PORTFOLIO").items.getById(SiteID).get();

      this.setState({usage : SiteRequest["Usage"]});
      let createdformat:string =  moment(SiteRequest["CreationDate"]).format("DD/MM/YYYY");
      this.setState({creationDate :createdformat});

      if(SiteRequest["SponsorId"] != null)
       {  
         let sponsor = await sp.web.getUserById(parseInt(SiteRequest["SponsorId"])).get();
         this.setState({sponsor : sponsor.Title});
       }else{
        this.setState({sponsor : strings.NoSponsor});
       }

    
           
            let htmlOwner ="";
            await Promise.all(SiteRequest["OwnersId"].map(async (element)=>{
                 let user = await sp.web.getUserById(parseInt(element)).get();
                 htmlOwner += user.Title +";";
                 this.setState({owners : htmlOwner});
            }));


      if(owner != result.data.Id)   // pas pour l'utilisateur courant
            {
              this.setState({myForm : false});
              this.setState({displayError : true});
              this.setState({currentOwner : true});
              return;
            }else{ 
              let found  =false;
              for(var i = 0; i < SiteRequest["OwnersId"].length; i++)
              { console.log(SiteRequest["OwnersId"][i]);
                if(SiteRequest["OwnersId"][i] ==result.data.Id)
                {
                  found = true;
                }
              }
            if(found == false)  // pas dans la liste des Owners
            {
              this.setState({currentOwner : false});
              this.setState({myForm : false});
              this.setState({displayError : false});
              return;
            }
          }

          //get all other results from the same site to check
          const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Eq> <FieldRef Name='SiteID'/> <Value Type='Text'>" + userRequest["SiteID"] + "</Value></Eq><IsNotNull><FieldRef Name='Certified' /></IsNotNull></And></Where></Query><RowLimit>1</RowLimit></View>"  };
          const result2  = await sp.web.lists.getByTitle("PublicAccess_Certification").select("Owner","Certified","Status").expand("Owner").getItemsByCAMLQuery(q);
         
          if(result2.length>0)
          {
            let certifiedformat:string =  moment(result2[0]["Certified"]).format("DD/MM/YYYY");
            let Certifier = await sp.web.getUserById(parseInt(result2[0]["OwnerId"])).get();
            this.setState({Certified : certifiedformat});
            this.setState({OwnerName : Certifier.Title});
            this.setState({PublicAccess : (result2[0]["Status"] == "Maintain public access" ?true:false)});

            this.setState({validated : true});
            this.setState({currentOwner : true});
            this.setState({myForm : false});
            this.setState({displayError : false});
            return;
          }

            this.setState({myForm : true});

     }
     
    //}catch{}
  }


  private async RevisionPublicAccess(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
    var myCurrentDate = new Date().toLocaleDateString(); 
  if( checked) {
   this.setState({PublicAccess:true});
   this.setState({PublicAccessLabel:strings.PublicAccessLabel});
   this.setState({Certified:myCurrentDate});

 }else{
  this.setState({PublicAccess:false});
  this.setState({PublicAccessLabel:strings.RevokeAccessLabel});
  this.setState({Certified:''});
 }

  }


  private async RevisionSite(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
    var myCurrentDate = new Date().toLocaleDateString(); 
  if( checked) {
   this.setState({activeSite:true});
   this.setState({SiteLabel:strings.ActiveSite});
   this.setState({Confirmation:false});
 }else{
  this.setState({activeSite:false});
  this.setState({SiteLabel:strings.DeleteSite});
  this.setState({Confirmation:true});
 }

  }

  private async _Request(){
    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
    var UserID : number = parseInt(queryParameters.getValue("UserID"));

    let status = (this.state.PublicAccess ? "Maintain public access" : "revoke public access");
    let SiteStatus = (this.state.activeSite ? "Active site" : "Site to delete");

    sp.web.lists.getByTitle("PublicAccess_Certification").items.getById(UserID).update({
      Status: status,
      SiteStatus : SiteStatus,
      Certified:(new Date())
    });
    
    this.setState({Certified : new Date().toDateString()});
    this.setState({validated : true});
    this.setState({myForm : false});

  }



  public render(): React.ReactElement<IEveryoneCertificationProps> {
    return (
      <div>
      <header className={styles.FormHeader}><Icon iconName="Permissions"  className={styles.Icon}/>{strings.FormTitle}</header>
      <div  style={{ display: (this.state.myForm ? 'block' : 'none') }} >
       <div className={styles.bg}>
           {this.state.url}
        </div>
        <br/><br/>
       <div className={styles.leftPan}>
            <table>
              <tr>
                <td className={styles.TD}>{strings.CreationDate}</td>
                <td className={styles.TD2}>{this.state.creationDate}</td>
              </tr>
              <tr>
                <td className={styles.TD}>{strings.Usage}</td>
                <td className={styles.TD2}>{this.state.usage}</td>
              </tr>
              <tr>
                <td className={styles.TD}>{strings.Sponsor}</td>
                <td className={styles.TD2}>{this.state.sponsor}</td>
              </tr>
              <tr>
                <td className={styles.TD}>{strings.Owners}</td>
                <td className={styles.TD2}>
               {this.state.owners}
                </td>
              </tr>
            </table>
        </div>
        <div  className={styles.rightPan}>
            <div>
              <MessageBar messageBarType={MessageBarType.warning} isMultiline>
               {strings.WarningMessage1}<br/><br/>{strings.WarningMessage2}<br/><br/>{strings.WarningMessage3}
              </MessageBar>
            </div>
            <div>
              <br/><br/>
              <Toggle  inlineLabel onChange={this.RevisionPublicAccess.bind(this)} className={styles.tg}  checked={this.state.PublicAccess}/> <div>{this.state.PublicAccessLabel}</div>
              <br/>
              <Toggle  inlineLabel onChange={this.RevisionSite.bind(this)} className={styles.tg}  checked={this.state.activeSite}/> <div>{this.state.SiteLabel}</div>
            </div>
        </div>
        <div>
        <div  className={styles.fullPan}><DefaultButton  className={styles.button} iconProps={ApproveIcon} text={strings.Certify} onClick={this._Request.bind(this)} ></DefaultButton></div> 
        <Dialog
        hidden={!this.state.Confirmation}
        onDismiss={this.RevisionSite.bind(this)}
        dialogContentProps = {{type:DialogType.largeHeader, title:strings.PopupTitle, subText :strings.PopupMessage,}}
        >
          <DialogFooter>
            <PrimaryButton onClick={this.Confirm.bind(this)}  text={strings.PopupButton1} />
            <DefaultButton onClick={this.Ignore.bind(this)}  text={strings.PopupButton2} />
          </DialogFooter>
        </Dialog>
        </div>
      </div>
      <div  style={{ display: (this.state.displayError ? 'block' : 'none') }} >
        <MessageBar messageBarType={MessageBarType.error}>
        {strings.NotToYou}
        </MessageBar>
      </div>
      <div  style={{ display: (this.state.currentOwner ? 'none' : 'block') }} >
           <MessageBar messageBarType={MessageBarType.error}>
           {strings.NotOwnerList}
          </MessageBar>
      </div>
      <div  style={{ display: (this.state.validated ? 'block' : 'none') }} >
      <div className={styles.bg}>
           {this.state.url}
        </div>
        <br/><br/>
        <strong>{this.state.OwnerName}</strong> {strings.ValidationMessage} <strong>{this.state.Certified}</strong>
        <div className={styles.bg2}  style={{ display: (this.state.PublicAccess ? 'block' : 'none') }} > {strings.PublicAccessLabel}</div>
        <div className={styles.bg2}   style={{ display: (this.state.PublicAccess ? 'none' : 'block') }} >  {strings.RevokeAccessLabel}</div>

      </div>

      </div>
    );
  }
}
