/* tslint:disable */
require("./EveryoneCertification.module.css");
const styles = {
  leftPan: 'leftPan_6fd68dbc',
  rightPan: 'rightPan_6fd68dbc',
  fullPan: 'fullPan_6fd68dbc',
  TD: 'TD_6fd68dbc',
  TD2: 'TD2_6fd68dbc',
  bg: 'bg_6fd68dbc',
  bg2: 'bg2_6fd68dbc',
  tg: 'tg_6fd68dbc',
  button: 'button_6fd68dbc',
  Icon: 'Icon_6fd68dbc',
  FormHeader: 'FormHeader_6fd68dbc'
};

export default styles;
/* tslint:enable */