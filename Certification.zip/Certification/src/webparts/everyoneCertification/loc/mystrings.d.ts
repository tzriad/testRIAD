declare interface IEveryoneCertificationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  DeleteSite : string;
  ActiveSite : string;
  PublicAccessLabel : string;
  RevokeAccessLabel : string;
  NoSponsor: string;
  FormTitle : string;
  CreationDate: string;
  Usage:string;
  Sponsor:string;
  Owners:string;
  WarningMessage1: string;
  WarningMessage2: string;
  WarningMessage3: string;
  Certify:string;
  PopupTitle:string;
  PopupMessage : string;
  PopupButton1 :string;
  PopupButton2 :string;
  NotToYou:string;
  NotOwnerList : string;
  ValidationMessage: string;
}

declare module 'EveryoneCertificationWebPartStrings' {
  const strings: IEveryoneCertificationWebPartStrings;
  export = strings;
}
