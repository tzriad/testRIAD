/* tslint:disable */
require("./OwnerCertification.module.css");
const styles = {
  leftPan: 'leftPan_dfa1fcae',
  rightPan: 'rightPan_dfa1fcae',
  fullPan: 'fullPan_dfa1fcae',
  TD: 'TD_dfa1fcae',
  TD2: 'TD2_dfa1fcae',
  bg: 'bg_dfa1fcae',
  bg2: 'bg2_dfa1fcae',
  tg: 'tg_dfa1fcae',
  button: 'button_dfa1fcae',
  Icon: 'Icon_dfa1fcae',
  FormHeader: 'FormHeader_dfa1fcae'
};

export default styles;
/* tslint:enable */