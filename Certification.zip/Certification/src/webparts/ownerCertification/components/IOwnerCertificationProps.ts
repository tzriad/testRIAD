import { WebPartContext } from '@microsoft/sp-webpart-base';  
export interface IOwnerCertificationProps {
  description: string;
  context: WebPartContext; 
}
