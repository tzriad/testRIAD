define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "DeleteSite" : "Site à supprimer",
  "ActiveSite" : "Site toujours actif",
  "OwnerLabel" : "Je suis toujours propriétaire du site",
  "NotOwnerLabel" : "Je ne suis plus propriétaire du site",
  "NoSponsor": "Non renseigné",
  "FormTitle" : "PROPRIETAIRES DE SITE / FORMULAIRE DE CERTIFICATION",
  "CreationDate": "Date de création",
  "Usage":"Volumétrie (GO)",
  "Sponsor":"Sponsor",
  "Owners":"Propriétaires",
  "WarningMessage1": 'Vous êtes un des propriétaires de ce site. Pour des raisons de conformité vous devez certifier une fois par an que vous êtes toujours propriétaire du site.',
  "WarningMessage2": 'Sans retour de votre part d\'ici 30 jours, vos droits de propriétaires seront supprimés.',
  "WarningMessage3": 'Si vous n\'utilisez plus ce site, merci de décocher la case "Site toujours actif". Le site sera ainsi supprimé.',
  "Certify":"ENREGISTRER",
  "PopupTitle":"Supprimer ce site ?",
  "PopupMessage" : "Confirmez vous que ce site n'est plus utilisé et qu'il peut être supprimé ?",
  "PopupButton1" :"Confirmer",
  "PopupButton2" :"Annuler",
  "NotToYou":"Cette demande de certification ne vous est pas assignée",
  "NotOwnerList" : "Il semble que vous ne soyez plus propriétaire de ce site",
  "ValidationMessage": "Vous avez certifié l'accès à ce site le "
  }
});