declare interface ISiteAttributesExtensionApplicationCustomizerStrings {
  Title: string;
}

declare module 'SiteAttributesExtensionApplicationCustomizerStrings' {
  const strings: ISiteAttributesExtensionApplicationCustomizerStrings;
  export = strings;
}
