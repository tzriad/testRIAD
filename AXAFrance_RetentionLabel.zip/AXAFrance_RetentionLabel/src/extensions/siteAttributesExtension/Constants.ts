export class Constant 
{
    public static readonly REF_SITE_URL = "https://afatestretention.sharepoint.com/sites/AFA-LabellisationsDMO";
    public static readonly REF_LIST_ENTITIES = "REF_RETENTION_ENTITIES";
    public static readonly BusinessProperty = "BusinessRetention";
    public static readonly Entites_Site_URL = "https://afatestretention.sharepoint.com/sites/AFA-LabellisationsDMO";
 
}