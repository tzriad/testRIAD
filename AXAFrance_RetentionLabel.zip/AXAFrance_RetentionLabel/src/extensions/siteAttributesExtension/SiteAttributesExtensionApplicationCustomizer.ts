import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer,
  PlaceholderContent,
  PlaceholderName
} from '@microsoft/sp-application-base';
import * as ReactDOM from "react-dom";
import * as React from "react";

import * as strings from 'SiteAttributesExtensionApplicationCustomizerStrings';


const LOG_SOURCE: string = 'SiteAttributesExtensionApplicationCustomizer';

export interface ISiteAttributesExtensionApplicationCustomizerProperties {
  BusinessProperties: string;
  UserCompanyName : string;
}

import { ISiteManagePanelProps } from "../Component/ISiteManagePanelProps";
import { SiteManagePanel } from "../Component/SiteManagePanel";

export default class SiteAttributesExtensionApplicationCustomizer
  extends BaseApplicationCustomizer<ISiteAttributesExtensionApplicationCustomizerProperties> {

  private _rightPlaceholder: PlaceholderContent | undefined;

  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, `Initialized ${strings.Title}`);
    this.context.placeholderProvider.changedEvent.add(this, this._renderPlaceHolders);

    return Promise.resolve();
  }


  private _renderPlaceHolders(): void {

    if (!this._rightPlaceholder) {
      this._rightPlaceholder = this.context.placeholderProvider.tryCreateContent(
        PlaceholderName.Top,
        { onDispose: this.onDispose }
      );
  }

  if (!this._rightPlaceholder) { console.error("The expected placeholder (Right) was not found."); return;  }

//if(this.context.pageContext.web.permissions.hasAllPermissions())   //Only for owners
{
  const element: React.ReactElement<ISiteManagePanelProps>  = React.createElement(SiteManagePanel,
    {
      context: this.context
    } );


  if (this._rightPlaceholder.domElement) {
    ReactDOM.render(element, this._rightPlaceholder.domElement);
  }
}

}
}
