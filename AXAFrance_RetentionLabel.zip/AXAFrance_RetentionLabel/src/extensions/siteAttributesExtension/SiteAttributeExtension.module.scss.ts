/* tslint:disable */
require("./SiteAttributeExtension.module.css");
const styles = {

};

export default styles;
/* tslint:enable */