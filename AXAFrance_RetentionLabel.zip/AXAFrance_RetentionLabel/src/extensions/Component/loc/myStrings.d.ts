declare interface ISiteRetentionAttributeStrings {
  Title: string;
  Presentation:string;
  LabelDropDown: string;
  REQUIRED:string;
  CurrentValue : string;
  Save: string;
  Cancel : string;
}

declare module 'SiteRetentionAttributeStrings' {
  const strings: ISiteRetentionAttributeStrings;
  export = strings;
}
