import * as ReactDOM from "react-dom";
import * as React from "react";
import { Constant } from "../siteAttributesExtension/Constants";

require('sp-init'); 
require('microsoft-ajax'); 
require('sp-runtime'); 
require('sharepoint');

import * as _ from "lodash";

import { Dropdown, IDropdownOption, MessageBar, MessageBarType, PrimaryButton } from 'office-ui-fabric-react';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import {  Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import { ISiteManagePanelProps } from "./ISiteManagePanelProps";


import styles from './SiteManagePanel.module.scss';
import * as strings from 'SiteRetentionAttributeStrings';

import { sp } from "@pnp/sp";  

import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { _Web } from '@pnp/sp/webs/types';

export interface ISiteManagePanelState {
    showPanel: boolean;
    showBusiness :boolean;
    BusinessProperty: string;
    UserCompanyName : string;
    errorMetier:boolean;
    BusinessChoice: string;
    EntityOnboarded: boolean;
    EntityRefList : string;
}

const Entites_Site_URL = new _Web(Constant.Entites_Site_URL);
const REF_SITE_URL = new _Web(Constant.REF_SITE_URL);


const TagIcon: IIconProps = { iconName: 'Tag' };

const Metieroptions: IDropdownOption[] = [];

export class SiteManagePanel extends React.Component<ISiteManagePanelProps, ISiteManagePanelState> {
    componentWillMount(){this._getUserProfileInformation(); }
   
    private async _getUserProfileInformation(){
        const profile = await sp.profiles.myProperties.get();
        var props = {};
        profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
        profile.userProperties = props;

        this.setState({UserCompanyName: profile.userProperties["Office"]});

        const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><And><Contains><FieldRef Name='Names'/> <Value Type='Note'>" + profile.userProperties["Office"] + "</Value></Contains><Eq><FieldRef Name='Activ'/><Value Type='Boolean'>1</Value></Eq></And></Where></Query></View>"  };
 
        let refentity : any[] = await REF_SITE_URL.lists.getByTitle(Constant.REF_LIST_ENTITIES).getItemsByCAMLQuery(q); 
         if(refentity.length > 0)  { 
           this.setState({EntityOnboarded:true});
           this.setState({EntityRefList:refentity[0]["REF"] });

        // Charger les dropDown list
        var items : string[] = await Entites_Site_URL.lists.getByTitle(refentity[0]["REF"]).items.getAll();
        for (let item in items) { Metieroptions.push({key:items[item]["Title"], text:items[item]["Title"]});   }

        
        //get properties bag (if any) : "BusinessRetention"
        let properties = await sp.web.allProperties.get();

        if(properties[Constant.BusinessProperty] != null){
            this.setState({BusinessProperty : properties[Constant.BusinessProperty]});
            this.setState({showBusiness:true});
         }
        
        }else{
            this.setState({EntityOnboarded:false});
        }
    }

    constructor(props: ISiteManagePanelProps) {
        super(props);

        sp.setup({  spfxContext:  props.context   });
        this.state = {
            showPanel:false,
            showBusiness:false,
            BusinessProperty: '',
            UserCompanyName : '',
            BusinessChoice:'',
            errorMetier:false,
            EntityOnboarded:false,
            EntityRefList:''
        };
    }

    private _hideMenu = () => {
        this.setState({ showPanel: false });
      }

      private _save = () => {

        if(this.state.BusinessChoice == ""){ this.setState({errorMetier:true});return;}else{this.setState({errorMetier:false});}
        this.setSPProperty(Constant.BusinessProperty,this.state.BusinessChoice);
        this.setState({ showPanel: false });
      }

      private _show = () => {
        this.setState({ showPanel: true });
      }

      private _MetierChange(newValue: any): void {
        this.setState({BusinessChoice: newValue.key});
      if(newValue.key.length <3){
        this.setState({errorMetier:true});
      }else{this.setState({errorMetier:false});}
    
      }

    public render(): React.ReactElement<ISiteManagePanelProps> {
        return (
            <div className={styles.Top}>
                <DefaultButton onClick={this._show.bind(this)} iconProps={TagIcon}  className={styles.Icon}  />
 
                <Panel isOpen={this.state.showPanel}
                type={PanelType.custom}
                customWidth="400px"
                 onDismiss={this._hideMenu.bind(this)}
                 headerText={strings.Title}
                 isLightDismiss={true}>
                <br/><br/>
                <MessageBar  messageBarType={MessageBarType.warning} isMultiline={true}>
                     {strings.Presentation}
               </MessageBar><br/><br/>

                <Dropdown label={strings.LabelDropDown} required options={Metieroptions} onChanged={this._MetierChange.bind(this)} />
                <div className={styles.errorMessage} style={{ display: (this.state.errorMetier ? 'block' : 'none') }}>{strings.REQUIRED}</div>
  

                <div style={{ display: (this.state.showBusiness ? 'block' : 'none') }}>
                <br/>
                <MessageBar  messageBarType={MessageBarType.success} isMultiline={true}>
                {strings.CurrentValue} : <strong>{this.state.BusinessProperty}</strong>
                </MessageBar>
                </div>

                <br/><br/>
                <PrimaryButton onClick={this._save.bind(this)} className={styles.paddingBtn} >{strings.Save}</PrimaryButton>
                <DefaultButton onClick={this._hideMenu.bind(this)}>{strings.Cancel}</DefaultButton>

                </Panel>
            </div>
        );
    }

    public setSPProperty(name: string, value: string) { 
            let webProps;
            let clientContext:SP.ClientContext= new SP.ClientContext(this.props.context.pageContext.web.absoluteUrl);

            console.log(this.props.context.pageContext.web.absoluteUrl);
            const web = clientContext.get_web();
            webProps = web.get_allProperties();
            webProps.set_item(name, value);
            clientContext.load(web);
            web.update();
   
            clientContext.executeQueryAsync(function(sender,args){console.log("SUCCESS");}, function failed(sender,args){ console.log(args.get_message());});

        }

}

