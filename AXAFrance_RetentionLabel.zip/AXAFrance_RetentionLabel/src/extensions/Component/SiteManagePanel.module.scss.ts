/* tslint:disable */
require("./SiteManagePanel.module.css");
const styles = {
  paddingBtn: 'paddingBtn_3ba396f4',
  errorMessage: 'errorMessage_3ba396f4',
  Icon: 'Icon_3ba396f4',
  Top: 'Top_3ba396f4'
};

export default styles;
/* tslint:enable */