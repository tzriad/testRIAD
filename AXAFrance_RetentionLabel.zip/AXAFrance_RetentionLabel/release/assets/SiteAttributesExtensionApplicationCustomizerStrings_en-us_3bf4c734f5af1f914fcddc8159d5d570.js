define([], function() {
  return {
    "Title": "SiteAttributesExtensionApplicationCustomizer"
  }
});