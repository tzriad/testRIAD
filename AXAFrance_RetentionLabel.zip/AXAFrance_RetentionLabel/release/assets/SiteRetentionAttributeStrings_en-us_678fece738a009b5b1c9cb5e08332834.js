define([], function() {
  return {
    "Title": "SITE RETENTION MANAGEMENT",
    "Presentation":"Please select the label corresponding to your business. This will narrow down the retention fields to just your profession.",
    "LabelDropDown": "Select a value",
    "REQUIRED":"REQUIRED",
    "CurrentValue" : "Current value",
    "Save": "Save",
    "Cancel" : "Cancel",
    }
});