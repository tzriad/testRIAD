define([], function() {
  return {
    "Title": "GESTION DE LA RETENTION",
    "Presentation":"Merci de sélectionner le label correspendant à votre métier. Ce permettra de réduire les champs de rétention uniquement à votre profession.",
    "LabelDropDown": "Choisir une valeur",
    "REQUIRED":"Obligatoire",
    "CurrentValue" : "Valeur actuelle",
    "Save": "Enregistrer",
    "Cancel" : "Annuler",
    }
});