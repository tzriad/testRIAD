declare const styles: {};
export default styles;
//# sourceMappingURL=SiteAttributeExtension.module.scss.d.ts.map