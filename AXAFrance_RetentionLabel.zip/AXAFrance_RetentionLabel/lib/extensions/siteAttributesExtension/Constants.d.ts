export declare class Constant {
    static readonly REF_SITE_URL = "https://afatestretention.sharepoint.com/sites/AFA-LabellisationsDMO";
    static readonly REF_LIST_ENTITIES = "REF_RETENTION_ENTITIES";
    static readonly BusinessProperty = "BusinessRetention";
    static readonly Entites_Site_URL = "https://afatestretention.sharepoint.com/sites/AFA-LabellisationsDMO";
}
//# sourceMappingURL=Constants.d.ts.map