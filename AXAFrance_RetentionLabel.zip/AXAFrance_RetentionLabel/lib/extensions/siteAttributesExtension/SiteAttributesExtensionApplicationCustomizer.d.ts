import { BaseApplicationCustomizer } from '@microsoft/sp-application-base';
export interface ISiteAttributesExtensionApplicationCustomizerProperties {
    BusinessProperties: string;
    UserCompanyName: string;
}
export default class SiteAttributesExtensionApplicationCustomizer extends BaseApplicationCustomizer<ISiteAttributesExtensionApplicationCustomizerProperties> {
    private _rightPlaceholder;
    onInit(): Promise<void>;
    private _renderPlaceHolders;
}
//# sourceMappingURL=SiteAttributesExtensionApplicationCustomizer.d.ts.map