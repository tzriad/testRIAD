import { ApplicationCustomizerContext } from "@microsoft/sp-application-base";
export interface ISiteManagePanelProps {
    context: ApplicationCustomizerContext;
}
//# sourceMappingURL=ISiteManagePanelProps.d.ts.map