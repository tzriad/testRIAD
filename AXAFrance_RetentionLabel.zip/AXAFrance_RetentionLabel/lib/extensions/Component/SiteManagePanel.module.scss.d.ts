declare const styles: {
    paddingBtn: string;
    errorMessage: string;
    Icon: string;
    Top: string;
};
export default styles;
//# sourceMappingURL=SiteManagePanel.module.scss.d.ts.map