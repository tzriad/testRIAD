import * as React from "react";
import { ISiteManagePanelProps } from "./ISiteManagePanelProps";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface ISiteManagePanelState {
    showPanel: boolean;
    showBusiness: boolean;
    BusinessProperty: string;
    UserCompanyName: string;
    errorMetier: boolean;
    BusinessChoice: string;
    EntityOnboarded: boolean;
    EntityRefList: string;
}
export declare class SiteManagePanel extends React.Component<ISiteManagePanelProps, ISiteManagePanelState> {
    componentWillMount(): void;
    private _getUserProfileInformation;
    constructor(props: ISiteManagePanelProps);
    private _hideMenu;
    private _save;
    private _show;
    private _MetierChange;
    render(): React.ReactElement<ISiteManagePanelProps>;
    setSPProperty(name: string, value: string): void;
}
//# sourceMappingURL=SiteManagePanel.d.ts.map