define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "Header": "Délégation d'accès au site",
    "SiteNotExist":"Le site n'existe pas",
    "siteexist" : "Le site existe",
    "required":"Obligatoire",
    "step1":"1/ Adresse de votre site (url)",
    "step2":"2/ Votre requête",
    "indicate" : "Détaillez ici votre requête...",
    "Duration": "Durée d'accès souhaitée",
    "SendRequest": "Créer la requête",
    "MessageDenied":"Vous n'etes pas autorisé a demander l'accès à ce site",
    "MessagePending":"Une demande est déjà en cours. Merci de patienter.",
    "MessageValidated":"Votre demande a été créée. Les propriétaire du site devront l'approuver avant que l'accès ne vous soit accordé."
  }
});