define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "Header": "Site access delegation",
    "SiteNotExist":"site doesn't exist",
    "siteexist" : "site exists",
    "required":"required",
    "step1":"1/ Your site address (url)",
    "step2":"2/ Your request",
    "indicate" : "Detail your request here...",
    "Duration": "Duration",
    "SendRequest": "SEND REQUEST",
    "MessageDenied":"You are not allowed to request an administrator access for this site",
    "MessagePending":"A request is already in progress. Please wait.",
    "MessageValidated":"Your request has been created. Site owners will need to approve it before you are granted access"
  }
});