define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "Requester":"Requester",
    "Duration":"Duration",
    "Request":"Request",
    "Reject":"Reject",
    "Approve" : "Approve",
    "MessageTop":"A request for access as administrator need your validation. If you approve it, the requester will have hight privileges during this period.",
    "MessageValidated": "Approval request completed.",
    "MessageAlready" : "This request has already been processed.",
    "Header": "Site access delegation / Approval",
  }
});