define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "Requester":"Requester",
    "Duration":"Duration",
    "Request":"Request",
    "Reject":"Reject",
    "Approve" : "Approve",
    "MessageTop":"Une demande daccès en tant qu'administrateur vous a été soumise pour validation. Si vous acceptez cette requête, le demandeur aura des prévilèges élévés pendant cette période.",
    "MessageValidated": "Processus d'approbation terminé.",
    "MessageAlready" : "Cette requête a déjà été traitée.",
    "Header": "Délégation d'accès au site / Approbation",
  }
});