import * as React from 'react';
import { IApprovalWorkflowProps } from './IApprovalWorkflowProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    description: string;
    url: string;
    Justification: string;
    IDRequest: number;
    IDTask: number;
    ApprovalStatus: string;
    isSponsor: boolean;
    TaskAssignedTo: number;
    AccountName: string;
    Parameter: string;
    show_ApprovalForm: string;
    show_AlreadyTerminated: string;
    show_TaskAlreadyTerminated: string;
    show_NotYourTask: string;
    show_RequestStatus: string;
    show_NothigToDisplay: string;
    show_TaskRejected: string;
    show_TaskApproved: string;
    show_TaskCurrent: string;
    show_ScriptCreation: string;
    show_TaskPending: string;
    show_ProcessTaskRejected: string;
    show_ProcessTaskApproved: string;
    requester: string;
    IamSponsor: boolean;
}
export default class ApprovalWorkflow extends React.Component<IApprovalWorkflowProps, IControls> {
    private _sitedecriptionchange;
    componentWillMount(): void;
    constructor(props: IApprovalWorkflowProps);
    private _logicLanding;
    private _Approve;
    private _Reject;
    render(): React.ReactElement<IApprovalWorkflowProps>;
}
//# sourceMappingURL=ApprovalWorkflow.d.ts.map