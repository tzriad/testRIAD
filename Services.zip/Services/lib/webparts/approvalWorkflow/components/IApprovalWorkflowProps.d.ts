import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IApprovalWorkflowProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IApprovalWorkflowProps.d.ts.map