declare const styles: {
    FormHeader: string;
    Box: string;
    Icon: string;
    carrouselItem: string;
    seleted: string;
    carrousel: string;
    errorMessage: string;
    errorMessageTemplate: string;
    button: string;
    buttoncontainer: string;
    messageresult: string;
    stepdone: string;
    stepdCurrent: string;
    stepRjected: string;
    smallIcon: string;
    stepMess: string;
    stepMesslast: string;
    bigIcon: string;
    step: string;
    resumeRequest: string;
    leftTD: string;
    rightTD: string;
};
export default styles;
//# sourceMappingURL=ApprovalWorkflow.module.scss.d.ts.map