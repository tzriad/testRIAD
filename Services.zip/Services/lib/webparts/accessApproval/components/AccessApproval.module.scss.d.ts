declare const styles: {
    FormHeader: string;
    button: string;
    buttoncontainer: string;
    resumeRequest: string;
    leftTD: string;
    rightTD: string;
    FormHeader2: string;
};
export default styles;
//# sourceMappingURL=AccessApproval.module.scss.d.ts.map