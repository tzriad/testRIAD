import * as React from 'react';
import { IAccessApprovalProps } from './IAccessApprovalProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    Duration: string;
    url: string;
    Justification: string;
    IDRequest: number;
    status: string;
    requester: string;
    alreadyProcessed: boolean;
    Approved: boolean;
    Rejected: boolean;
    Approval: number;
    ApprovalAccess: string;
}
export default class AccessApproval extends React.Component<IAccessApprovalProps, IControls> {
    constructor(props: IAccessApprovalProps);
    componentWillMount(): void;
    private _logicLanding;
    private _Reject;
    private _Approve;
    render(): React.ReactElement<IAccessApprovalProps>;
}
//# sourceMappingURL=AccessApproval.d.ts.map