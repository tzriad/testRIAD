import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IAccessApprovalProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IAccessApprovalProps.d.ts.map