import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IAccessDelegationProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IAccessDelegationProps.d.ts.map