import * as React from 'react';
import { IAccessDelegationProps } from './IAccessDelegationProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/fields";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    required: boolean;
    url: string;
    duration: string;
    isSupport: boolean;
    isReferent: boolean;
    ExistingRequest: boolean;
    Validated: boolean;
    requester: string;
    justification: string;
    owners: any[];
    siteExist: boolean;
    siteScope: boolean;
    NotsiteExist: boolean;
    errorDesc: boolean;
    pole: string;
}
export default class AccessDelegation extends React.Component<IAccessDelegationProps, IControls> {
    componentWillMount(): void;
    constructor(props: IAccessDelegationProps);
    private _fetchData;
    private _siteURlChange;
    private _getUserProfileInformation;
    private _getDescription;
    private _SelectDuration;
    private _SendRequest;
    render(): React.ReactElement<IAccessDelegationProps>;
}
//# sourceMappingURL=AccessDelegation.d.ts.map