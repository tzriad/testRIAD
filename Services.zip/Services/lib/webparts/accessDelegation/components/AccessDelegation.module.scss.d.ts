declare const styles: {
    errorMessage: string;
    InfoMessage: string;
    FormHeader: string;
    Icon: string;
    button: string;
    datePicker: string;
    FormHeader2: string;
};
export default styles;
//# sourceMappingURL=AccessDelegation.module.scss.d.ts.map