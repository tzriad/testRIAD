declare const styles: {
    FormHeader: string;
    Box: string;
    Icon: string;
    toHide: string;
    carrouselItem: string;
    seleted: string;
    carrousel: string;
    errorMessage: string;
    errorMessageTemplate: string;
    button: string;
    buttoncontainer: string;
    messageresult: string;
    stepdone: string;
    smallIcon: string;
    stepMess: string;
    stepMesslast: string;
    bigIcon: string;
    step: string;
};
export default styles;
//# sourceMappingURL=RequestYourSite.module.scss.d.ts.map