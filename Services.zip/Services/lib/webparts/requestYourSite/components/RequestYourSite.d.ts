import * as React from 'react';
import { IRequestYourSiteProps } from './IRequestYourSiteProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    owners: any[];
    members: any[];
    visitors: any[];
    referents: any[];
    sponsor: number;
    NbInternalOwner: number;
    description: string;
    template: string;
    language: string;
    url: string;
    errortitle: string;
    errorUrl: string;
    errorSponsor: string;
    errorOwner: string;
    errorLanguage: string;
    errorTemplate: string;
    errorDesc: string;
    Pole: string;
    BU: string;
    Manager: string;
    TypeContract: string;
    Scope: string;
    sponsorAccountName: string;
    sponsorHRStatus: string;
    AccountName: string;
    show: string;
}
export default class RequestYourSite extends React.Component<IRequestYourSiteProps, IControls> {
    constructor(props: IRequestYourSiteProps);
    private _UserScope;
    private _getUserProfileInformation;
    private _getReferents;
    private _selectTemplate;
    private _getSponsor;
    private _getOwners;
    private _getMembers;
    private _getVisitors;
    private _sitetitlechange;
    private _sitedecriptionchange;
    private _sitelanguageChange;
    private _siteURlChange;
    private _newRequest;
    private _placeRequest;
    private _fetchData;
    render(): React.ReactElement<IRequestYourSiteProps>;
}
//# sourceMappingURL=RequestYourSite.d.ts.map