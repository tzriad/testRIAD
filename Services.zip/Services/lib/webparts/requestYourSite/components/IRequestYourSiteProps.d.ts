import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IRequestYourSiteProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IRequestYourSiteProps.d.ts.map