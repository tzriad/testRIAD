declare const styles: {
    FormHeader: string;
    Box: string;
    Icon: string;
    carrouselItem: string;
    carrousel: string;
    errorMessage: string;
    button: string;
    buttoncontainer: string;
    messageresult: string;
    stepdone: string;
    smallIcon: string;
    stepMess: string;
    bigIcon: string;
    step: string;
    InfoBulle: string;
};
export default styles;
//# sourceMappingURL=RequestTeam.module.scss.d.ts.map