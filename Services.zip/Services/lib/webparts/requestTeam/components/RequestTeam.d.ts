import * as React from 'react';
import { IRequestTeamProps } from './IRequestTeamProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    title: string;
    Metier: string;
    TypeProjet: string;
    Objectifs: string;
    SecondaryOwner: number;
    PrimaryOwner: number;
    EstimatedNBUsers: string;
    errorMetier: string;
    errorType: string;
    errorSecOwner: string;
    errorFirstOwner: string;
    AccountName: string;
    PrimryOwnerHRStatus: string;
    secOwnerAccountName: string;
    SecOwnerHRStatus: string;
    show: string;
    errorTitle: string;
    Pole: string;
    Department: string;
}
export default class RequestTeam extends React.Component<IRequestTeamProps, IControls> {
    componentWillMount(): void;
    private _MetierChange;
    private _TypeChange;
    private _EstimatedChange;
    private _NameChange;
    private _Deschange;
    private _getUserProfileInformation;
    private _getSecondOwner;
    private _getFirstOwner;
    private _newRequest;
    private _placeRequest;
    constructor(props: IRequestTeamProps);
    render(): React.ReactElement<IRequestTeamProps>;
}
//# sourceMappingURL=RequestTeam.d.ts.map