import * as React from 'react';
import { IDeveloperRequestsProps } from './IDeveloperRequestsProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/profiles";
import "@pnp/sp/site-users/web";
export interface IControls {
    Url: string;
    Staging: boolean;
    AppRegistration: boolean;
    AzureFunction: boolean;
    AppCatalog: boolean;
    step2: boolean;
    errorUrl1: string;
    siteExist: boolean;
    NotsiteExist: boolean;
    targetFullUrl: string;
}
export default class DeveloperRequests extends React.Component<IDeveloperRequestsProps, IControls> {
    constructor(props: IDeveloperRequestsProps);
    private _ChooseRequest;
    private _fetchData;
    private _newRequest;
    private _siteURlChange;
    private _SendRequest;
    render(): React.ReactElement<IDeveloperRequestsProps>;
}
//# sourceMappingURL=DeveloperRequests.d.ts.map