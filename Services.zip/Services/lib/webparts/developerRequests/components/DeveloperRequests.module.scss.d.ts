declare const styles: {
    errorMessage: string;
    InfoMessage: string;
    FormHeader: string;
    Icon: string;
    button: string;
    datePicker: string;
};
export default styles;
//# sourceMappingURL=DeveloperRequests.module.scss.d.ts.map