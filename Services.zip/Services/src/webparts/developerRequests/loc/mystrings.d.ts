declare interface IDeveloperRequestsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DeveloperRequestsWebPartStrings' {
  const strings: IDeveloperRequestsWebPartStrings;
  export = strings;
}
