import * as React from 'react';
import styles from './DeveloperRequests.module.scss';
import { IDeveloperRequestsProps } from './IDeveloperRequestsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as strings from 'DeveloperRequestsWebPartStrings';

import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import {Dropdown, IDropdownOption} from 'office-ui-fabric-react/lib/Dropdown';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { ChoiceGroup, IChoiceGroupOption } from 'office-ui-fabric-react/lib/ChoiceGroup';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { _Web } from '@pnp/sp/webs/types';
import { ICamlQuery } from "@pnp/sp/lists";
import { optionProperties } from 'office-ui-fabric-react/lib/Utilities';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { IContextInfo } from "@pnp/sp/sites";
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { Slider } from 'office-ui-fabric-react/lib/Slider';

const mainDomain :string = "https://bnpparibas.sharepoint.com/";
const ApproveIcon: IIconProps = { iconName: 'Accept' };
export interface IControls
{
  Url: string;  
  Staging : boolean;
  AppRegistration: boolean;
  AzureFunction : boolean;
  AppCatalog : boolean;
  step2:boolean;
  errorUrl1:string;
  siteExist:boolean;
  NotsiteExist:boolean;
  targetFullUrl:string;
}

const options: IChoiceGroupOption[] = [
  { key: 'Staging environment', text: 'Staging environment', iconProps: { iconName: 'DeveloperTools' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Activate app catalog', text: 'Activate App catalog', iconProps: { iconName: 'ProductCatalog' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'App registration', text: 'App registration', iconProps: { iconName: 'AppIconDefaultAdd' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Azure function', text: 'Azure function', iconProps: { iconName: 'AzureDataExplorer' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
 ];

export default class DeveloperRequests extends React.Component<IDeveloperRequestsProps, IControls> {

  constructor(props: IDeveloperRequestsProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      Url: '',
      Staging : false,
      AppRegistration: false,
      AzureFunction : false,
      AppCatalog : false,
      step2:false,
      errorUrl1:'',
      siteExist:false,
      NotsiteExist:false,
      targetFullUrl:''
    }
  }

  private _ChooseRequest(ev: React.MouseEvent<HTMLElement>, option: any) {
  
    this.setState({Staging: false}) ;
    this.setState({AppRegistration: false}) ;
    this.setState({AzureFunction: false}) ;
    this.setState({AppCatalog: false}) ;

    this.setState({step2: true}) ;
    
    switch(option.key)  {
    case 'Staging environment':   this.setState({Staging: true}) ;return;
    case 'App registration': this.setState({AppRegistration: true}) ;return;
    case 'Azure function':  this.setState({AzureFunction: true}) ;return;
    case 'Activate app catalog': this.setState({AppCatalog: true}) ;return;
  }
   }

   private _fetchData(siteUrl: string) : Promise<any> {
    return new Promise(function (resolve, reject) {
      var client = new SPHttpClient();
      
      sp.site.getContextInfo().then(function(result) {
       var endpoint =  mainDomain + "_api/SP.Site.Exists";
       var fullUrl =  mainDomain + "sites/" + siteUrl;
      
      
      client.post(endpoint, {
        body: JSON.stringify({
          url: fullUrl
        }),
        headers: {
          "accept": "application/json;",
        },
      }).then(d => {        
        d.json().then((v: any) => {
          resolve(v.value);
        });
      }).catch(d => {
        reject(d);
      });


    });
  });
}

private _newRequest():void{
  window.location.href = window.location.href;
}

private _siteURlChange(newValueInput: any): void {
  let newValue: string =  newValueInput.target.defaultValue;

  if(newValue.length == 0){
    this.setState({errorUrl1: "show"});
  }else{
    this.setState({errorUrl1: ""});
  this._fetchData(newValue).then(async d => {
    if(d){
      this.setState({siteExist: true});
      this.setState({NotsiteExist: false});
      this.setState({Url: newValue});
      this.setState({targetFullUrl: (mainDomain + "sites/" +newValue)});
    }else{
      this.setState({siteExist: false});
      this.setState({NotsiteExist: true});
      this.setState({Url: newValue});
    }
  });
}
}

private _SendRequest():void{
}

public render(): React.ReactElement<IDeveloperRequestsProps> {
    return (
      <div>
         <header className={styles.FormHeader}>1/ WHAT IS YOUR NEED ?</header>
         <ChoiceGroup  options={options}  onChange={this._ChooseRequest.bind(this)} />

         <div  style={{ display: (this.state.step2 ? 'block' : 'none') }} >
          <br/><br/>
        <header className={styles.FormHeader}>2/ Your site address (url)</header>
        <MessageBar
           messageBarType={MessageBarType.warning}
           isMultiline={true}>
            Make sure you fill in a site that you own. Otherwise your request will not be processed.
          </MessageBar><br/>
          <TextField prefix={mainDomain + "sites/"}  underlined onChange={this._siteURlChange.bind(this)}/>
          <div className={styles.errorMessage} style={{ display: (this.state.NotsiteExist ? 'block' : 'none') }}>site doesn't exist</div>
          <div className={styles.InfoMessage} style={{ display: (this.state.siteExist ? 'block' : 'none') }}>site exist</div>
          <div className={styles.errorMessage} style={{ display: (this.state.errorUrl1  =="show"? 'block' : 'none') }}>required</div>
        </div>

        <div  style={{ display: (this.state.Staging ? 'block' : 'none') }} >
           <br/>
           <DefaultButton title="SEND REQUEST" className={styles.button} iconProps={ApproveIcon} text="SEND REQUEST" onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>

        <div  style={{ display: (this.state.AppCatalog ? 'block' : 'none') }} >
           <br/>
           <DefaultButton title="SEND REQUEST" className={styles.button} iconProps={ApproveIcon} text="SEND REQUEST" onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>

        <div  style={{ display: (this.state.AppRegistration ? 'block' : 'none') }} >
           <br/>
           <DefaultButton title="SEND REQUEST" className={styles.button} iconProps={ApproveIcon} text="SEND REQUEST" onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>

        <div  style={{ display: (this.state.AzureFunction ? 'block' : 'none') }} >
           <br/>
           <DefaultButton title="SEND REQUEST" className={styles.button} iconProps={ApproveIcon} text="SEND REQUEST" onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>

        </div>
    );
  }
}
