/* tslint:disable */
require("./DeveloperRequests.module.css");
const styles = {
  errorMessage: 'errorMessage_5f113494',
  InfoMessage: 'InfoMessage_5f113494',
  FormHeader: 'FormHeader_5f113494',
  Icon: 'Icon_5f113494',
  button: 'button_5f113494',
  datePicker: 'datePicker_5f113494'
};

export default styles;
/* tslint:enable */