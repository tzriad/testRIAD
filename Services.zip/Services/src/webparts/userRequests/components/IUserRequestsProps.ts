import { WebPartContext } from '@microsoft/sp-webpart-base';  
export interface IUserRequestsProps {
  description: string;
  context: WebPartContext; 
}
