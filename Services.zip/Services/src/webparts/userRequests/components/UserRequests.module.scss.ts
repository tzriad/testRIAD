/* tslint:disable */
require("./UserRequests.module.css");
const styles = {
  errorMessage: 'errorMessage_8112d8ce',
  InfoMessage: 'InfoMessage_8112d8ce',
  FormHeader: 'FormHeader_8112d8ce',
  Icon: 'Icon_8112d8ce',
  button: 'button_8112d8ce',
  datePicker: 'datePicker_8112d8ce'
};

export default styles;
/* tslint:enable */