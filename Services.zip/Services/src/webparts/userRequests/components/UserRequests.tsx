import * as React from 'react';
import styles from './UserRequests.module.scss';
import { IUserRequestsProps } from './IUserRequestsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as strings from 'UserRequestsWebPartStrings';

import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import {Dropdown, IDropdownOption} from 'office-ui-fabric-react/lib/Dropdown';
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { ChoiceGroup, IChoiceGroupOption } from 'office-ui-fabric-react/lib/ChoiceGroup';
import {DatePicker} from 'office-ui-fabric-react/lib/DatePicker';
import { ListPicker } from "@pnp/spfx-controls-react/lib/ListPicker";
import { Checkbox} from 'office-ui-fabric-react/lib/Checkbox';


import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { _Web } from '@pnp/sp/webs/types';
import { ICamlQuery } from "@pnp/sp/lists";

import { optionProperties } from 'office-ui-fabric-react/lib/Utilities';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { IContextInfo } from "@pnp/sp/sites";
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { Slider } from 'office-ui-fabric-react/lib/Slider';
import { resultItem } from 'office-ui-fabric-react/lib/components/ExtendedPicker/PeoplePicker/ExtendedPeoplePicker.scss';

const mainDomain :string = "https://bnpparibas.sharepoint.com/";

export interface IControls
{
  Url: string;  
  newUrl:string;
  SecurityMap : boolean;
  AuditTrail: boolean;
  ActivateTermGroup : boolean;
  ChangeName : boolean;
  ExtendQuota:boolean;
  ClearList:boolean;
  DeleteSite : boolean;
  DeleteSubSite: boolean;
  Quota : boolean;
  Other : boolean;
  Description:string;
  CurrentQuota : number;
  NeededQuota : number;
  step2:boolean;
  siteExist : boolean;
  NotsiteExist:boolean;
  NewsiteExist:boolean;
  NotNewsiteExist:boolean;
  errorUrl1:string;
  errorUrl2:string;
  errordate:string;
  errordate2:string;
  errorDesc:string;
  startDate : Date;
  endDate : Date;
  show:string;
  langue:string;
  targetFullUrl:string;
  ListID:string;
  Webs:any[];
  SelectedWebs:any[];
}
const ApproveIcon: IIconProps = { iconName: 'Accept' };
const sliderValueFormat = (value: number) => `${value} GB`;

const QuotaOptions: IDropdownOption[] = [
  { key: '20', text: '20' },
  { key: '50', text: '50' },
  { key: '100', text: '100' },
  { key: '150', text: '150' },
  { key: '250', text: '250' },
  { key: 'Other', text: 'Other' }
];

const today = new Date(Date.now());
const minDate = today.setDate(today.getDate()-365);
const maxDate =  today.setDate(today.getDate()+1);

const options: IChoiceGroupOption[] = [
  { key: 'Change url', text: 'Change your site Url', iconProps: { iconName: 'SyncOccurence' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Security map', text: 'Generate security map', iconProps: { iconName: 'AuthenticatorApp' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Audit report', text: 'Get audit report', iconProps: { iconName: 'ComplianceAudit' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Increase quota', text: 'Increase quota', iconProps: { iconName: 'Step' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Delete site', text: 'Delete your site', iconProps: { iconName: 'RecycleBin' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Delete subsite', text: 'Delete subsite', iconProps: { iconName: 'Delete' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Empty list', text: 'Clear list', iconProps: { iconName: 'ClearFilter' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Activate term group', text: 'Activate local taxonomy (term store)', iconProps: { iconName: 'Tag' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Other request', text: 'Other request', iconProps: { iconName: 'FeedbackRequestSolid' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}}
];

const optionsFR: IChoiceGroupOption[] = [
  { key: 'Change url', text: "Modifier l'adresse (url)", iconProps: { iconName: 'SyncOccurence' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Security map', text: 'Générer la cartographie des permissions', iconProps: { iconName: 'AuthenticatorApp' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Audit report', text: "Obtenir les journaux d'audit", iconProps: { iconName: 'ComplianceAudit' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Increase quota', text: 'Augmenter le quota', iconProps: { iconName: 'Step' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Delete site', text: 'Supprimer le site', iconProps: { iconName: 'RecycleBin' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Delete subsite', text: 'Supprimer le sous-site', iconProps: { iconName: 'Delete' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Empty list', text: 'Vider liste', iconProps: { iconName: 'ClearFilter' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Activate term group', text: 'Activer taxonomie locale (term store)', iconProps: { iconName: 'Tag' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}},
  { key: 'Other request', text: 'Autre chose', iconProps: { iconName: 'FeedbackRequestSolid' } , styles:{field: { width: "180px"},labelWrapper:{maxWidth:"180px !important"}}}
];

export default class UserRequests extends React.Component<IUserRequestsProps, IControls> {
  componentWillMount() {
    let localLang =  this.props.context.pageContext.cultureInfo.currentUICultureName.toLowerCase();
    this.setState({langue:localLang});

  }

  constructor(props: IUserRequestsProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      Url: '',  
      newUrl :'',
      Other:false,
      SecurityMap : false,
      AuditTrail: false,
      ChangeName : false,
      ActivateTermGroup:false,
      ExtendQuota:false,
      DeleteSite:false,
      DeleteSubSite:false,
      ClearList:false,
      Quota : false,
      CurrentQuota : 100,
      Description:'',
      NeededQuota : 50,
      step2:false,
      siteExist:false,
      NotsiteExist:false,
      NewsiteExist:false,
      NotNewsiteExist:false,
      errorUrl1:'',
      errorUrl2:'',
      errordate:'',
      errordate2:'',
      errorDesc:'',
      startDate:null,
      endDate:null,
      show:"show",
      langue:'en-us',
      targetFullUrl:'',
      ListID:'',
      Webs:[],
      SelectedWebs:[]
    };

  }

  private _ChooseRequest(ev: React.MouseEvent<HTMLElement>, option: any) {
  
    this.setState({ChangeName: false}) ;
    this.setState({AuditTrail: false}) ;
    this.setState({SecurityMap: false}) ;
    this.setState({ClearList: false}) ;
    this.setState({Quota: false}) ;
    this.setState({Other: false}) ;
    this.setState({DeleteSite: false}) ;
    this.setState({DeleteSubSite: false}) ;
    this.setState({ActivateTermGroup: false}) ;

    this.setState({step2: true}) ;
    
    switch(option.key)  {
    case 'Change url':   this.setState({ChangeName: true}) ;return;
    case 'Security map': this.setState({SecurityMap: true}) ;return;
    case 'Audit report':  this.setState({AuditTrail: true}) ;return;
    case 'Increase quota': this.setState({Quota: true}) ;return;
    case 'Other request': this.setState({Other: true}) ;return;
    case 'Delete site': this.setState({DeleteSite: true}) ;return;
    case 'Delete subsite': this.setState({DeleteSubSite: true}) ;return;
    case 'Empty list': this.setState({ClearList: true}) ;return;
    case 'Activate term group': this.setState({ActivateTermGroup: true}) ;return;
  }
   }

   private _fetchData(siteUrl: string) : Promise<any> {
    return new Promise(function (resolve, reject) {
      var client = new SPHttpClient();
      
      sp.site.getContextInfo().then(function(result) {
       var endpoint =  mainDomain + "_api/SP.Site.Exists";
       var fullUrl =  mainDomain + "sites/" + siteUrl;
      
      
      client.post(endpoint, {
        body: JSON.stringify({
          url: fullUrl
        }),
        headers: {
          "accept": "application/json;",
        },
      }).then(d => {        
        d.json().then((v: any) => {
          resolve(v.value);
        });
      }).catch(d => {
        reject(d);
      });


    });
  });
}

private _siteURlChange(newValueInput: any): void {
  let newValue: string =  newValueInput.target.defaultValue;

  if(newValue.length == 0){
    this.setState({errorUrl1: "show"});
  }else{
    this.setState({errorUrl1: ""});
  this._fetchData(newValue).then(async d => {
    if(d){
      this.setState({siteExist: true});
      this.setState({NotsiteExist: false});
      this.setState({Url: newValue});
      this.setState({targetFullUrl: (mainDomain + "sites/" +newValue)});

      const SBX = new _Web(mainDomain + "sites/" +newValue);
      const webs = await SBX.webs.select("Title","ServerRelativeUrl").get();
      const val : any [] = [];
      webs.forEach(async (prop) => {  
        val.push({ url: prop.ServerRelativeUrl , title:prop.Title }) ;
        const nested =  new _Web(mainDomain + prop.ServerRelativeUrl);
        const nesteswebs = await nested.webs.select("Title","ServerRelativeUrl").get();
        nesteswebs.forEach(async (nestedprop) => {  val.push({ url: nestedprop.ServerRelativeUrl , title:nestedprop.Title }) ;
        
        });
      });
     
      this.setState({Webs:val});
      
    }else{
      this.setState({siteExist: false});
      this.setState({NotsiteExist: true});
      this.setState({Url: newValue});
    }
  });
}
}

private _siteURlChange2(newValueInput: any): void {
  let newValue: string =  newValueInput.target.defaultValue;
  if(newValue.length == 0){
    this.setState({errorUrl2: "show"});
  }else{
    this.setState({errorUrl2: ""});
  this._fetchData(newValue).then(d => {
    if(d){
      this.setState({NewsiteExist: true});
      this.setState({newUrl: newValue});
    }else{
      this.setState({NewsiteExist: false});
      this.setState({newUrl: newValue});
    }
  });
}
}

private _SendRequest():void{

if(this.state.ChangeName)
{
  var stop = false;
  stop= this.state.NotsiteExist;
  if( this.state.Url.length == 0) {this.setState({errorUrl1: "show"});stop =true;}else this.setState({errorUrl1: ""}); 
  if( this.state.newUrl.length == 0) {this.setState({errorUrl2: "show"});stop =true;}else this.setState({errorUrl2: ""});

  if(stop) return;
  sp.web.lists.getByTitle("User_REQUESTS").items.add({  
    Title : this.state.Url,
    AddtionalInfo: this.state.newUrl,
    RequestType : "Change Url"
   }) ;

}

if(this.state.SecurityMap ) 
{
   stop = false;
  stop= this.state.NotsiteExist;
  if( this.state.Url.length == 0) {this.setState({errorUrl1: "show"});stop =true;}else this.setState({errorUrl1: ""});

  if(stop) return;
  sp.web.lists.getByTitle("User_REQUESTS").items.add({  
    Title : this.state.Url,
    RequestType : "Security map"
   }) ;
}

if(this.state.DeleteSite ) 
{
   stop = false;
  stop= this.state.NotsiteExist;
  if( this.state.Url.length == 0) {this.setState({errorUrl1: "show"});stop =true;}else this.setState({errorUrl1: ""});

  if(stop) return;
  sp.web.lists.getByTitle("User_REQUESTS").items.add({  
    Title : this.state.Url,
    RequestType : "Delete site"
   }) ;
}

if(this.state.ActivateTermGroup ) 
{
  stop = false;
  stop= this.state.NotsiteExist;
  if( this.state.Url.length == 0) {this.setState({errorUrl1: "show"});stop =true;}else this.setState({errorUrl1: ""});
 
  if(stop) return;
  sp.web.lists.getByTitle("User_REQUESTS").items.add({  
    Title : this.state.Url,
    RequestType : "Activate Taxonomy"
   }) ;

}

if(this.state.DeleteSubSite )
{

  stop = false;
  if( this.state.SelectedWebs.length == 0) {this.setState({errorUrl2: "show"});stop =true;}else this.setState({errorUrl2: ""});

  if(stop) return;
  sp.web.lists.getByTitle("User_REQUESTS").items.add({  
    Title : this.state.Url,
    RequestType : "Delete sub-site",
    AddtionalInfo : this.state.SelectedWebs.join(';')
   }) ;

}

if(this.state.ClearList ) 
{
   stop = false;
 
  if( this.state.ListID.length == 0) {this.setState({errorUrl2: "show"});stop =true;}else this.setState({errorUrl2: ""});

  if(stop) return;
  sp.web.lists.getByTitle("User_REQUESTS").items.add({  
    Title : this.state.Url,
    RequestType : "Empty list",
    AddtionalInfo : this.state.ListID
   }) ;
}

if(this.state.AuditTrail) 
{
   stop = false;
  stop= this.state.NotsiteExist;
  if( this.state.Url.length == 0) {this.setState({errorUrl1: "show"});stop =true;}else this.setState({errorUrl1: ""});
  if(this.state.startDate == null) {this.setState({errordate: "show"});stop =true;}else this.setState({errordate: ""});
  if(this.state.endDate == null) {this.setState({errordate: "show"});stop =true;}else this.setState({errordate: ""});
  if(this.state.startDate > this.state.endDate)  {this.setState({errordate2: "show"});stop =true;}else this.setState({errordate2: ""});

  if(stop) return;
  sp.web.lists.getByTitle("User_REQUESTS").items.add({  
    Title : this.state.Url,
    RequestType : "Audit report" ,
    startDate : this.state.startDate,
    endDate : this.state.endDate,
   }) ;
}

if(this.state.Other){
   stop = false;
  stop= this.state.NotsiteExist;
  if( this.state.Url.length == 0) {this.setState({errorUrl1: "show"});stop =true;}
  if( this.state.Description.length == 0){this.setState({errorDesc: "show"});stop= true;}else this.setState({errorDesc: ""});

  if(stop) return;
  sp.web.lists.getByTitle("Other_REQUESTS").items.add({  
    Title : this.state.Url,
    Description : this.state.Description
   }) ;

}

if(this.state.Quota){
   stop = false;
  if( this.state.Url.length == 0) {this.setState({errorUrl1: "show"});stop =true;}
  if(this.state.ExtendQuota)
     if( this.state.Description.length == 0){this.setState({errorDesc: "show"});stop= true;}else this.setState({errorDesc: ""});


  if(stop) return;

  if(this.state.ExtendQuota)
   {
  sp.web.lists.getByTitle("Other_REQUESTS").items.add({  
    Title : this.state.Url,
    Description : ("[Extended QUOTA]" + this.state.Description)
   }) ;
  }else{
    sp.web.lists.getByTitle("User_REQUESTS").items.add({  
      Title : this.state.Url,
      RequestType : "Increase quota",
      AddtionalInfo : this.state.NeededQuota.toString()
     }) ;
  }

}

this.setState({show: "hide"});

}

private _getDescription(newValueInput: any): void {
  let newValue: string =  newValueInput.target.defaultValue;

  if(newValue.length  == 0){
    this.setState({errorDesc: "show"});
  }else{
    this.setState({errorDesc: ""});
    this.setState({Description:newValue});
  }
}

private _getQuota(newvalue:number):void{
  this.setState({NeededQuota:newvalue});
}

private _ExtendQuota(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
 this.setState({ExtendQuota:checked});
}

private _newRequest():void{
  window.location.href = window.location.href;
}
private _onChange(ev: React.FormEvent<HTMLElement>, isChecked: boolean) {
  var tempValues = this.state.SelectedWebs;
  var serverRelativeUrl = ev.currentTarget.title;
 if(isChecked)
  {
    if(tempValues.indexOf(serverRelativeUrl) == -1)  {tempValues.push( serverRelativeUrl);}
  }else{
    var index = tempValues.indexOf(serverRelativeUrl);
    if( index > -1)  {  tempValues.splice(index,1);  }
  }
  
  console.log(tempValues);

  this.setState({SelectedWebs:tempValues});
}

private onListPickerChange (lists: string | string[]) {
  this.setState({ListID:lists.toString()});
  this.setState({errorUrl2 : "hide"});
}

private _SelectStartDate(newValue:any):void { 
  if(newValue.length != 0){
    this.setState({errordate: ""});
  this.setState({startDate:newValue});
  }else{
    this.setState({errordate: "show"});
  }
}
private _SelectEndDate(newValue:any):void { 
  if(newValue.length != 0){
  this.setState({errordate: ""});
this.setState({endDate:newValue});
}else{
  this.setState({errordate: "show"});
}
}

private _getQuotaJustification(newValueInput:any):void { 
  let newValue: string =  newValueInput.target.defaultValue;
  this.setState({Description:newValue});
}

  public render(): React.ReactElement<IUserRequestsProps> {
    return (
      <div><div  style={{ display: (this.state.show  =="show"? 'block' : 'none') }} >
        <header className={styles.FormHeader}>{strings.step1}</header>

        <div  style={{ display: (this.state.langue == "fr-fr" ? 'none' : 'block') }} >   
        <ChoiceGroup  options={options}  onChange={this._ChooseRequest.bind(this)} />
        </div>
        <div  style={{ display: (this.state.langue == "fr-fr" ? 'block' : 'none') }} >   
        <ChoiceGroup  options={optionsFR}  onChange={this._ChooseRequest.bind(this)} />
        </div>

        <div  style={{ display: (this.state.step2 ? 'block' : 'none') }} >
          <br/><br/>
        <header className={styles.FormHeader}>{strings.step2}</header>
        <MessageBar
           messageBarType={MessageBarType.warning}
           isMultiline={true}>
            {strings.warningMessage}
          </MessageBar><br/>
          <TextField prefix={mainDomain + "sites/"}  underlined onChange={this._siteURlChange.bind(this)}/>
          <div className={styles.errorMessage} style={{ display: (this.state.NotsiteExist ? 'block' : 'none') }}>{strings.SiteNotExist}</div>
          <div className={styles.InfoMessage} style={{ display: (this.state.siteExist ? 'block' : 'none') }}>{strings.siteexist}</div>
          <div className={styles.errorMessage} style={{ display: (this.state.errorUrl1  =="show"? 'block' : 'none') }}>{strings.required}</div>
        </div>
       
        <div  style={{ display: (this.state.ChangeName ? 'block' : 'none') }} >
           <br/> <br/>
           <div  style={{ display: (this.state.siteExist? 'block' : 'none') }}>
        <header className={styles.FormHeader}>{strings.step3}</header>
          <TextField prefix={mainDomain + "sites/"}  underlined onChange={this._siteURlChange2.bind(this)}/>
          <div className={styles.errorMessage} style={{ display: (this.state.errorUrl2  =="show"? 'block' : 'none') }}>{strings.required}</div>
          <div className={styles.errorMessage} style={{ display: (this.state.NewsiteExist ? 'block' : 'none') }}>{strings.siteexist}</div><br/>
           <DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>
        </div>

        <div  style={{ display: (this.state.ClearList ? 'block' : 'none') }} >
           <br/> <br/>
        <div  style={{ display: (this.state.siteExist? 'block' : 'none') }}>
        <header className={styles.FormHeader}>{strings.step5}</header>
        <ListPicker context={this.props.context}
            includeHidden={false}
            multiSelect={false}
            onSelectionChanged={this.onListPickerChange.bind(this)} 
            webAbsoluteUrl={this.state.targetFullUrl}
            />
          <div className={styles.errorMessage} style={{ display: (this.state.errorUrl2  =="show"? 'block' : 'none') }}>{strings.required}</div>
         <br/><DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
         </div>

        </div>

        <div  style={{ display: (this.state.DeleteSubSite ? 'block' : 'none') }} >
           <br/> <br/>
        <div  style={{ display: (this.state.siteExist? 'block' : 'none') }}>
        <header className={styles.FormHeader}>{strings.step6}</header>

        {this.state.Webs.map((xweb: any) => {   return (  
             <div><Checkbox label={xweb.url} title={xweb.url} onChange={this._onChange.bind(this)} /> 
             <br/></div> 
         );})}

          <div className={styles.errorMessage} style={{ display: (this.state.errorUrl2  =="show"? 'block' : 'none') }}>{strings.required}</div>
         <br/><DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
         </div>

        </div>

        <div  style={{ display: (this.state.SecurityMap ? 'block' : 'none') }} >
           <br/>
           <DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>

        <div  style={{ display: (this.state.DeleteSite ? 'block' : 'none') }} >
           <br/>
           <DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>

        <div  style={{ display: (this.state.ActivateTermGroup ? 'block' : 'none') }} >
           <br/>
           <DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>

        <div  style={{ display: (this.state.AuditTrail ? 'block' : 'none') }} >
           <br/><br/>
           <div  style={{ display: (this.state.siteExist? 'block' : 'none') }}>
          <header className={styles.FormHeader}>{strings.validinterval}</header>
           <DatePicker id="StartDate" placeholder={strings.startDate}  underlined isRequired className={styles.datePicker}  onSelectDate={this._SelectStartDate.bind(this)} value={this.state.startDate}/>
           <DatePicker id="endDate"  placeholder={strings.endDate} underlined isRequired className={styles.datePicker}   onSelectDate={this._SelectEndDate.bind(this)} value={this.state.endDate}/>
           <div className={styles.errorMessage} style={{ display: (this.state.errordate  =="show"? 'block' : 'none') }}>{strings.required}</div>
           <div className={styles.errorMessage} style={{ display: (this.state.errordate2  =="show"? 'block' : 'none') }}>{strings.errorinterval}</div>
           <br/><br/><br/><br/>
           <DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div> </div>

        <div  style={{ display: (this.state.Other ? 'block' : 'none') }} >
        <br/> <br/>
        <header className={styles.FormHeader}>{strings.describe}</header>
           <TextField placeholder={strings.indicate}  underlined onChange={this._getDescription.bind(this)}/>
           <div className={styles.errorMessage} style={{ display: (this.state.errorDesc  =="show"? 'block' : 'none') }}>{strings.required}</div><br/>
           <DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>

        <div  style={{ display: (this.state.Quota ? 'block' : 'none') }} >
        <br/> <br/>
        <div  style={{ display: (this.state.siteExist? 'block' : 'none') }}>
        <header className={styles.FormHeader}>{strings.step4}</header>
        <br/>
        <Slider  min={50} max={250} step={50} defaultValue={this.state.CurrentQuota} showValue onChange={this._getQuota.bind(this)} valueFormat={sliderValueFormat} /><br/>
        <Toggle label={strings.NeededQutoa} inlineLabel onChange={this._ExtendQuota.bind(this)} /><br/>
        <div  style={{ display: (this.state.ExtendQuota ? 'block' : 'none') }}> <TextField placeholder={strings.explain}  underlined onChange={this._getQuotaJustification.bind(this)}/><br/></div>
         <DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>
      </div></div>
       <div  style={{ display: (this.state.show  =="hide"? 'block' : 'none') }} >
       <MessageBar
           messageBarType={MessageBarType.warning}
           isMultiline={true}>
           {strings.requestCreated}
          </MessageBar><br/>
          <DefaultButton title="New request" className={styles.button}  text="New request" onClick={this._newRequest.bind(this)} ></DefaultButton>
       </div></div>
    );
  }
}
