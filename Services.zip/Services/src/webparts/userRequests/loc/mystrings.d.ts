declare interface IUserRequestsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  ChangeSite: string;
  SiteNotExist:string;
  siteexist : string;
  required:string;
  step1:string;
  step2:string;
  step3:string;
  step4:string;
  step5:string;
  step6:string;
  warningMessage:string;
  validinterval:string;
  errorinterval: string;
  describe:string;
  increaseQuota: string;
  explain : string;
  yourrequest :string;
  NewRequest:string;
  SendRequest: string;
  startDate: string;
  endDate:  string;
  NeededQutoa : string;
  requestCreated :string;
  indicate:string;
}

declare module 'UserRequestsWebPartStrings' {
  const strings: IUserRequestsWebPartStrings;
  export = strings;
}
