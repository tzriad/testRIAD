declare interface IAccessApprovalWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  Requester:string;
  Request:string;
  Duration:string;
  Reject:string;
  Approve:string;
  MessageTop:string;
  MessageValidated:string;
  MessageAlready:string;
  Header:string;
}

declare module 'AccessApprovalWebPartStrings' {
  const strings: IAccessApprovalWebPartStrings;
  export = strings;
}
