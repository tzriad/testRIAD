/* tslint:disable */
require("./AccessApproval.module.css");
const styles = {
  FormHeader: 'FormHeader_089cb553',
  button: 'button_089cb553',
  buttoncontainer: 'buttoncontainer_089cb553',
  resumeRequest: 'resumeRequest_089cb553',
  leftTD: 'leftTD_089cb553',
  rightTD: 'rightTD_089cb553',
  FormHeader2: 'FormHeader2_089cb553'
};

export default styles;
/* tslint:enable */