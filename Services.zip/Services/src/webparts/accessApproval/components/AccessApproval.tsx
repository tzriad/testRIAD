import * as React from 'react';
import styles from './AccessApproval.module.scss';
import { IAccessApprovalProps } from './IAccessApprovalProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as strings from 'AccessApprovalWebPartStrings';

import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/fields";
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { Dropdown, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
import {imgProperties, MessageBar, MessageBarType } from 'office-ui-fabric-react';
import { ServiceScope, UrlQueryParameterCollection } from '@microsoft/sp-core-library';
import { RestrictedMessage1 } from 'RequestYourSiteWebPartStrings';

const mainDomain :string = "https://bnpparibas.sharepoint.com/"

const ApproveIcon: IIconProps = { iconName: 'Accept' };
const RejectIcon: IIconProps = { iconName: 'CalculatorMultiply' };

export interface IControls
{
  title: string;  
  Duration:string;
  url:string ;
  Justification: string;
  IDRequest:number;
  status:string;
  requester: string;
  alreadyProcessed:boolean;
  Approved : boolean;
  Rejected: boolean;
  Approval :number;
  ApprovalAccess :string;
}

export default class AccessApproval extends React.Component<IAccessApprovalProps, IControls> {
  
  constructor(props: IAccessApprovalProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      title: "", 
      Duration:"",
      url:"", 
      Justification: "", 
      IDRequest:0,
      status:"", 
      requester: "",
      Approval: 0,
      alreadyProcessed:false,
      Approved : false,
      Rejected: false,
      ApprovalAccess:""
    };

  }

  componentWillMount() {  this._logicLanding();  }


  private async _logicLanding(){
    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
 
    if(queryParameters.getValue("RequestID")){

      var UserID : number = parseInt(queryParameters.getValue("RequestID"));
      const userRequest = await sp.web.lists.getByTitle("AccessDelegation").items.getById(UserID).get();
      this.setState({IDRequest : UserID});

      const ReqStatus = userRequest["Status"];
      this.setState({url : userRequest["Title"]});
      this.setState({Duration : userRequest["Duration"]});
      this.setState({Justification : userRequest["Justification"]});

      let owner = await sp.web.getUserById(parseInt(userRequest["AuthorId"])).get();
      this.setState({requester : owner.Title});

     if( ReqStatus != "Requested"  ) {
       this.setState({alreadyProcessed : true});
       this.setState({Approval : userRequest["Approval"]});
       this.setState({ApprovalAccess : userRequest["ApprovalAccess"]});

      }

    }
  }
  
  private async _Reject(newValue: string): Promise<void> {
    this.setState({Approved : false});
    this.setState({Rejected : true});
    var CurrentUser : any = await sp.web.currentUser.get();
     const i = await sp.web.lists.getByTitle("AccessDelegation").items.getById(this.state.IDRequest).update({
      Status : "Rejected",
      ApprovalId : CurrentUser.Id,
      ApprovalAccess: (new Date())
     });
  }
  private async _Approve(newValue: string): Promise<void> {
    this.setState({Approved : true});
    this.setState({Rejected : false});
    var CurrentUser : any = await sp.web.currentUser.get();

     const i = await sp.web.lists.getByTitle("AccessDelegation").items.getById(this.state.IDRequest).update({
      Status : "Approved",
      ApprovalId : CurrentUser.Id,
      ApprovalAccess: (new Date())
     });

  }

  public render(): React.ReactElement<IAccessApprovalProps> {
    return (
      <div>
        <header className={styles.FormHeader2}>{strings.Header}</header>
      <div style={{ display: ((!this.state.Approved && !this.state.Rejected &&!this.state.alreadyProcessed)  ? 'block' : 'none') }}>
         <MessageBar  messageBarType={MessageBarType.warning} isMultiline={true}>
          {strings.MessageTop}
         </MessageBar><br/>
          <div className={styles.resumeRequest}>
          <table>
            <tr>
              <td className={styles.leftTD}>{strings.Requester}</td>
              <td className={styles.rightTD}>{this.state.requester}</td>
            </tr>
            <tr>
              <td className={styles.leftTD}>Url</td>
              <td className={styles.rightTD}>https://bnpparibas.sharepoint.com/sites/{this.state.url}</td>
            </tr>
            <tr>
              <td className={styles.leftTD}>{strings.Duration}</td>
              <td className={styles.rightTD}>{this.state.Duration}h</td>
            </tr>
            <tr>
              <td className={styles.leftTD}>{strings.Request}</td>
              <td>{this.state.Justification}</td>
            </tr>
           </table>
         </div> 
         <br/>
         <div className={styles.buttoncontainer}>
           <DefaultButton title={strings.Approve} className={styles.button} iconProps={ApproveIcon} text={strings.Approve} onClick={this._Approve.bind(this)} ></DefaultButton>
           <DefaultButton title={strings.Reject}  iconProps={RejectIcon} text={strings.Reject}  onClick={this._Reject.bind(this)} ></DefaultButton>
        </div>
      </div>
      <div style={{ display: (this.state.alreadyProcessed  ? 'block' : 'none') }}>
      <MessageBar  messageBarType={MessageBarType.severeWarning} isMultiline={true}>
          {strings.MessageAlready}
         </MessageBar><br/>
      </div>
      <div style={{ display: (!this.state.alreadyProcessed && this.state.Rejected ||  this.state.Approved  ? 'block' : 'none') }}>
      <MessageBar  messageBarType={MessageBarType.success} isMultiline={true}>
          {strings.MessageValidated}
         </MessageBar><br/>
      </div>
      </div>

    );
  }
}
