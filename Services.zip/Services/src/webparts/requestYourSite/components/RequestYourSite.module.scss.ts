/* tslint:disable */
require("./RequestYourSite.module.css");
const styles = {
  FormHeader: 'FormHeader_c9a1a8ef',
  Box: 'Box_c9a1a8ef',
  Icon: 'Icon_c9a1a8ef',
  toHide: 'toHide_c9a1a8ef',
  carrouselItem: 'carrouselItem_c9a1a8ef',
  seleted: 'seleted_c9a1a8ef',
  carrousel: 'carrousel_c9a1a8ef',
  errorMessage: 'errorMessage_c9a1a8ef',
  errorMessageTemplate: 'errorMessageTemplate_c9a1a8ef',
  button: 'button_c9a1a8ef',
  buttoncontainer: 'buttoncontainer_c9a1a8ef',
  messageresult: 'messageresult_c9a1a8ef',
  stepdone: 'stepdone_c9a1a8ef',
  smallIcon: 'smallIcon_c9a1a8ef',
  stepMess: 'stepMess_c9a1a8ef',
  stepMesslast: 'stepMesslast_c9a1a8ef',
  bigIcon: 'bigIcon_c9a1a8ef',
  step: 'step_c9a1a8ef'
};

export default styles;
/* tslint:enable */