import * as React from 'react';
import styles from './RequestYourSite.module.scss';
import { IRequestYourSiteProps } from './IRequestYourSiteProps';
import * as strings from 'RequestYourSiteWebPartStrings';

import {
  MessageBarButton,
  Link,
  Stack,
  StackItem,
  MessageBar,
  MessageBarType,
  ChoiceGroup,
  IStackProps,
} from 'office-ui-fabric-react';

import { escape } from '@microsoft/sp-lodash-subset';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";

import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import {Dropdown, IDropdownOption} from 'office-ui-fabric-react/lib/Dropdown';
import { Icon } from 'office-ui-fabric-react/lib/Icon';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";

import { optionProperties } from 'office-ui-fabric-react/lib/Utilities';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { IContextInfo } from "@pnp/sp/sites";

export interface IControls
{
  title: string;  
  owners: any[] ;  
  members:any[] ;
  visitors:any[] ;
  referents: any[];
  sponsor: number ;
  NbInternalOwner:number;
  description:string ;
  template:string ;
  language:string ;
  url:string ;
  errortitle:string ;
  errorUrl:string ;
  errorSponsor:string ;
  errorOwner:string ;
  errorLanguage:string;
  errorTemplate:string;
  errorDesc:string;
  Pole:string ;
  BU: string ;
  Manager : string ;
  TypeContract : string ;
  Scope:string ;
  sponsorAccountName :string;
  sponsorHRStatus : string;
  AccountName:string;
  show: string;
}



const options: IDropdownOption[] = [
  { key: '1025', text: 'Arabic' },
  { key: '1068', text: 'Azerbaijani' },
  { key: '1069', text: 'Basque' },
  { key: '5146', text: 'Bosnian (Latin)' },
  { key: '1026', text: 'Bulgarian' },
  { key: '1027', text: 'Catalan' },
  { key: '2052', text: 'Chinese (Simplified)' },
  { key: '1028', text: 'Chinese (Traditional)' },
  { key: '1050', text: 'Croatian' },
  { key: '1029', text: 'Czech' },
  { key: '1030', text: 'Danish' },
  { key: '1164', text: 'Dari' },
  { key: '1043', text: 'Dutch' },
  { key: '1033', text: 'English' },
  { key: '1061', text: 'Estonian' },
  { key: '1035', text: 'Finnish' },
  { key: '1036', text: 'French' },
  { key: '1110', text: 'Galician' },
  { key: '1031', text: 'German' },
  { key: '1032', text: 'Greek' },
  { key: '1037', text: 'Hebrew' },
  { key: '1081', text: 'Hindi' },
  { key: '1038', text: 'Hungarian' },
  { key: '1057', text: 'Indonesian' },
  { key: '2108', text: 'Irish' },
  { key: '1040', text: 'Italian' },
  { key: '1041', text: 'Japanese' },
  { key: '1087', text: 'Kazakh' },
  { key: '1042', text: 'Korean' },
  { key: '1062', text: 'Latvian' },
  { key: '1063', text: 'Lithuanian' },
  { key: '1071', text: 'Macedonian' },
  { key: '1086', text: 'Malay' },
  { key: '1044', text: 'Norwegian (Bokmål)' },
  { key: '1045', text: 'Polish' },
  { key: '1046', text: 'Portuguese (Brazil)' },
  { key: '2070', text: 'Portuguese (Portugal)' },
  { key: '1048', text: 'Romanian' },
  { key: '1049', text: 'Russian' },
  { key: '2074', text: 'Serbian (Latin)' },
  { key: '1051', text: 'Slovak' },
  { key: '1060', text: 'Slovenian' },
  { key: '3082', text: 'Spanish' },
  { key: '1053', text: 'Swedish' },
  { key: '1054', text: 'Thai' },
  { key: '1055', text: 'Turkish' },
  { key: '1058', text: 'Ukrainian' },
  { key: '1066', text: 'Vietnamese' }
];


export default class RequestYourSite extends React.Component<IRequestYourSiteProps, IControls> {
  constructor(props: IRequestYourSiteProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      title: '',  
      owners: [],  
      members:[],
      visitors:[],
      referents:[],
      sponsor:0,
      NbInternalOwner:0,
      description:'',
      template:'',
      language:'',
      url:'',
      errortitle:'',
      errorUrl:'',
      errorSponsor:'',
      errorOwner:'',
      errorLanguage:'',
      errorTemplate:'',
      errorDesc:'',
      Pole:'',
      BU: '',
      Manager : '',
      TypeContract : '',
      Scope:'',
      sponsorAccountName:'',
      sponsorHRStatus:'',
      AccountName: '',
      show:'show'
    };  

    this._getUserProfileInformation();
  }  

  private _UserScope(){

    const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><Eq> <FieldRef Name='Title'/> <Value Type='Text'>" + this.state.Pole + "</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>"  };
    sp.web.lists.getByTitle("PROCESSING_POLE").getItemsByCAMLQuery(q).then((result: any[]) => {
      if(result.length> 0){  this.setState({Scope: "ITO"});   }
      else {  this.setState({Scope: "ITG"});   }
    
    });   

    this._getReferents();

  }

  private  _getUserProfileInformation(){
    if(this.state.Scope == "")
    {
    sp.profiles.myProperties.get().then(profile => {
      var props = {};
      profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
      profile.userProperties = props;
      this.setState({TypeContract: profile.userProperties["HRPERSONNESTATUT"]});
      this.setState({Pole: profile.userProperties["POLEFONCTION"]});
      this.setState({BU: profile.userProperties["Department"]});
      this.setState({AccountName: profile.userProperties["AccountName"]});

      this._UserScope() ;
     });
  }

  }

  private _getReferents(){
    const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><Eq><FieldRef Name='Title'/> <Value Type='Text'>" + this.state.Pole + "</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>"  };
    sp.web.lists.getByTitle("REFERENTS").getItemsByCAMLQuery(q).then((result: any[]) => {
      if(result.length> 0){  
        let referers: number[] =   result[0]["ReferentsId"];
         this.setState({referents:referers});
      }
    });   

  }

  private _selectTemplate(newValue){
    this.setState({template:newValue.currentTarget.id});
    this.setState({errorTemplate:''});

    var elemes =  document.getElementsByClassName(styles.carrouselItem);
    [].forEach.call(elemes, function(el) { el.classList.remove(styles.seleted);});
    document.getElementById(newValue.currentTarget.id).classList.add(styles.seleted);
  }

  private async _getSponsor(items: any[]) { 
    if(items.length == 0){
      this.setState({errorSponsor:  "show"});
    }else {
         this.setState({errorSponsor: ""});
         this.setState({ sponsor: items[0].id });  
         this.setState({ sponsorAccountName: ("i:0#.f|membership|" + items[0].secondaryText )});    

 
         if(this.state.Scope == "ITG"){
         //check if sponsor is external user
         const propertyName = "HRPERSONNESTATUT";
        var result: any =  await sp.profiles.getUserProfilePropertyFor(("i:0#.f|membership|" + items[0].secondaryText ) , propertyName);
        
        if(result == "CONTRACTOR")
           { 
             
             this.setState({sponsorHRStatus : "CONTRACTOR"});
             this.setState({errorSponsor: "show1"});
           }else{
            this.setState({sponsorHRStatus : ""});
            this.setState({errorSponsor: ""});
           }
     

         //Check if sponsor is you
         if(("i:0#.f|membership|" + items[0].secondaryText ) == this.state.AccountName){ this.setState({errorSponsor: "show2"});}
        }
    }
   }

  private async _getOwners(items: any[]) {
    let tempTeamAssArr = [];  
    let NbInternalOwner : number = 0;
    const propertyName = "HRPERSONNESTATUT";

    for (let item in items) {  
      tempTeamAssArr.push(items[item].id);  
     var result :any =  await sp.profiles.getUserProfilePropertyFor(("i:0#.f|membership|" + items[item].secondaryText ) , propertyName);
     if(result != "CONTRACTOR")  { NbInternalOwner++;  }
    }   

    if(NbInternalOwner < 2){
      this.setState({errorOwner: "show"});
      this.setState({NbInternalOwner : 0});
    }
    else{
    this.setState({errorOwner: ""});
    this.setState({ owners: tempTeamAssArr });
    this.setState({NbInternalOwner : tempTeamAssArr.length});
    }
  
  }
  private _getMembers(items: any[]) { 
    let tempTeamAssArr = [];  
    for (let item in items) {  
      tempTeamAssArr.push(items[item].id);  
    }   
    this.setState({ members: tempTeamAssArr });
  }
  private _getVisitors(items: any[]) { 
    let tempTeamAssArr = [];  
    for (let item in items) {  
      tempTeamAssArr.push(items[item].id);  
    }   
    this.setState({ visitors: tempTeamAssArr });
  }
  private _sitetitlechange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
  
    if(newValue.length == 0){
      this.setState({errortitle: "show1"});
      this.setState({url: ""});
    }else{  
      var Url :string =  newValue;
      Url = Url.toString().replace(/[^a-zA-Z0-9-_]+/gi, "");
      this._fetchData(Url).then(d => {
        if(d){
          this.setState({errortitle: "show2"});
          this.setState({url: Url});
        }else{
          this.setState({errortitle: ""});
          this.setState({errorUrl: ""});
          this.setState({url: Url});  
          this.setState({title: newValue});
        }
   
      });

    }
  }
  private _sitedecriptionchange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
    
    if(newValue.length == 0){
      this.setState({errorDesc: "show"});
      this.setState({description: ""});
    }else{  
    this.setState({description: newValue}); 
    this.setState({errorDesc: ""});
    }
  
  }

  private _sitelanguageChange(newValue: any): void { 
    this.setState({language: newValue.key});
  if(newValue.key.length <3){
    this.setState({errorLanguage:"show"});
  }else{this.setState({errorLanguage:""});}

  }

  private _siteURlChange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
   
    if(newValue.length == 0){
      this.setState({errorUrl: "show"});
    }
    else{  this.setState({errorUrl: ""});}
    this.setState({url: newValue.replace(/[^a-zA-Z0-9-_]+/gi, "")});
  }
 
  private _newRequest():void{
    window.location.href = window.location.href;
  }
  private _placeRequest():void{
     var stop = false;
     if(this.state.title.length == 0){this.setState({errortitle: "show"});stop= true;}
     if(this.state.url.length == 0){this.setState({errorUrl: "show"});stop= true;}
     if(this.state.description.length == 0){this.setState({errorDesc: "show"});stop= true;}
     if(this.state.template.length == 0){this.setState({errorTemplate: "show"});stop= true;}
     if(this.state.sponsor == 0){this.setState({errorSponsor: "show"});stop= true;}
     if(this.state.language.length <3){this.setState({errorLanguage:"show"});stop= true;}

     if(this.state.Scope == "ITG"){
        if(this.state.AccountName == this.state.sponsorAccountName){this.setState({errorSponsor: "show1"});stop= true;}
        if(this.state.sponsorHRStatus == "CONTRACTOR"){this.setState({errorSponsor: "show2"});stop= true;}
        if(this.state.NbInternalOwner == 0){ this.setState({errorOwner: "show"});stop=true;}
     }
     
     if(stop) return; 
       

     sp.web.lists.getByTitle("REQUESTS").items.add({  
        Title : this.state.title,
        Description : this.state.description,
        Pole: this.state.Pole,
        BU: this.state.BU,
        Scope: this.state.Scope,
        SiteUrl: this.state.url,
        SiteTemplate : this.state.template,
        Language : this.state.language,
        SponsorId: this.state.sponsor,
        SiteOwnersId : {  results: this.state.owners },
        SiteMembersId : {  results: this.state.members },
        SiteVisitorsId : {  results: this.state.visitors},
        ReferentsId : { results: this.state.referents}
        }) ;

       this.setState({show:"hide"});
  }

  private _fetchData(siteUrl: string) : Promise<any> {
    return new Promise(function (resolve, reject) {
      var client = new SPHttpClient();
      
      sp.site.getContextInfo().then(function(result) {
      var endpoint = result.SiteFullUrl + "/_api/SP.Site.Exists";

     var fullUrl =  result.SiteFullUrl + "/sites/" + siteUrl;

      client.post(endpoint, {
        body: JSON.stringify({
          url: fullUrl
        }),
        headers: {
          "accept": "application/json;",
        },
      }).then(d => {        
        d.json().then((v: any) => {
          resolve(v.value);
        });
      }).catch(d => {
        reject(d);
      });


    });
  });
}

  public render(): React.ReactElement<IRequestYourSiteProps> {
    return (
      <div>
      <div style={{ display: (this.state.Scope == "ITG"? 'block' : 'none') }}>    
      <div style={{ display: (this.state.show  =="show"? 'block' : 'none') }} >
       <header className={styles.FormHeader}><Icon iconName="SharepointAppIcon16" className={styles.Icon}/>{strings.SITETEMPLATE}</header>
       <div className={styles.carrousel}>
        <div className={styles.carrouselItem} id="STS#3" onClick={this._selectTemplate.bind(this)}><img src="https://spoprod-a.akamaihd.net/files/odsp-next-prod-webpack_2020-10-16-sts_20201016.001/odsp-media/images/createsite/teamsite.png" /><br/>
        <strong>{strings.TEAMSITE}</strong><br/>
        <span>{strings.DescTeamSite}</span>
        </div>

        <div className={styles.carrouselItem} id="SITEPAGEPUBLISHING#0" onClick={this._selectTemplate.bind(this)}><img src="https://spoprod-a.akamaihd.net/files/odsp-next-prod-webpack_2020-10-16-sts_20201016.001/odsp-media/images/createsite/commsite.png" /><br/>
        <strong>{strings.COMMUNICATIONSITE}</strong><br/>
        <span>{strings.DescComSite}</span>
        </div>
        <div className={styles.errorMessage} style={{ display: (this.state.errorTemplate  =="show"? 'block' : 'none') }}>{strings.REQUIRED}</div>
         </div>


      <header className={styles.FormHeader}><Icon iconName="AllApps"  className={styles.Icon}/>{strings.SITEINFOS}</header>
      <div className={styles.Box}>
      <TextField   label={strings.SITETITLE} underlined required   onChange={this._sitetitlechange.bind(this)}/> 
      <div className={styles.errorMessage} style={{ display: (this.state.errortitle  =="show1"? 'block' : 'none') }}>{strings.REQUIRED}</div>
      <div className={styles.errorMessage} style={{ display: (this.state.errortitle  =="show2"? 'block' : 'none') }}>{strings.EXISTINGSITE }</div>
      <br/>
      <TextField  underlined  prefix="https://bnpparibas.sharepoint/com/sites/" value={this.state.url}  onChange={this._siteURlChange.bind(this)}/> 
      <div className={styles.errorMessage} style={{ display: (this.state.errorUrl  =="show"? 'block' : 'none') }}>{strings.REQUIRED}</div>
      <br/>
      <TextField label={strings.SITEDESCRIPTION} underlined multiline required onChange={this._sitedecriptionchange.bind(this)}/> 
      <div className={styles.errorMessage} style={{ display: (this.state.errorDesc  =="show"? 'block' : 'none') }}>{strings.REQUIRED}</div>
      <br/>
      <Dropdown label={strings.LANGUAGE} placeholder={strings.SelectLanguage} required  options={options} onChanged={this._sitelanguageChange.bind(this)} />
      <div className={styles.errorMessage} style={{ display: (this.state.errorLanguage  =="show"? 'block' : 'none') }}>{strings.REQUIRED}</div>
      <br/>
      <PeoplePicker 
       required={true}
      context={this.props.context}
      titleText={strings.SPONSOR}
      personSelectionLimit={1} 
      showtooltip={false} 
      disabled={false}
      onChange={this._getSponsor.bind(this)}
      showHiddenInUI={false}
      ensureUser={true}
      principalTypes={[PrincipalType.User]}
      resolveDelay={1000} />
      <div className={styles.errorMessage} style={{ display: (this.state.errorSponsor  =="show"? 'block' : 'none') }}>{strings.REQUIRED}</div>
      <div className={styles.errorMessage} style={{ display: (this.state.errorSponsor  =="show1"? 'block' : 'none') }}>{strings.Error_sponsorExternal}</div>
      <div className={styles.errorMessage} style={{ display: (this.state.errorSponsor  =="show2"? 'block' : 'none') }}>{strings.YouCannotBeSponsor}</div>
      <br/><br/>
      </div>


      <header className={styles.FormHeader}><Icon iconName="Permissions"  className={styles.Icon}/>{strings.SITEPERMISSIONS}</header>
      <div className={styles.Box}>
      <PeoplePicker 
      required={true}
      context={this.props.context}
      titleText={strings.OWNERS}
      ensureUser={true}
      personSelectionLimit={10} 
      showtooltip={true} 
      tooltipMessage={strings.ToolTipOWners}
      disabled={false}
      onChange={this._getOwners.bind(this)}
      showHiddenInUI={false}
      principalTypes={[PrincipalType.User]}
      resolveDelay={1000} />
      <div className={styles.errorMessage} style={{ display: (this.state.errorOwner  =="show"? 'block' : 'none') }}>{strings.TwoInternal}</div>
      
      <br/><br/>

      <PeoplePicker 
      context={this.props.context}
      titleText={strings.MEMBERS}
      ensureUser={true}
      personSelectionLimit={10} 
      showtooltip={true} 
      tooltipMessage={strings.ToolTipMembers}
      disabled={false}
      onChange={this._getMembers.bind(this)}
      showHiddenInUI={false}
      principalTypes={[PrincipalType.User]}
      resolveDelay={1000} />

       <br/><br/>
      <PeoplePicker 
      context={this.props.context}
      titleText={strings.VISITORS}
      ensureUser={true}
      personSelectionLimit={10} 
      showtooltip={true} 
      tooltipMessage={strings.ToolTipVisitors}
      disabled={false}
      onChange={this._getVisitors.bind(this)}
      showHiddenInUI={false}
      principalTypes={[PrincipalType.User]}
      resolveDelay={1000} />
       <br/>
      <DefaultButton title={strings.REQUESTIT} className={styles.button}  text={strings.REQUESTIT} onClick={this._placeRequest.bind(this)} ></DefaultButton>
     </div>
      </div>
      <div  style={{ display: (this.state.show  =="show"? 'none' : 'block') }} >
      <header className={styles.FormHeader}><Icon iconName="Accept" className={styles.Icon}/>{strings.SITEREQUESTED}</header>
             <div className={styles.messageresult}> {strings.MessRequest} </div>
             <div className={styles.stepdone}><Icon  iconName="NewTeamProject" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step1}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
             <div className={styles.step}><Icon  iconName="Flow" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step2}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
             <div className={styles.step}><Icon  iconName="Settings" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step3}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
             <div className={styles.step}><Icon  iconName="MailCheck" className={styles.smallIcon}  /><div className={styles.stepMesslast}> {strings.Step4}<br/>{strings.Step41} </div></div>

            <div className={styles.buttoncontainer}><DefaultButton title={strings.NewRequest} className={styles.button}  text={strings.NewRequest} onClick={this._newRequest.bind(this)} ></DefaultButton></div>
      </div>
     </div>
     <div className={styles.toHide} style={{ display: (this.state.Scope == "ITG"? 'none' : 'block') }}>    

     <MessageBar  messageBarType={MessageBarType.warning}    isMultiline={true}>
       {strings.RestrictedMessage1}<br/><br/>
       {strings.RestrictedMessage2}<br/><br/>
       {strings.RestrictedMessage3} : <a href='https://my.cib.echonet'>Welcome to the CIB collaboration plateform</a> 
     </MessageBar>
     </div>
     </div>

    );
  }
}
