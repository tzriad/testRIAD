declare interface IRequestYourSiteWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
   SITETEMPLATE:string;
  SITEINFOS:string;
  SITEPERMISSIONS:string;
  SITEREQUESTED:string;
  SITEDESCRIPTION:string;
  LANGUAGE:string;
  SPONSOR:string;
  OWNERS:string;
  MEMBERS:string;
  VISITORS:string;
  SelectLanguage:string;
  REQUIRED:string;
  REQUESTIT:string;
  TEAMSITE:string;
  COMMUNICATIONSITE:string;
  DescTeamSite:string;
  DescComSite:string;
  MessRequest:string;
  Step1:string;
  Step2:string;
  Step3:string;
  Step4:string;
  Step41:string;
  NewRequest:string;
  Error_sponsorExternal:string;
  YouCannotBeSponsor:string;
  TwoInternal:string;
  EXISTINGSITE:string;
  SITETITLE:string;
  ToolTipOWners:string;
  ToolTipMembers:string;
  ToolTipVisitors:string;
  RestrictedMessage1:string;
  RestrictedMessage2:string;
  RestrictedMessage3:string;
}

declare module 'RequestYourSiteWebPartStrings' {
  const strings: IRequestYourSiteWebPartStrings;
  export = strings;
}
