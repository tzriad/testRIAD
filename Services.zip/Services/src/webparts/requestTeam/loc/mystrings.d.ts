declare interface IRequestTeamWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  Header:string;
  Introduction1:string;
  Introduction2:string;
  Introduction3:string;
  Introduction4:string;
  Introduction5:string;
  Metier:string;
  TypeEquipe:string;
  TeamTitle:string;
  TeamGoals:string;
  GoalsPlaceHolder:string;
  SecondaryOwner:string;
  PrimaryOwner:string;
  Estimated:string;
  ConfirmationMessage:string;
  infoBullesMetier:string;
  InfoBullesTitle :string;
  InfoBullesSecondaryOwner:string;
  CreateBtn:string;
  NewRequest:string;
  REQUESTSAVED:string;
  SelectValue:string;
  errorSecondOwner1:string;
  errorSecondOwner2:string;
  required:string;
}

declare module 'RequestTeamWebPartStrings' {
  const strings: IRequestTeamWebPartStrings;
  export = strings;
}
