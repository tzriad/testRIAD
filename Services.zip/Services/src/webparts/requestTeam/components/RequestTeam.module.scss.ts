/* tslint:disable */
require("./RequestTeam.module.css");
const styles = {
  FormHeader: 'FormHeader_0df475b5',
  Box: 'Box_0df475b5',
  Icon: 'Icon_0df475b5',
  carrouselItem: 'carrouselItem_0df475b5',
  carrousel: 'carrousel_0df475b5',
  errorMessage: 'errorMessage_0df475b5',
  button: 'button_0df475b5',
  buttoncontainer: 'buttoncontainer_0df475b5',
  messageresult: 'messageresult_0df475b5',
  stepdone: 'stepdone_0df475b5',
  smallIcon: 'smallIcon_0df475b5',
  stepMess: 'stepMess_0df475b5',
  bigIcon: 'bigIcon_0df475b5',
  step: 'step_0df475b5',
  InfoBulle: 'InfoBulle_0df475b5'
};

export default styles;
/* tslint:enable */