import * as React from 'react';
import styles from './RequestTeam.module.scss';
import { IRequestTeamProps } from './IRequestTeamProps';
import { escape } from '@microsoft/sp-lodash-subset';


import { withStyles } from "@material-ui/core/styles";
import Tooltip from "@material-ui/core/Tooltip";

import * as strings from 'RequestTeamWebPartStrings';
import {
  MessageBarButton,
  Link,
  Stack,
  StackItem,
  MessageBar,
  MessageBarType,
  ChoiceGroup,
  IStackProps,
} from 'office-ui-fabric-react';

import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import {Dropdown, IDropdownOption} from 'office-ui-fabric-react/lib/Dropdown';
import { Icon } from 'office-ui-fabric-react/lib/Icon';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';


export interface IControls
{
  title: string; 
  Metier :string;
  TypeProjet : string;
  Objectifs: string;
  SecondaryOwner :  number;
  PrimaryOwner:number;
  EstimatedNBUsers : string;
   errorMetier : string;
   errorType : string;
   errorSecOwner : string;  
   errorFirstOwner:string;
   AccountName:string;
   PrimryOwnerHRStatus:string;
   secOwnerAccountName: string;
   SecOwnerHRStatus:string;
   show :string;
   errorTitle:string;
   Pole:string;
   Department:string;
}

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor:theme.palette.common.white,
    color: "rgba(0, 0, 0, 0.87)",
    boxShadow: theme.shadows[2],
    fontSize: 13
  }
}))(Tooltip);


const Metieroptions: IDropdownOption[] = [];
const TypeOptions: IDropdownOption[] = [];
const EstimatedOptions: IDropdownOption[] = [];


export default class RequestTeam extends React.Component<IRequestTeamProps, IControls> {
  componentWillMount() { this._getUserProfileInformation();  }
  
  private _MetierChange(newValue: any): void {

    this.setState({Metier: newValue.key});
  if(newValue.key.length <3){
    this.setState({errorMetier:"show"});
  }else{this.setState({errorMetier:""});}

  }

  private _TypeChange(newValue: any): void {
    
    this.setState({TypeProjet: newValue.key});
  if(newValue.key.length <3){
    this.setState({errorType:"show"});
  }else{this.setState({errorType:""});}

  }

  private _EstimatedChange(newValue: any): void {

    if(newValue.key.length <3){
      this.setState({EstimatedNBUsers: ""});
    }else{  
    this.setState({EstimatedNBUsers: newValue.key}); 
    }
  }

  private _NameChange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
  
    if(newValue.length == 0){
      this.setState({errorTitle: "show"});
      this.setState({title: ""});
    }else{  
    this.setState({title: newValue}); 
    this.setState({errorTitle: ""});
    }
  }

  private _Deschange(newValueInput: any): void {
    let newValue: string =  newValueInput.target.defaultValue;
    if(newValue.length == 0){
      this.setState({Objectifs: ""});
    }else{  
    this.setState({Objectifs: newValue}); 
    }
  }

  private async _getUserProfileInformation(){

    //Load Business values
    const items: any[] = await sp.web.lists.getByTitle("TEAMS_Business").items.get();
    for (let item in items) {  Metieroptions.push({key:items[item]["Title"], text:items[item]["Title"]});  }

    let localLang =  this.props.context.pageContext.cultureInfo.currentUICultureName.toLowerCase();
    let fieldName = "Title";
    if(localLang == "fr-fr"){fieldName = localLang.replace("-","_x002d_"); }
    
    //Load type values
     const itemsT: any[] = await sp.web.lists.getByTitle("TEAMS_Type").items.get();
     for (let item in itemsT) { TypeOptions.push({key:itemsT[item][fieldName], text:itemsT[item][fieldName]});   }

     //Load type values
     const itemsE: any[] = await sp.web.lists.getByTitle("TEAMS_EstimatedUsers").items.get();
     for (let item in itemsE) { EstimatedOptions.push({key:itemsE[item][fieldName], text:itemsE[item][fieldName]});   }


     const profile = await sp.profiles.myProperties.get();
     this.setState({AccountName: profile.AccountName});
     var props = {};
     profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
     profile.userProperties = props;
     this.setState({Department: profile.userProperties["Department"]});
     this.setState({PrimryOwnerHRStatus: profile.userProperties["HRPERSONNESTATUT"]});
     this.setState({Pole: profile.userProperties["POLEFONCTION"]});

     let result = await sp.web.ensureUser(profile.AccountName);
     this.setState({PrimaryOwner: result.data.Id});
  }

  private async _getSecondOwner(newValue: any[]) {
    this.setState({errorSecOwner: ""});
    if(newValue.length == 0){
      this.setState({errorSecOwner:  "show"});
    }else {
         this.setState({errorSecOwner: ""});
         this.setState({ SecondaryOwner :  newValue[0].id });  
         this.setState({ secOwnerAccountName: ("i:0#.f|membership|" + newValue[0].secondaryText )});    

         //get secondary Owner Status
         const propertyName = "HRPERSONNESTATUT";
         var result: any =  await sp.profiles.getUserProfilePropertyFor(("i:0#.f|membership|" + newValue[0].secondaryText ) , propertyName);
         if(result == "CONTRACTOR") { this.setState({SecOwnerHRStatus : "CONTRACTOR"});}else{ this.setState({SecOwnerHRStatus : ""});}

         if((result == "CONTRACTOR") &&(this.state.PrimryOwnerHRStatus == "CONTRACTOR"))
         {
         this.setState({errorSecOwner: "show2"});
         }else{
           this.setState({errorSecOwner: ""});
         }
        
          //Check if secondary Owner is you
         if(("i:0#.f|membership|" + newValue[0].secondaryText ) == this.state.AccountName){ this.setState({errorSecOwner: "show1"});}

    }



  }

  private async _getFirstOwner(newValue: any[]) {
    this.setState({errorFirstOwner: ""});
    if(newValue.length == 0){
      this.setState({errorFirstOwner:  "show"});
    }else {
         this.setState({errorFirstOwner: ""});
         this.setState({ PrimaryOwner :  newValue[0].id });  
         this.setState({ AccountName: ("i:0#.f|membership|" + newValue[0].secondaryText )});    

         //get secondary Owner Status
         const propertyName = "HRPERSONNESTATUT";
         var result: any =  await sp.profiles.getUserProfilePropertyFor(("i:0#.f|membership|" + newValue[0].secondaryText ) , propertyName);
         if(result == "CONTRACTOR") { this.setState({PrimryOwnerHRStatus : "CONTRACTOR"});}else{ this.setState({PrimryOwnerHRStatus : ""});}

         if((result == "CONTRACTOR") &&(this.state.SecOwnerHRStatus == "CONTRACTOR"))
         {
         this.setState({errorSecOwner: "show2"});
         }else{
           this.setState({errorSecOwner: ""});
         }
        
          //Check if secondary Owner is primary owner
         if(("i:0#.f|membership|" + newValue[0].secondaryText ) == this.state.secOwnerAccountName){ this.setState({errorSecOwner: "show1"});}

    }
  }

  private _newRequest():void{  window.location.href = window.location.href; }
  private _placeRequest():void{
    var stop = false;
    if(this.state.Metier.length <3){this.setState({errorMetier:"show"});stop= true;}
    if(this.state.TypeProjet.length <3){this.setState({errorType:"show"});stop= true;}
    if(this.state.PrimaryOwner == 0){this.setState({errorFirstOwner: "show"});stop= true;}
    if(this.state.SecondaryOwner == 0){this.setState({errorSecOwner: "show"});stop= true;}
    if(this.state.title.length == 0){this.setState({errorTitle: "show"});stop= true;}
    if(this.state.AccountName == this.state.secOwnerAccountName){this.setState({errorSecOwner: "show1"});stop= true;}
    if((this.state.SecOwnerHRStatus == "CONTRACTOR") &&(this.state.PrimryOwnerHRStatus == "CONTRACTOR")){this.setState({errorSecOwner: "show2"});stop= true;}
    if(stop) return; 


    sp.web.lists.getByTitle('Teams REQUESTS').items.add({
      Metier: this.state.Metier,
      TypeEquipe: this.state.TypeProjet,
      Description: this.state.Objectifs,
      NBEstimatedMembers: this.state.EstimatedNBUsers,
      SecondOwnerId : this.state.SecondaryOwner,
      PrimaryOwnerId : this.state.PrimaryOwner,
      Title :this.state.title
    });
    this.setState({show:"hide"});
  }

  constructor(props: IRequestTeamProps) {  
    super(props);  
   
    
    sp.setup({  spfxContext:  props.context   });

    this.state = {  
      title: '', 
      Metier :'',
      TypeProjet : '',
      Objectifs: '',
      SecondaryOwner :  0 ,
      PrimaryOwner: 0,
      EstimatedNBUsers : '',
       errorMetier : '',
       errorType : '',
       errorFirstOwner : '',
       errorSecOwner : '',  
       errorTitle :'',
       AccountName:'',
       secOwnerAccountName: '',
       SecOwnerHRStatus:'',
       PrimryOwnerHRStatus:'',
      show:'show',
      Pole:'',
      Department:'',

    };  
  }

  public render(): React.ReactElement<IRequestTeamProps> {
    return (
      <div>
        <div style={{ display: (this.state.show  =="show"? 'block' : 'none') }} >
       <header className={styles.FormHeader}><Icon iconName="AllApps"  className={styles.Icon}/>{strings.Header}</header>
         <div className={styles.Box}>
        <MessageBar
           messageBarType={MessageBarType.warning}
           isMultiline={true}>
          {strings.Introduction1}<br/><br/>
          {strings.Introduction2}<br/><br/>
          {strings.Introduction3}<Link href="https://weshare.group.echonet/sites/digitalworking/FR/Pages/Create-a-Team-Teams.aspx?PathID=22">{strings.Introduction4}</Link>{strings.Introduction5}
        </MessageBar><br/>
        
         <Dropdown label={strings.Metier} placeholder={strings.SelectValue} required options={Metieroptions} onChanged={this._MetierChange.bind(this)} /><span><LightTooltip title={strings.infoBullesMetier}><Icon iconName="Info" className={styles.InfoBulle}/></LightTooltip></span>
         <div className={styles.errorMessage} style={{ display: (this.state.errorMetier  =="show"? 'block' : 'none') }}>{strings.required}</div>
         <br/>

         <Dropdown label={strings.TypeEquipe} placeholder={strings.SelectValue} required  options={TypeOptions}  onChanged={this._TypeChange.bind(this)} />
         <div className={styles.errorMessage} style={{ display: (this.state.errorType  =="show"? 'block' : 'none') }}>{strings.required}</div>
         <br/>
        
         <TextField  label={strings.TeamTitle} maxLength={35} required  onChange={this._NameChange.bind(this)}/><span><LightTooltip title={strings.InfoBullesTitle}><Icon iconName="Info" className={styles.InfoBulle}/></LightTooltip></span>
         <div className={styles.errorMessage} style={{ display: (this.state.errorTitle  =="show"? 'block' : 'none') }}>{strings.required}</div>
         <br/>
         <TextField  label= {strings.TeamGoals}  multiline  placeholder={strings.GoalsPlaceHolder}  onChange={this._Deschange.bind(this)}/>
         <br/>
        
         <PeoplePicker 
           required={true}
           context={this.props.context}
           titleText={strings.PrimaryOwner}
           personSelectionLimit={1} 
           showtooltip={true}
           tooltipMessage={strings.InfoBullesSecondaryOwner} 
           disabled={false}
           onChange={this._getFirstOwner.bind(this)}
           showHiddenInUI={false}
           ensureUser={true}
           principalTypes={[PrincipalType.User]}
           resolveDelay={1000} /><span><LightTooltip title={strings.InfoBullesSecondaryOwner}><Icon iconName="Info" className={styles.InfoBulle}/></LightTooltip></span>
           <div className={styles.errorMessage} style={{ display: (this.state.errorFirstOwner  =="show"? 'block' : 'none') }}>{strings.required}</div>
         <br/>
         <PeoplePicker 
           required={true}
           context={this.props.context}
           titleText={strings.SecondaryOwner}
           personSelectionLimit={1} 
           showtooltip={true}
           tooltipMessage={strings.InfoBullesSecondaryOwner} 
           disabled={false}
           onChange={this._getSecondOwner.bind(this)}
           showHiddenInUI={false}
           ensureUser={true}
           principalTypes={[PrincipalType.User]}
           resolveDelay={1000} /><span><LightTooltip title={strings.InfoBullesSecondaryOwner}><Icon iconName="Info" className={styles.InfoBulle}/></LightTooltip></span>
           <div className={styles.errorMessage} style={{ display: (this.state.errorSecOwner  =="show"? 'block' : 'none') }}>{strings.required}</div>
           <div className={styles.errorMessage} style={{ display: (this.state.errorSecOwner  =="show1"? 'block' : 'none') }}>{strings.errorSecondOwner2}</div>
           <div className={styles.errorMessage} style={{ display: (this.state.errorSecOwner  =="show2"? 'block' : 'none') }}>{strings.errorSecondOwner1}</div>
           <br/>
           <Dropdown label={strings.Estimated} placeholder={strings.SelectValue}   options={EstimatedOptions} onChanged={this._EstimatedChange.bind(this)} />
            <br/>
            <br/>
             <DefaultButton title={strings.CreateBtn} className={styles.button}  text={strings.CreateBtn}   onClick={this._placeRequest.bind(this)} ></DefaultButton>
         </div>
         </div>
      <div  style={{ display: (this.state.show  =="show"? 'none' : 'block') }} >
      <header className={styles.FormHeader}><Icon iconName="Accept" className={styles.Icon}/>{strings.REQUESTSAVED}</header>
             <div className={styles.messageresult}>{strings.ConfirmationMessage}</div>
             <div className={styles.buttoncontainer}>
               <DefaultButton title={strings.NewRequest} className={styles.button}  text={strings.NewRequest} onClick={this._newRequest.bind(this)} ></DefaultButton></div>
      </div>
      </div>
    );
  }
}
