import { WebPartContext } from '@microsoft/sp-webpart-base'; 

export interface IRequestTeamProps {
  description: string;
  context: WebPartContext; 
}
