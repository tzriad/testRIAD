declare interface IAccessDelegationWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  Header:string;
  required:string;
  siteexist:string;
  SiteNotExist:string;
  step1:string;
  step2:string;
  indicate:string;
  Duration:string;
  SendRequest:string;
  MessageDenied :string;
  MessagePending:string;
  MessageValidated:string;
}

declare module 'AccessDelegationWebPartStrings' {
  const strings: IAccessDelegationWebPartStrings;
  export = strings;
}
