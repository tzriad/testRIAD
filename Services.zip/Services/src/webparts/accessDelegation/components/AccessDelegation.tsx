import * as React from 'react';
import styles from './AccessDelegation.module.scss';
import { IAccessDelegationProps } from './IAccessDelegationProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as strings from 'AccessDelegationWebPartStrings';

import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/fields";
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { Dropdown, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
import {MessageBar, MessageBarType } from 'office-ui-fabric-react';

const mainDomain :string = "https://bnpparibas.sharepoint.com/"

const ApproveIcon: IIconProps = { iconName: 'Accept' };

export interface IControls
{
  title: string; 
  required:boolean;
  url:string; 
  duration: string;
  isSupport:boolean;
  isReferent :boolean;
  ExistingRequest : boolean;
  Validated:boolean;
  requester:string;
  justification:string;
  owners:any[];
  siteExist:boolean;
  siteScope : boolean;
  NotsiteExist:boolean;
  errorDesc:boolean;
  pole : string;
}

const TypeOptions: IDropdownOption[] = [
  { key: '1', text: '1h' },
  { key: '2', text: '2h' },
  { key: '4', text: '4h' },
  { key: '12', text: '12h' }
];

const today = new Date(Date.now());

export default class AccessDelegation extends React.Component<IAccessDelegationProps, IControls> {
  componentWillMount() { this._getUserProfileInformation();  }

  constructor(props: IAccessDelegationProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      title: '', 
      url:'',
      duration: '',
      isSupport:false,
      isReferent :false,
      ExistingRequest:false,
      Validated:false,
      siteScope:true,
      requester:'',
      justification:'',
      owners:null,
      siteExist:false,
      pole:'',
      required:false,
      NotsiteExist:false,
      errorDesc:false
    }
  }
 
  private _fetchData(siteUrl: string) : Promise<any> {
    return new Promise(function (resolve, reject) {
      var client = new SPHttpClient();
      
      sp.site.getContextInfo().then(function(result) {
       var endpoint =  mainDomain + "_api/SP.Site.Exists";
       var fullUrl =  mainDomain + "sites/" + siteUrl;
      
      
      client.post(endpoint, {
        body: JSON.stringify({
          url: fullUrl
        }),
        headers: {
          "accept": "application/json;",
        },
      }).then(d => {        
        d.json().then((v: any) => {
          resolve(v.value);
        });
      }).catch(d => {
        reject(d);
      });


    });
  });
}

private _siteURlChange(newValueInput: any): void {
  let newValue: string =  newValueInput.target.defaultValue;

  if(newValue.length == 0){
    this.setState({required: true});
  }else{
    this.setState({required: false});
  this._fetchData(newValue).then(async d => {
    if(d){
      console.log(d);
      this.setState({siteExist: true});
      this.setState({NotsiteExist: false});
      this.setState({url: newValue});

      const q: ICamlQuery = {  ViewXml: "<View><Query><Where><Eq> <FieldRef Name='Title' /> <Value Type='Text'>" + newValue + "</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>"  };
      var result = await  sp.web.lists.getByTitle("PORTFOLIO").getItemsByCAMLQuery(q);
      if(result.length > 0) { if(result[0]["Pole"]== this.state.pole) {this.setState({siteScope: true}); }}

      var user = await sp.web.currentUser.get();
      const q2: ICamlQuery = {  ViewXml: "<View><Query><Where><And><And><And><Eq><FieldRef Name='Title' /> <Value Type='Text'>" + newValue + "</Value></Eq><Neq><FieldRef Name='Status' /><Value Type='Choice'>Closed</Value></Neq></And><Neq><FieldRef Name='Status' /><Value Type='Choice'>Rejected</Value></Neq></And><Eq><FieldRef Name='Author'  LookupId='TRUE'/> <Value Type='Integer'>" + user.Id + "</Value></Eq></And></Where></Query><RowLimit>1</RowLimit></View>"  };
      var result = await  sp.web.lists.getByTitle("AccessDelegation").getItemsByCAMLQuery(q2);
      if(result.length > 0) { this.setState({ExistingRequest: true}); console.log("Exist request");}

    }else{
      this.setState({siteExist: false});
      this.setState({NotsiteExist: true});
      this.setState({url: newValue});
      this.setState({siteScope: false}); 
      this.setState({ExistingRequest: false}); 
    }
  });
}
}

  private  async _getUserProfileInformation(){
    var profile = await sp.profiles.myProperties.get();
      var props = {};
      profile.UserProfileProperties.forEach((prop) => {   props[prop.Key] = prop.Value; });
      profile.userProperties = props;
      this.setState({pole: profile.userProperties["POLE-FONCTION"]});

     //Support ?
     var user = await sp.web.currentUser.get();
     const q: ICamlQuery = {  ViewXml: "<View><Query><Where><Eq> <FieldRef Name='User'  LookupId='TRUE'/> <Value Type='Integer'>" + user.Id + "</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>"  };
     var result = await  sp.web.lists.getByTitle("Support").getItemsByCAMLQuery(q);
     if(result.length > 0) { this.setState({isSupport: true}); }

     //Referent ?
     if(profile.userProperties["POLE-FONCTION"] != "")
     {
     const qu: ICamlQuery = {  ViewXml: "<View><Query><Where><Eq><FieldRef Name='Title' /> <Value Type='Text'>" + profile.userProperties["POLE-FONCTION"]  + "</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>"  };
     var result2 = await  sp.web.lists.getByTitle("REFERENTS").getItemsByCAMLQuery(qu);
     if(result2.length > 0) {
      result2[0]["ReferentsId"].forEach((owner) => {   if(owner == user.Id){ this.setState({isReferent: true});} });
      }
     }


     
  }

  private _getDescription(newValueInput: any): void {
    let newValue: string =  newValueInput.target.defaultValue;
  
    if(newValue.length  == 0){
      this.setState({errorDesc: true});
    }else{
      this.setState({errorDesc: false});
      this.setState({justification:newValue});
    }
  }

  private _SelectDuration(newValue: any): void {  this.setState({duration: newValue.key});  }

  private _SendRequest():void{

    var stop = false;
    stop= this.state.NotsiteExist;
    if( this.state.url.length == 0) {this.setState({required: true});stop =true;}else this.setState({required: false}); 
    if(stop) return;

    sp.web.lists.getByTitle("AccessDelegation").items.add({  
      Title : this.state.url,
      Justification : this.state.justification,
      Duration : this.state.duration,
      Profile:(this.state.isReferent?"Referent":"Support")
     }) ;

     this.setState({Validated: true});

  }

  public render(): React.ReactElement<IAccessDelegationProps> {
    return (
     <div>
      <header className={styles.FormHeader2}>{strings.Header}</header>
     <div   style={{ display: (this.state.Validated? 'none' : 'block') }}>
         <header className={styles.FormHeader}>{strings.step1}</header>
          <TextField prefix={mainDomain + "sites/"} required  underlined onChange={this._siteURlChange.bind(this)}/>
          <div className={styles.errorMessage} style={{ display: (this.state.NotsiteExist ? 'block' : 'none') }}>{strings.SiteNotExist}</div>
          <div className={styles.InfoMessage} style={{ display: (this.state.siteExist ? 'block' : 'none') }}>{strings.siteexist}</div>
          <div className={styles.errorMessage} style={{ display: (this.state.required? 'block' : 'none') }}>{strings.required}</div>
        <br/><br/>
        <div  style={{ display: ((!this.state.ExistingRequest && this.state.siteExist && this.state.isSupport)|| (!this.state.ExistingRequest && this.state.siteExist && this.state.isReferent && this.state.siteScope)? 'block' : 'none') }}>
        <header className={styles.FormHeader}>{strings.step2}</header>
           <TextField placeholder={strings.indicate}  underlined onChange={this._getDescription.bind(this)}/>
           <div className={styles.errorMessage} style={{ display: (this.state.errorDesc ? 'block' : 'none') }}>{strings.required}</div><br/>
           <Dropdown label={strings.Duration} required  options={TypeOptions}  onChanged={this._SelectDuration.bind(this)} /><br/><br/>
           <DefaultButton title={strings.SendRequest} className={styles.button} iconProps={ApproveIcon} text={strings.SendRequest} onClick={this._SendRequest.bind(this)} ></DefaultButton>
        </div>
        <div  style={{ display: (((!this.state.ExistingRequest && this.state.siteExist && (!this.state.isReferent && !this.state.isSupport))||(!this.state.ExistingRequest && this.state.siteExist && (this.state.isReferent && !this.state.siteScope)))? 'block' : 'none') }}>
        <MessageBar
           messageBarType={MessageBarType.error} isMultiline={true}>
            {strings.MessageDenied}
          </MessageBar><br/>
           
        </div>
        <div  style={{ display: (this.state.ExistingRequest? 'block' : 'none') }}>
        <MessageBar
           messageBarType={MessageBarType.severeWarning} isMultiline={true}>
            {strings.MessagePending}
          </MessageBar>
           
        </div>
      </div>
      <div style={{ display: (this.state.Validated? 'block' : 'none') }}>
      <MessageBar
           messageBarType={MessageBarType.success} isMultiline={true}>
            {strings.MessageValidated}
          </MessageBar><br/>
      </div>
      </div>
    );
  }
}
