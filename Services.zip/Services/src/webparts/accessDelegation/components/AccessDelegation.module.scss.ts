/* tslint:disable */
require("./AccessDelegation.module.css");
const styles = {
  errorMessage: 'errorMessage_79c579da',
  InfoMessage: 'InfoMessage_79c579da',
  FormHeader: 'FormHeader_79c579da',
  Icon: 'Icon_79c579da',
  button: 'button_79c579da',
  datePicker: 'datePicker_79c579da',
  FormHeader2: 'FormHeader2_79c579da'
};

export default styles;
/* tslint:enable */