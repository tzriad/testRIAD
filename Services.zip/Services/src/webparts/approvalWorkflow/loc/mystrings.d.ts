declare interface IApprovalWorkflowWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  MessRequest:string;
  Step1:string;
  Step2:string;
  Step3:string;
  Step4:string;
  NoNeedAnymore : string;
  le:string;
  par: string,
  NoNeedAnymore:string;
  TaskAlreadyProcess:string;
  ApproveOrReject:string;
  TASKCOMPLETED :string;
  TaskRejected:string;
  TaskApproved:string;
  APPROVALTASK:string;
  Title:string;
  Requester:string;
  Approve:string;
  Reject:string;
  NotToYou:string;
  NothingThere:string;
  WORKFLOWTERMINATED:string;
  STATUSREQUEST : string;
}

declare module 'ApprovalWorkflowWebPartStrings' {
  const strings: IApprovalWorkflowWebPartStrings;
  export = strings;
}
