/* tslint:disable */
require("./ApprovalWorkflow.module.css");
const styles = {
  FormHeader: 'FormHeader_622d95ff',
  Box: 'Box_622d95ff',
  Icon: 'Icon_622d95ff',
  carrouselItem: 'carrouselItem_622d95ff',
  seleted: 'seleted_622d95ff',
  carrousel: 'carrousel_622d95ff',
  errorMessage: 'errorMessage_622d95ff',
  errorMessageTemplate: 'errorMessageTemplate_622d95ff',
  button: 'button_622d95ff',
  buttoncontainer: 'buttoncontainer_622d95ff',
  messageresult: 'messageresult_622d95ff',
  stepdone: 'stepdone_622d95ff',
  stepdCurrent: 'stepdCurrent_622d95ff',
  stepRjected: 'stepRjected_622d95ff',
  smallIcon: 'smallIcon_622d95ff',
  stepMess: 'stepMess_622d95ff',
  stepMesslast: 'stepMesslast_622d95ff',
  bigIcon: 'bigIcon_622d95ff',
  step: 'step_622d95ff',
  resumeRequest: 'resumeRequest_622d95ff',
  leftTD: 'leftTD_622d95ff',
  rightTD: 'rightTD_622d95ff'
};

export default styles;
/* tslint:enable */