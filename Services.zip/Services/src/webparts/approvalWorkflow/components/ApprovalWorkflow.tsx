import * as React from 'react';
import styles from './ApprovalWorkflow.module.scss';
import { IApprovalWorkflowProps } from './IApprovalWorkflowProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as strings from 'ApprovalWorkflowWebPartStrings';

import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { Icon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';

import { sp } from "@pnp/sp";  
import { SPHttpClient } from "@pnp/sp";
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/fields";
import "@pnp/sp/profiles";  
import { IFieldInfo } from "@pnp/sp/fields/types";
import "@pnp/sp/site-users/web";
import { ICamlQuery } from "@pnp/sp/lists";
import { IContextInfo } from "@pnp/sp/sites";
import { UrlQueryParameterCollection } from '@microsoft/sp-core-library';

export interface IControls
{
  title: string;  
  description:string;
  url:string ;
  Justification: string;
  IDRequest:number;
  IDTask:number;
  ApprovalStatus:string;
  isSponsor:boolean;
  TaskAssignedTo: number;
  AccountName:string;
  Parameter:string;
  show_ApprovalForm: string;
  show_AlreadyTerminated:string;
  show_TaskAlreadyTerminated:string;
  show_NotYourTask:string;
  show_RequestStatus:string;
  show_NothigToDisplay:string;
  show_TaskRejected:string;
  show_TaskApproved:string;
  show_TaskCurrent:string;
  show_ScriptCreation:string;
  show_TaskPending:string;
  show_ProcessTaskRejected:string;
  show_ProcessTaskApproved:string;
  requester:string;
  IamSponsor:boolean;
}

const ApproveIcon: IIconProps = { iconName: 'Accept' };
const RejectIcon: IIconProps = { iconName: 'CalculatorMultiply' };


export default class ApprovalWorkflow extends React.Component<IApprovalWorkflowProps, IControls> {
   
  private _sitedecriptionchange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
    this.setState({Justification : newValue});
  }


  componentWillMount() {

    this._logicLanding();
    
  }

  constructor(props: IApprovalWorkflowProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
       requester:'',
       title: '',  
       description:'' ,
       url:'' ,
       Justification: '',
      IDRequest:0,
      IDTask:0,
      ApprovalStatus:'',
      isSponsor:false,
      TaskAssignedTo: 0,
      AccountName:'',
      Parameter:'',
      show_ApprovalForm: '',
      show_AlreadyTerminated:'',
      show_NotYourTask:'',
      show_RequestStatus:'',
      show_TaskAlreadyTerminated:'',
      show_NothigToDisplay:'',
      show_TaskRejected:'',
      show_TaskApproved:'',
      show_TaskCurrent:'',
      show_ScriptCreation:'',
      show_ProcessTaskRejected:'',
      show_ProcessTaskApproved:'',
      show_TaskPending:'',
      IamSponsor: false,
    };

  }

  private async _logicLanding(){
    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
 
    if(queryParameters.getValue("RequestID")){

      var UserID : number = parseInt(queryParameters.getValue("RequestID"));
      const userRequest = await sp.web.lists.getByTitle("REQUESTS").items.getById(UserID).get();
      
      const ReqStatus = userRequest["Status"];
      this.setState({url : userRequest["SiteUrl"]});
      if(ReqStatus == "Pending"){  this.setState({show_TaskPending:"show"});  }
      if(ReqStatus == "In Progress"){  this.setState({show_TaskCurrent:"show"});   }
      if(ReqStatus == "Rejected"){  this.setState({show_ProcessTaskRejected:"show"});   }
      if(ReqStatus == "Validated"){   this.setState({show_ProcessTaskApproved:"show"});  }
      if(ReqStatus == "Created"){   this.setState({show_ScriptCreation:"show"});  }

      this.setState({show_RequestStatus:'show'});
     }

    if(queryParameters.getValue("GuidTask")){
      const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><Eq> <FieldRef Name='Title'/> <Value Type='Text'>" + queryParameters.getValue("GuidTask") + "</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>"  };
         sp.web.lists.getByTitle("Workflow").getItemsByCAMLQuery(q).then(async (result: any[]) => {
           if(result.length == 0) {this.setState({show_NothigToDisplay:'show'}); }
           else{
           const IDRequest :number =  result[0]["IDRequest"];
           const statusRequest =  result[0]["APProvalStatus"];
           const TaskID : number= result[0]["ID"];
          const isSponsor :boolean = result[0]["isSponsor"];
          this.setState({IamSponsor:isSponsor});

           const TAT = await sp.web.lists.getByTitle("Workflow").items.getById(TaskID).select("TaskAssignedTo/Title", "TaskAssignedTo/EMail").expand("TaskAssignedTo").get();
           this.setState({IDRequest:IDRequest});
           this.setState({IDTask:TaskID});

           const request = await sp.web.lists.getByTitle("REQUESTS").items.getById(IDRequest).select("Status","Title","SiteUrl","Description","Author/Title").expand("Author").get();
           if(request["Status"] == "In Progress")
           {
             if(statusRequest != "Pending") { this.setState({show_TaskAlreadyTerminated:'show'}); }
             else{
              const myprofile = await sp.profiles.myProperties.get();
              if(TAT.TaskAssignedTo.EMail !=  myprofile.Email){
                this.setState({show_NotYourTask:'show'});  
              }else
               {
              this.setState({requester:request.Author.Title});
              this.setState({title:request["Title"]});
              this.setState({url:request["SiteUrl"]});
              this.setState({description:request["Description"]});
              this.setState({show_ApprovalForm:'show'});
              }

             }

           }else { this.setState({show_AlreadyTerminated:'show'});   }
           }
         });

    }

  }

  private async _Approve(newValue: string): Promise<void> {
    const request = await sp.web.lists.getByTitle("REQUESTS").items.getById(this.state.IDRequest).select("Status").get();
    if(request["Status"] == "In Progress")
    {
       const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><Eq> <FieldRef Name='IDRequest'/> <Value Type='Text'>" + this.state.IDRequest.toString() + "</Value></Eq></Where></Query></View>"  };
       const approvers:any[]  = await sp.web.lists.getByTitle("Workflow").getItemsByCAMLQuery(q);

      if(this.state.IamSponsor)
       {
        let validateRef :boolean = false;
        if(approvers.length == 1){validateRef = true;}  // No Referents
         approvers.forEach(element => { 
           if( !element["isSponsor"]){ 
              if(element["APProvalStatus"] == "Accepted") {validateRef = true;}  
            }
          });

          if(validateRef){
             const i = await sp.web.lists.getByTitle("REQUESTS").items.getById(this.state.IDRequest).update({
             Justification: this.state.Justification,
             Status: "Validated"
            });
           }
    }else{  //Référent
      let validateRef :boolean = false;
      approvers.forEach(element => { 
        if( element["isSponsor"]){ 
          if(element["APProvalStatus"] == "Accepted") {validateRef = true;}  
        }
      });

      if(validateRef){
            const i = await sp.web.lists.getByTitle("REQUESTS").items.getById(this.state.IDRequest).update({
            Justification: this.state.Justification,
            Status: "Validated"
          });
        }
    }

  }
    const i2 = await sp.web.lists.getByTitle("Workflow").items.getById(this.state.IDTask).update({
      Justification: this.state.Justification,
      APProvalStatus: "Accepted"
    });

    this.setState({show_ApprovalForm:''});
    this.setState({show_TaskApproved:'show'});
  }

  private async _Reject(newValue: string): Promise<void> {

    const i = await sp.web.lists.getByTitle("REQUESTS").items.getById(this.state.IDRequest).update({
      Justification: this.state.Justification,
      Status: "Rejected"
    });

    const i2 = await sp.web.lists.getByTitle("Workflow").items.getById(this.state.IDTask).update({
      Justification: this.state.Justification,
      APProvalStatus: "Rejected"
    });

    this.setState({show_ApprovalForm:''});
    this.setState({show_TaskRejected:'show'});

  }
  
  
  public render(): React.ReactElement<IApprovalWorkflowProps> {
    return (
      <div>

      <div style={{ display: (this.state.show_RequestStatus =="show"? 'block' : 'none') }} >
      <header className={styles.FormHeader}><Icon iconName="Flow" className={styles.Icon}/>{strings.STATUSREQUEST}</header>
         <div className={styles.messageresult}> {strings.MessRequest} <strong>https://bnpparibas.sharepoint.com/sites/{this.state.url}</strong> </div><br/>
          <div className={styles.stepdone}><Icon  iconName="NewTeamProject" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step1}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
          
          <div style={{ display: (this.state.show_TaskPending  =="show"? 'block' : 'none') }} >
              <div className={styles.step}><Icon  iconName="Flow" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step2}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
              <div className={styles.step}><Icon  iconName="Settings" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step3}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
              <div className={styles.step}><Icon  iconName="MailCheck" className={styles.smallIcon}  /><div className={styles.stepMesslast}> {strings.Step4} </div></div>
          </div>

          <div style={{ display: (this.state.show_ProcessTaskRejected  =="show"? 'block' : 'none') }} >
              <div className={styles.stepRjected}><Icon  iconName="Flow" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step2}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
              <div className={styles.step}><Icon  iconName="Settings" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step3}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
              <div className={styles.step}><Icon  iconName="MailCheck" className={styles.smallIcon}  /><div className={styles.stepMesslast}> {strings.Step4} </div></div>
          </div>

          <div style={{ display: (this.state.show_TaskCurrent  =="show"? 'block' : 'none') }} >
               <div className={styles.stepdCurrent}><Icon  iconName="Flow" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step2}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
               <div className={styles.step}><Icon  iconName="Settings" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step3}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
               <div className={styles.step}><Icon  iconName="MailCheck" className={styles.smallIcon}  /><div className={styles.stepMesslast}> {strings.Step4} </div></div>
         </div>

         <div style={{ display: (this.state.show_ProcessTaskApproved  =="show"? 'block' : 'none') }} >
               <div className={styles.stepdone}><Icon  iconName="Flow" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step2}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
               <div className={styles.stepdCurrent}><Icon  iconName="Settings" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step3}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
               <div className={styles.step}><Icon  iconName="MailCheck" className={styles.smallIcon}  /><div className={styles.stepMesslast}> {strings.Step4}</div></div>
         </div>
         <div style={{ display: (this.state.show_ScriptCreation =="show"? 'block' : 'none') }} >
               <div className={styles.stepdone}><Icon  iconName="Flow" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step2}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
               <div className={styles.stepdone}><Icon  iconName="Settings" className={styles.smallIcon}  /><div className={styles.stepMess}> {strings.Step3}</div> <Icon  iconName="ChevronRight" className={styles.bigIcon}  /></div>
               <div className={styles.stepdone}><Icon  iconName="MailCheck" className={styles.smallIcon}  /><div className={styles.stepMesslast}> {strings.Step4} </div></div>
         </div>
      </div>


      <div style={{ display: (this.state.show_AlreadyTerminated  =="show"? 'block' : 'none') }} >
        <header className={styles.FormHeader}><Icon iconName="Flow" className={styles.Icon}/>{strings.WORKFLOWTERMINATED}</header>
        <div className={styles.Box}>
        <div className={styles.carrouselItem}> <Icon iconName="ErrorBadge" className={styles.Icon} /> {strings.NoNeedAnymore}</div>
        </div>
      </div>

      <div style={{ display: (this.state.show_TaskRejected  =="show"? 'block' : 'none') }} >
        <header className={styles.FormHeader}><Icon iconName="Flow" className={styles.Icon}/>{strings.TASKCOMPLETED}</header>
        <div className={styles.Box}>
        <div className={styles.carrouselItem}> <Icon iconName="ErrorBadge" className={styles.Icon} />{strings.TaskRejected} </div>
        </div>
      </div>

      <div style={{ display: (this.state.show_TaskApproved  =="show"? 'block' : 'none') }} >
        <header className={styles.FormHeader}><Icon iconName="Flow" className={styles.Icon}/>{strings.TASKCOMPLETED}</header>
        <div className={styles.Box}>
        <div className={styles.carrouselItem}> <Icon iconName="ErrorBadge" className={styles.Icon} /> {strings.TaskApproved} </div>
        </div>
      </div>
      <div style={{ display: (this.state.show_TaskAlreadyTerminated  =="show"? 'block' : 'none') }} >
        <header className={styles.FormHeader}><Icon iconName="Flow" className={styles.Icon}/>{strings.TaskAlreadyProcess} </header>
        <div className={styles.Box}>
        <div className={styles.carrouselItem}> <Icon iconName="ErrorBadge" className={styles.Icon} /> {strings.NoNeedAnymore}  </div>
        </div>
      </div>

      <div style={{ display: (this.state.show_ApprovalForm  =="show"? 'block' : 'none') }} >
     <header className={styles.FormHeader}><Icon iconName="Flow" className={styles.Icon}/> {strings.APPROVALTASK}</header>
        <div className={styles.Box}>
        <div>{strings.ApproveOrReject}</div><br/><br/>
        <div className={styles.resumeRequest}>
          <table>
            <tr>
              <td className={styles.leftTD}>{strings.Requester}</td>
              <td className={styles.rightTD}>{this.state.requester}</td>
            </tr>
            <tr>
              <td className={styles.leftTD}>{strings.Title}</td>
              <td className={styles.rightTD}>{this.state.title}</td>
            </tr>
            <tr>
              <td className={styles.leftTD}>Url</td>
              <td className={styles.rightTD}>https://bnpparibas.sharepoint.com/sites/{this.state.url}</td>
            </tr>
            <tr>
              <td className={styles.leftTD}>Description</td>
              <td>{this.state.description}</td>
            </tr>
           </table>
         </div> 
           <br/>
           <TextField label="JUSTIFICATION :" underlined multiline  onChange={this._sitedecriptionchange.bind(this)}/> 
         <br/>
         <br/>
         <div className={styles.buttoncontainer}>
           <DefaultButton title={strings.Approve} className={styles.button} iconProps={ApproveIcon} text={strings.Approve} onClick={this._Approve.bind(this)} ></DefaultButton>
           <DefaultButton title={strings.Reject}  iconProps={RejectIcon} text={strings.Reject}  onClick={this._Reject.bind(this)} ></DefaultButton>
         </div>
        </div>
      </div>

      <div style={{ display: (this.state. show_NotYourTask  =="show"? 'block' : 'none') }} >
       <header className={styles.FormHeader}><Icon iconName="Flow" className={styles.Icon}/>{strings.APPROVALTASK} </header>
        <div className={styles.Box}>
        <div className={styles.carrouselItem}> <Icon iconName="ErrorBadge" className={styles.Icon} /> {strings.NotToYou} </div>
        </div>
      </div>

      <div style={{ display: (this.state.show_NothigToDisplay  =="show"? 'block' : 'none') }} >
        <div className={styles.Box}>
        <div className={styles.carrouselItem}> <Icon iconName="ErrorBadge" className={styles.Icon} />  {strings.NothingThere} </div>
        </div>
      </div>
   </div>
    );
  }
}
