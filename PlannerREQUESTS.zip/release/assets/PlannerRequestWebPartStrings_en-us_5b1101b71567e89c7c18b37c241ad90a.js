define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PlannerTitle":"Planner Name",
    "REQUIRED": "REQUIRED", 
    "PrimaryOwner":"Primary Owner",
    "SecondaryOwner":"Secondary Owner",
    "SAME": "Primary and secondary owners must be differents",
    "REQUESTIT": "Request your Planner",
    "FinalMessage" : "Your request has been received and will be processed within 1h. You will receive an automatic email once your Planner board is created",
    "NewRequest":"New REQUEST ?",
    "Header":"New Planner board request"
  }
});