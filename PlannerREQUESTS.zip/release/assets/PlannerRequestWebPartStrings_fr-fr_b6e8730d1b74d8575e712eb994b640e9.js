define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "PlannerTitle":"Nom du Planner",
    "REQUIRED": "Obligatoire", 
    "PrimaryOwner":"Premier propriétaire",
    "SecondaryOwner":"Deuxième propriétaire",
    "SAME": "Les propriétaires doivent être différents",
    "REQUESTIT": "Demander votre Planner",
    "FinalMessage" : "Votre demande a bien été reçue et sera traitée sous 1h. Vous recevrez un mail automatique dès que votre espace Planner sera créé",
    "NewRequest":"Nouvelle requête ?",
    "Header":"Nouvelle demande d'espace Planner"
  }
});