declare interface IPlannerRequestWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  PlannerTitle:string;
  REQUIRED :string;
  PrimaryOwner:string;
  SecondaryOwner:string;
  SAME:string;
  REQUESTIT:string;
  FinalMessage:string;
  NewRequest:string;
  Header:string;
}

declare module 'PlannerRequestWebPartStrings' {
  const strings: IPlannerRequestWebPartStrings;
  export = strings;
}
