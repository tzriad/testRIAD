import { WebPartContext } from '@microsoft/sp-webpart-base';  
export interface IPlannerRequestProps {
  description: string;
  context: WebPartContext; 
}
