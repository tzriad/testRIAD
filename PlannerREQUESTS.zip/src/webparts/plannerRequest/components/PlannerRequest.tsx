import * as React from 'react';
import styles from './PlannerRequest.module.scss';
import { IPlannerRequestProps } from './IPlannerRequestProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as strings from 'PlannerRequestWebPartStrings';

import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import {  MessageBar, MessageBarType } from 'office-ui-fabric-react';

import { sp } from "@pnp/sp";  
import "@pnp/sp/webs";  
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  

export interface IControls
{
  Name: string;  
  PrimaryOwner: number ;
  SecondaryOwner: number ;
  errorOwner1:boolean ;
  errorOwner2:boolean ;
  errorTitle:boolean ;
  errorSame:boolean;
  Final :boolean;
}


export default class PlannerRequest extends React.Component<IPlannerRequestProps, IControls> {
 
  constructor(props: IPlannerRequestProps) {  
    super(props);  
   
    sp.setup({  spfxContext: props.context  });

    this.state = {  
      Name: '',  
      PrimaryOwner: 0 ,
      SecondaryOwner: 0 ,
      errorOwner1:false ,
      errorOwner2:false,
      errorSame: false,
      errorTitle:false ,
      Final:false
    }
  }
 
 
  private _Plannertitlechange(newValue: any): void {  
    console.log(newValue.target.defaultValue);
    if(newValue.length == 0){
      this.setState({errorTitle: true});
      this.setState({Name: ""});
    }else{  
      this.setState({errorTitle: false});
      this.setState({Name: newValue.target.defaultValue});
      
    }
  }
 

  private async _getPrimaryOwner(items: any) { 
    if(items.length == 0){
      
      this.setState({errorOwner1:  true});
    }else {
      this.setState({errorOwner1: false});

      if((this.state.SecondaryOwner != 0) && (items[0].id == this.state.SecondaryOwner ))
      {
       this.setState({errorSame:  true});
      }else{
       this.setState({ PrimaryOwner: items[0].id });  
       this.setState({errorSame:  false});
      }
      
         }
  }


  private async _getSecondaryOwner(items: any) { 
    console.log( items[0].id );
    if(items.length == 0){
      this.setState({errorOwner2:  true});
      this.setState({errorSame:  false});
    }else {
         this.setState({errorOwner2: false});

         if((this.state.PrimaryOwner != 0) && (items[0].id == this.state.PrimaryOwner ))
         {
          this.setState({errorSame:  true});
         }else{
          this.setState({ SecondaryOwner: items[0].id });  
          this.setState({errorSame:  false});
         }
         
         }
  }

  private _newRequest():void{  window.location.href = window.location.href; }

  private _placeRequest():void{
    var stop = false;
    if(this.state.Name.length == 0){this.setState({errorTitle: true});stop= true;}
    if(this.state.PrimaryOwner == 0){this.setState({errorOwner1: true});stop= true;}
    if(this.state.SecondaryOwner == 0){this.setState({errorOwner2: true});stop= true;}

    if(stop) return; 
      
    sp.web.lists.getByTitle("REQUESTS").items.add({  
       Title : this.state.Name,
       PrimaryOwnerId: this.state.PrimaryOwner,
       SecondaryOwnerId: this.state.SecondaryOwner
       }) ;

      this.setState({Final:true});
 }



  public render(): React.ReactElement<IPlannerRequestProps> {
    return (
      <div><div style={{ display: (this.state.Final ? 'none' : 'block') }}>
       <header className={styles.FormHeader}><Icon iconName="AllApps"  className={styles.Icon}/>{strings.Header}</header>
       <div className={styles.Box}>
       <TextField   label={strings.PlannerTitle}  required   onChange={this._Plannertitlechange.bind(this)}/> 
      <div className={styles.errorMessage} style={{ display: (this.state.errorTitle? 'block' : 'none') }}>{strings.REQUIRED}</div>

        <br/>
        <PeoplePicker 
        required={true}
        context={this.props.context}
        titleText={strings.PrimaryOwner}
        personSelectionLimit={1} 
        showtooltip={false} 
        disabled={false}
        onChange={this._getPrimaryOwner.bind(this)}
        showHiddenInUI={false}
        ensureUser={true}
        principalTypes={[PrincipalType.User]}
        resolveDelay={1000} />
        <div className={styles.errorMessage} style={{ display: (this.state.errorOwner1 ? 'block' : 'none') }}>{strings.REQUIRED}</div>

        <br/>
        <PeoplePicker 
        required={true}
        context={this.props.context}
        titleText={strings.SecondaryOwner}
        personSelectionLimit={1} 
        showtooltip={false} 
        disabled={false}
        onChange={this._getSecondaryOwner.bind(this)}
        showHiddenInUI={false}
        ensureUser={true}
        principalTypes={[PrincipalType.User]}
        resolveDelay={1000} />
        <div className={styles.errorMessage} style={{ display: (this.state.errorOwner2 ? 'block' : 'none') }}>{strings.REQUIRED}</div>
        <div className={styles.errorMessage} style={{ display: (this.state.errorSame ? 'block' : 'none') }}>{strings.SAME}</div>

        <br/>
        <DefaultButton title={strings.REQUESTIT} className={styles.button}  text={strings.REQUESTIT} onClick={this._placeRequest.bind(this)} ></DefaultButton>
        
        </div>
        </div>
        <div style={{ display: (this.state.Final ? 'block' : 'none') }}>
        <MessageBar  messageBarType={MessageBarType.success}    isMultiline={true}>
             {strings.FinalMessage}<br/><br/>
       </MessageBar>
       <div className={styles.buttoncontainer}>
            <DefaultButton title={strings.NewRequest} className={styles.button}  text={strings.NewRequest} onClick={this._newRequest.bind(this)} ></DefaultButton>
        </div>
        </div>
        </div>
    );
  }
}
