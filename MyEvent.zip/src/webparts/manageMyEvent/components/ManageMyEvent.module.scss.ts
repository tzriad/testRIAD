/* tslint:disable */
require("./ManageMyEvent.module.css");
const styles = {
  manageMyEvent: 'manageMyEvent_bd9301cc',
  container: 'container_bd9301cc',
  DialogContainer: 'DialogContainer_bd9301cc',
  greenIcon: 'greenIcon_bd9301cc',
  redIcon: 'redIcon_bd9301cc',
  orangeIcon: 'orangeIcon_bd9301cc',
  tdleft: 'tdleft_bd9301cc',
  tdleft2: 'tdleft2_bd9301cc',
  Next: 'Next_bd9301cc',
  row: 'row_bd9301cc',
  column: 'column_bd9301cc',
  'ms-Grid': 'ms-Grid_bd9301cc',
  title: 'title_bd9301cc',
  subTitle: 'subTitle_bd9301cc',
  description: 'description_bd9301cc',
  button: 'button_bd9301cc',
  label: 'label_bd9301cc'
};

export default styles;
/* tslint:enable */