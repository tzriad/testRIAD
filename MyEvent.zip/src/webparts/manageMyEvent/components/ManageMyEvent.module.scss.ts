/* tslint:disable */
require("./ManageMyEvent.module.css");
const styles = {
  manageMyEvent: 'manageMyEvent_534806f1',
  container: 'container_534806f1',
  DialogContainer: 'DialogContainer_534806f1',
  greenIcon: 'greenIcon_534806f1',
  errorMessage: 'errorMessage_534806f1',
  redIcon: 'redIcon_534806f1',
  orangeIcon: 'orangeIcon_534806f1',
  tdleft: 'tdleft_534806f1',
  tdleft2: 'tdleft2_534806f1',
  Next: 'Next_534806f1',
  row: 'row_534806f1',
  column: 'column_534806f1',
  'ms-Grid': 'ms-Grid_534806f1',
  title: 'title_534806f1',
  subTitle: 'subTitle_534806f1',
  description: 'description_534806f1',
  button: 'button_534806f1',
  label: 'label_534806f1'
};

export default styles;
/* tslint:enable */