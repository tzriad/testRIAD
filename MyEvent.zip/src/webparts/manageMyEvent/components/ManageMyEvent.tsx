import * as React from 'react';
import styles from './ManageMyEvent.module.scss';
import { Espace, EventHoraires, IManageMyEventProps,Prestations } from './IManageMyEventProps';
import { escape } from '@microsoft/sp-lodash-subset';
import {
  MessageBarButton,
  Link,
  Stack,
  StackItem,
  MessageBar,
  MessageBarType,
  ChoiceGroup,
  IChoiceGroupOption,
  IStackProps,
  PivotLinkFormat,
  Dialog,
  DialogFooter,
  PrimaryButton,
  DatePicker,
  Checkbox,
  Label,
  IconButton,
  ActionButton,
  Panel,
  PanelType,
  DialogType,
  Spinner
} from 'office-ui-fabric-react';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { FilePicker, IFilePickerResult } from '@pnp/spfx-controls-react/lib';
import { DateTimePicker, DateConvention, TimeConvention, TimeDisplayControlType } from '@pnp/spfx-controls-react/lib/DateTimePicker';
import { TextField } from 'office-ui-fabric-react/lib/TextField'; 
import {Dropdown, IDropdownOption} from 'office-ui-fabric-react/lib/Dropdown';
import { FontIcon, IIconProps } from 'office-ui-fabric-react/lib/Icon';
import { Pivot,PivotItem, IPivotItemProps } from 'office-ui-fabric-react';
import { sp } from "@pnp/sp";  
import "@pnp/sp/webs";  
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/lists";  
import "@pnp/sp/items";  
import "@pnp/sp/profiles";  
import "@pnp/sp/site-users/web";
import "@pnp/sp/regional-settings/web"
import { ICamlQuery } from "@pnp/sp/lists";
import { DefaultButton } from 'office-ui-fabric-react/lib/components/Button/DefaultButton/DefaultButton';
import { IContextInfo } from "@pnp/sp/sites";
import { UrlQueryParameterCollection } from '@microsoft/sp-core-library';


const EventType : IDropdownOption[] = [
  {key:"Buffet", text:"Buffet"},
  {key:"Cocktail", text:"Cocktail"},
  {key:"Concert", text:"Concert"},
  {key:"Conférence", text:"Conférence"},
  {key:"Exposition", text:"Exposition"},
  {key:"Projection de film", text:"Projection de film"},
  {key:"Restauration assise", text:"Restauration assise"},
  {key:"Soirée", text:"Soirée"},
  {key:"Autre", text:"Autre"},

];

const Entree : IChoiceGroupOption[] = [
  { key : "Sur Invitation interne", text : "Sur invitation interne"},
  { key : "Pas d'invitation interne nécessaire", text : "Pas d'invitation interne nécessaire"}
];

const accessParking : IChoiceGroupOption[] = [
  { key : "Oui", text : "Oui"},
  { key : "Non", text : "Non"}
];

const vestiaires : IChoiceGroupOption[] = [
  { key : "Oui", text : "Oui"},
  { key : "Non", text : "Non"}
];


const accessQuaiLivraison : IChoiceGroupOption[] = [
  { key : "Oui", text : "Oui"},
  { key : "Non", text : "Non"}
];

const Panneaux : IChoiceGroupOption[] = [
  { key : "Oui", text : "Oui"},
  { key : "Non", text : "Non"}
];

const PrestaChoiceOptions : IChoiceGroupOption[] = [
  { key : "OK", text : "Oui, j'en ai besoin"},
  { key : "NO", text : "Non, J'en ai pas besoin"},
  { key : "Idle", text : "Je ne sais pas encore"}
];

const modelProps ={
 isBlocking : true,
 topOffsetFixed : true,
 className : styles.DialogContainer,
};

export interface IControls
{
  title: string;  
  type : string;
  Description : string;
  responsable : string[];
  organizer : string[];
  organizer_entity : string;
  organizer_tel : string;
  organizer_email : string;
  condition_entree : string;
  organizer_details: boolean;
  billing_entity: string;
  billing_contact: string;
  billing_business: string;
  billing_siret : string;
  billing_address: string;
  billing_costCenter : string;
  villes: IDropdownOption[];
  immeubles :IDropdownOption[];
  prestations: Prestations[];
  SelectedPrestation  : Prestations;
  espaces : Espace[];
  pool_espace :Espace[];
  selected_espace :Espace[];
  selectedAdress:string;
  SelectedImmeuble: string;
  SelectedVille: string;
  SelectedPrestaPosition : number;
  Horaires : EventHoraires;
  HoraireString: string;
  nb_collab_bnpp : number;
  nb_collab_bnpp_extern : number;
  nb_non_collab_bnpp: number;
  nb_vip_extern_site:number;
  nb_vip_extern_bnpp : number;
  nb_psh : number;
  nb_mineurs: number;
  nb_presta : number;
  nb_totalParticipants: number;
  nb_choosenPlace : number;
  stage_one : boolean;
  display_required : boolean;
  ShowDialog: boolean;
  ShowDialog2: boolean;
  ShowDialog3: boolean;
  ShowDialog4: boolean;
  showSave : boolean;
  hideNext: boolean,
  SelectedPivot :number;
  ImagesEspaces: string;
  fileName1: string;
  file1 : IFilePickerResult;
  file2 : IFilePickerResult;
  file3 : IFilePickerResult;
  file4 : IFilePickerResult;
  file5 : IFilePickerResult;
  file6 : IFilePickerResult;
  file1Url : string;
  file2Url : string;
  file3Url : string;
  file4Url : string;
  file5Url : string;
  file6Url : string;
  fileName2: string;
  fileName3: string;
  fileName4: string;
  fileName5: string;
  fileName6: string;
  displayH2: boolean;
  displayH3: boolean;
  showPanel: boolean;
  Confirmation : boolean;
  EventCreated : boolean;
  EventUpdated : boolean;
  EventStatus : string,
  Loading : boolean;
  OrganizerId:  number;
  ResponsableId : number;
  DisplayForm : boolean;
  DisplaySummary : boolean;
  ThisIsMyEvent : boolean;
  IamEventOfficer : boolean;
  NoEventWithThisID : boolean;
  Status : string;
}

const ApproveIcon: IIconProps = { iconName: 'Bill' };
const CancelIcon: IIconProps = { iconName: 'CalculatorNotEqualTo' };
const ApprouverIcon: IIconProps = { iconName: 'BoxCheckmarkSolid' };
const RejectIcon: IIconProps = { iconName: 'BoxMultiplySolid' };
const NextIcon: IIconProps = { iconName: 'ChevronRightSmall' };
const PrevIcon: IIconProps = { iconName: 'ChevronLeftSmall' };
const SaveIcon: IIconProps = { iconName: 'Save' };
const AddRange: IIconProps = { iconName: 'Add' };
const RemoveRange: IIconProps = { iconName: 'Remove' };
const AddPresta: IIconProps = { iconName: 'AddNotes' };
const Delete: IIconProps = { iconName: 'Delete' };

export default class ManageMyEvent extends React.Component<IManageMyEventProps, IControls> {

  async componentWillMount() {
    await this._logicLanding();
  }

  constructor(props: IManageMyEventProps) {  
    super(props);  
   
  sp.setup({  spfxContext: props.context  });

  this.state = {  
  title: '',
  type :'',
  Description : '',
  responsable : [],
  organizer : [],
  organizer_entity : '',
  organizer_tel : '',
  organizer_email : '',
  organizer_details : false,
  condition_entree : 'Sur Invitation interne',
  billing_entity: '',
  billing_contact: '',
  billing_business: '',
  billing_address:'',
  billing_siret : '',
  billing_costCenter : '',
  villes : [],
  immeubles : [],
  espaces :[],
  prestations:[],
  SelectedPrestation : null,
  pool_espace:[],
  selected_espace :[],
  selectedAdress:'',
  SelectedImmeuble : '',
  SelectedVille: '',
  SelectedPrestaPosition : -1,
  Horaires : null,
  HoraireString: '',
  nb_collab_bnpp : 0,
  nb_collab_bnpp_extern : 0,
  nb_non_collab_bnpp: 0,
  nb_vip_extern_site:0,
  nb_vip_extern_bnpp : 0,
  nb_psh : 0,
  nb_mineurs: 0,
  nb_presta : 0,
  nb_totalParticipants: 0,
  nb_choosenPlace: 0,
  stage_one : true,
  display_required : false,
  showSave: false,
  hideNext : false,
  ShowDialog: false,
  ShowDialog2: false,
  ShowDialog3: false,
  ShowDialog4: false,
  SelectedPivot :0,
  ImagesEspaces:'',
  fileName1: '',
  file1 : null,
  file2 : null,
  file3 : null,
  file4 : null,
  file5 : null,
  file6 : null,
  file1Url : '',
  file2Url : '',
  file3Url : '',
  file4Url : '',
  file5Url : '',
  file6Url : '',
  fileName2: '',
  fileName3: '',
  fileName4: '',
  fileName5: '',
  fileName6: '',
  displayH2: false,
  displayH3: false,
  showPanel: false,
  Confirmation: false,
  EventCreated : false,
  EventUpdated: false,
  EventStatus : '',
  Loading : false,
  OrganizerId: 0,
  ResponsableId : 0,
  DisplayForm: false,
  DisplaySummary : false,
  ThisIsMyEvent : true,
  IamEventOfficer : false,
  NoEventWithThisID : false,
  Status : "En cours"
    };
  }

  private _show = () => {
    this.setState({ showPanel: true });
  }

  private _hideMenu = () => {
    this.setState({ showPanel: false });
  }

  private Confirm(){
    this.setState({Confirmation:false});
  }

  private Ignore(){
    this.setState({Confirmation:false});
  }

  private hiddenWindow(){
    this.setState({Confirmation:true});
  }

  private async _logicLanding(){

    var Horaire : EventHoraires = {
      startDate1: new Date(Date.now()),
      startDate1_TolocalDate :'',
      startDate1_TolocalTime:'',
      endDate1: new Date(Date.now()),
      endDate1_TolocalDate:'',
      endDate1_TolocalTime:'',
      startDate2:new Date(Date.now()),
      startDate2_TolocalDate:'',
      startDate2_TolocalTime:'',
      endDate2:new Date(Date.now()),
      endDate2_TolocalDate:'',
      endDate2_TolocalTime:'',
      startDate3:new Date(Date.now()),
      startDate3_TolocalDate:'',
      startDate3_TolocalTime:'',
      endDate3:new Date(Date.now()),
      endDate3_TolocalDate:'',
      endDate3_TolocalTime:''
    };
    this.setState({Horaires : Horaire});

    var EventPrestations : Prestations[] = new Array();

    var SelectedPresta : Prestations = {
      label: '',
      choix : '',
      message :'',
      messageType : 'Warning',
      precisions: false, precisions_value: '',
      displaydetails : false,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
      accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
      PanneauxNombre : '',  Hotessedisplay: true,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
      this.setState({SelectedPrestation : SelectedPresta});

    var Presta_Accueil : Prestations = {
      label: 'Acceuil',
      choix : '',
      message :"Si vous l'avez déjà identifiée, veuillez préciser le nom et les coordonnées de la société. IMEX peut vous proposer une prestation de service. Votre Event Officer vous contactera dans ce sens.",
      messageType : 'Warning',
      precisions: false, precisions_value: '',
      displaydetails : true,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
      accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
      PanneauxNombre : '',  Hotessedisplay: true,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
      EventPrestations.push(Presta_Accueil);

    var Presta_Security : Prestations = {
    label : 'Sécurité',
    choix : 'Hide',
    message :'Sur cette catégorie de prestation, IMEX détermine le dispositif nécessaire en fonction de la nature et des caractéristiques de votre événement. Votre Event Offier prendra contact avec vous pour préciser les modalités le cas échéant.',
    messageType : 'SeverityWarning',
    precisions: false, precisions_value: '',
    displaydetails : false,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
    accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
    PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
    EventPrestations.push(Presta_Security);

    var Presta_MiseEnPropre : Prestations = {
      label : 'Prestation de mise en propreté',
      choix : 'Hide',
      message :"Pour information : Prestation ménage post évènement si nécessaire / Lorque deux événements ont lieu le même jour, un devis ménage devra être pris en charge par les organisateurs du 1er événement afin que l'espace soit nettoyé entre les deux événements",
      messageType : 'SeverityWarning',
      precisions: false, precisions_value: '',
      displaydetails : false,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
      accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
      PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
      EventPrestations.push(Presta_MiseEnPropre);

    var Presta_DecorationFlorale : Prestations = {
        label : 'Décoration florale',
        choix : '',
        message :"Un prestataire sous contrat peut être proposé par IMEX. Si vous l'avez déjà identifiée, veuillez préciser le nom et les coordonnées de la société.",
        messageType : 'Warning',
        precisions: false, precisions_value: '',
        displaydetails : true,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
        accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
        PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false, HotesseUniforme:''    };
        EventPrestations.push(Presta_DecorationFlorale);
    
    var Presta_Traiteur : Prestations = {
          label : 'Traiteur/Restauration',
          choix : '',
          message :"Un prestataire sous contrat peut être proposé par IMEX. Si vous l'avez déjà identifiée, veuillez préciser le nom et les coordonnées de la société.",
          messageType : 'Warning',
          precisions: false, precisions_value: '',
          displaydetails : true,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
          accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
          PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
          EventPrestations.push(Presta_Traiteur);

    var Presta_Mobilier : Prestations = {
          label : 'Mobilier',
          choix : '',
          message :"Si vous l'avez déjà identifiée, veuillez préciser le nom et les coordonnées de la société.",
          messageType : 'Warning',
          precisions: false, precisions_value: '',
          displaydetails : true,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
          accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
          PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
          EventPrestations.push(Presta_Mobilier);
 
    var Presta_Demenagement : Prestations = {
          label : 'Déménagement',
          choix : '',
          message :"Si vous l'avez déjà identifiée, veuillez préciser le nom et les coordonnées de la société. Pour vos demandes de déménagement, vous pouvez aussi vous adresser à PARIS IMEX DEMENAGEMENT, en mettant votre Event Officer en copie",
          messageType : 'Warning',
          precisions: false, precisions_value: '',
          displaydetails : false,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
          accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
          PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
          EventPrestations.push(Presta_Demenagement);

     var Presta_Signalitique : Prestations = {
              label : 'Signalétique',
              choix : '',
              message :"La conception de l'affichage, le positionnement et la remise en place des panneaux d'affichage sont à la charge de l'organisateur.",
              messageType : 'Warning',
              precisions: false, precisions_value: '',
              displaydetails : true,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
              accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : true, PanneauxAffichage : false,
              PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
              EventPrestations.push(Presta_Signalitique);

     var Presta_Audiovisuel : Prestations = {
              label : 'Audiovisuel',
              choix : '',
              message :"IMEX détermine le dispositif nécessaire en fonction de la nature et des caractéristiques de votre évènement. Votre Event Officer prendra contact avec vous pour préciser les modalités le cas échéant.",
              messageType : 'SeverityWarning',
              precisions: true, precisions_value: '',
              displaydetails : false,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
              accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
              PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
              EventPrestations.push(Presta_Audiovisuel);

      var Presta_BesoinsTech : Prestations = {
              label : 'Autres types de besoins techniques',
              choix : '',
              message :"",
              messageType : '',
              precisions: true, precisions_value: '',
              displaydetails : false,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
              accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
              PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
              EventPrestations.push(Presta_BesoinsTech);

      var Presta_AgenceCom : Prestations = {
              label : 'Agence de communication événementielle',
              choix : '',
              message :"Si vous l'avez déjà identifiée, veuillez préciser le nom et les coordonnées de la société.",
              messageType : 'Warning',
              precisions: false, precisions_value: '',
              displaydetails : true,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
              accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
              PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false , HotesseUniforme:''   };
              EventPrestations.push(Presta_AgenceCom);
      
       var Presta_Autres : Prestations = {
              label : 'Autres',
              choix : '',
              message :"",
              messageType : '',
              precisions: true, precisions_value: '',
              displaydetails : false,   company : '',    referent : '',    referentTel : '',    referentMail: '',    date : null,    numImmatriculation: '',
              accessParking: false,    accesQuaiLivraison : false,  otherNeed: '',  PanneauAffichagedisplay : false, PanneauxAffichage : false,
              PanneauxNombre : '',  Hotessedisplay: false,  HotesseNombre :'',  HotesseProfile : '',  HotesseVestiaire : false, HotesseUniforme:''    };
              EventPrestations.push(Presta_Autres);

    this.setState({prestations : EventPrestations});
    const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><Eq><FieldRef Name='Actif'/><Value Type='Boolean'>1</Value></Eq></Where></Query></View>"  };
    const Req_Immeulbles:any[]  = await sp.web.lists.getByTitle("Immeubles").getItemsByCAMLQuery(q);
    var Local_Espaces : Espace[] = new Array() ;
    var tempvilles = [];
    var tempImmeubles = [];
     Req_Immeulbles.forEach(element => { 
      var new_space : Espace ={
        ville: element["Ville"],
        immeuble: element["Title"],
        capacite: element["Capacite"],
        Desc: element["DetailIm"],
        espace : element["Espace"],
        defaultChecked: false,
        address: element["Adresse"]
      };

    if( tempvilles.map((el)=> el.key).indexOf(element["Ville"])== -1)  {  tempvilles.push({key:element["Ville"], text:element["Ville"]}) ; }
    if( tempImmeubles.map((el)=> el.text).indexOf(element["Title"]) == -1)  {  tempImmeubles.push({key:element["Title"], text:element["Title"]}) ; }
    Local_Espaces.push(new_space);
    });
    this.setState({espaces : Local_Espaces});
    this.setState({ villes : tempvilles});
    this.setState({ immeubles : tempImmeubles});


    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
    if(queryParameters.getValue("myeventid")){
     var idEvent = parseInt(queryParameters.getValue("myeventid"));
    const myprofile = await sp.profiles.myProperties.get();
    var EventRequest = null
   
    try{
    const EventRequestSRC = await sp.web.lists.getByTitle("Demandes").items.getById(idEvent).get();
    EventRequest = EventRequestSRC
    }catch{
      console.log("Pas trouvé");  
       this.setState({NoEventWithThisID : true});
       return;
     }

     let user = await sp.web.getUserById(parseInt(EventRequest["AuthorId"])).get();
     let user2 = await sp.web.getUserById(parseInt(EventRequest["ResponsableEventId"])).get();
     let user3 = await sp.web.getUserById(parseInt(EventRequest["OrganisateurEventId"])).get();
     var tempsRest = [];tempsRest.push(user2.Email);
     this.setState({responsable : tempsRest});

     var tempsOrg = [];tempsOrg.push(user3.Email);
     this.setState({organizer : tempsOrg});

    // Récupérer l'EventOFficer + Backup ici , en se basant sur l'immeuble.
      const q: ICamlQuery = {  ViewXml: "<View>><Query><Where><Eq> <FieldRef Name='Title'/> <Value Type='Text'>" + EventRequest["Immeuble"] + "</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>"  };
      const ImmeubleQuery =  await sp.web.lists.getByTitle("Immeubles").getItemsByCAMLQuery(q);
      let user4 = await sp.web.getUserById(parseInt(ImmeubleQuery[0]["PEI_EventId"])).get();  // Event Officer
      let user5 = await sp.web.getUserById(parseInt(ImmeubleQuery[0]["REIId"])).get();        // Son backup
   
     // N'afficher l'événement que si faisant partie des 5 profiles : l'auteur, organisateur, Responsable, L'event Officer ou son backup
     if(user.LoginName != myprofile.AccountName && user2.LoginName != myprofile.AccountName  && user3.LoginName != myprofile.AccountName && user4.LoginName != myprofile.AccountName && user5.LoginName != myprofile.AccountName )  
     {
      this.setState({ThisIsMyEvent : false});
      this.setState({DisplaySummary : false});
      this.setState({DisplayForm : false});
      this.setState({NoEventWithThisID : true});
      
      console.log("NOT VALID PROFIL");
      return;
     }

     if(user4.LoginName == myprofile.AccountName || user5.LoginName == myprofile.AccountName)
     { 
      this.setState({IamEventOfficer:true} );
     }

    // Get all the data 'Event' tab
    this.setState({Status: EventRequest["Statut"]} ); 
    this.setState({title: EventRequest["Title"]} ); 
    this.setState({type: EventRequest["TypeEvent"]} ); 
    this.setState({Description: EventRequest["Presentation"]} ); 
    this.setState({condition_entree: EventRequest["ConditionEntree"]} ); 
    this.setState({ ResponsableId: EventRequest["ResponsableEventId"]});
    this.setState({ OrganizerId: EventRequest["OrganisateurEvent"]});
    this.setState({ organizer_entity: EventRequest["EntiteOrganisatrice"]});
    this.setState({ organizer_email: EventRequest["MailResponsable"]});
    this.setState({ organizer_tel: EventRequest["TelResponsable"]});

    //Billing information
    this.setState({ billing_contact: EventRequest["Billing_Contact"]});
    this.setState({ billing_entity: EventRequest["Billing_Entite"]});
    this.setState({ billing_business: EventRequest["Billing_Metier"]});
    this.setState({ billing_address: EventRequest["Billing_Adresse"]});
    this.setState({ billing_siret: EventRequest["Billing_Siret"]});
    this.setState({ billing_costCenter: EventRequest["Billing_CentreCout"]});

    // Planning & lieu
    this.setState({ SelectedImmeuble: EventRequest["Immeuble"]});
    this.setState({ SelectedVille: EventRequest["Ville"]});
    this.setState({ selectedAdress: EventRequest["Adresse"]});
    this.setState({ HoraireString: EventRequest["Horaires"]});

    //traitement spéciale pour récupérer les espaces avec leur capacités
    var selSpc = EventRequest["Espaces"].split(',');
    var tempespaces = [];
    selSpc.forEach(spc => {  Local_Espaces.forEach(element => {  if(element.espace == spc && element.immeuble == EventRequest["Immeuble"]){ tempespaces.push(element) }  });  });
    this.setState({selected_espace : tempespaces});
    
    //Participants
    this.setState({ nb_collab_bnpp: EventRequest["NBCollabBNPP"]});
    this.setState({ nb_collab_bnpp_extern: EventRequest["nbCollabBNPPExterneSite"]});
    this.setState({ nb_vip_extern_site: EventRequest["InviteVIPBNPP"]});
    this.setState({ nb_non_collab_bnpp: EventRequest["NBCollabExterneBNPP"]});
    this.setState({ nb_vip_extern_bnpp: EventRequest["InviteVIPExterneBNPP"]});
    this.setState({ nb_mineurs: EventRequest["Accompagnant"]});
    this.setState({ nb_psh: EventRequest["PSH"]});
    this.setState({ nb_presta: EventRequest["nbPresta"]});
    var localnbtotal  = EventRequest["nbPresta"] + EventRequest["PSH"]+ EventRequest["Accompagnant"]+ EventRequest["InviteVIPExterneBNPP"]+ EventRequest["NBCollabExterneBNPP"]+ EventRequest["InviteVIPBNPP"]+ EventRequest["nbCollabBNPPExterneSite"]+ EventRequest["NBCollabBNPP"];
    this.setState({nb_totalParticipants : localnbtotal });

    try{
   // Pieces Jointes
   if(EventRequest["FolderAttachment_ID"]!= null) //créé dans après migration
   {
    var idfolder= parseInt(EventRequest["FolderAttachment_ID"]);
    const itemsFolder = (await sp.web.lists.getByTitle("AttachmentsEvent").items.getById(idfolder).folder.files().then()).forEach(
      async thisfile => {
        const fileitem =  await sp.web.getFileByServerRelativePath(thisfile.ServerRelativeUrl).getItem();
        const detailsF = await fileitem;
        
        if(detailsF["TypeFile"] == "ListeIntervenants"){
          this.setState({fileName5 : thisfile.Name });
          this.setState({file5Url : thisfile.ServerRelativeUrl });
        }

        if(detailsF["TypeFile"] == "PlanPrevisionnel"){
          this.setState({fileName1 : thisfile.Name });
          this.setState({file1Url : thisfile.ServerRelativeUrl });
        }

        if(detailsF["TypeFile"] == "ListeInvites"){
          this.setState({fileName3 : thisfile.Name });
          this.setState({file3Url : thisfile.ServerRelativeUrl });
        }

        if(detailsF["TypeFile"] == "Autres"){
          this.setState({fileName6 : thisfile.Name });
          this.setState({file6Url : thisfile.ServerRelativeUrl });
        }

       if(detailsF["TypeFile"] == "PlanImplementation"){
          this.setState({fileName2 : thisfile.Name });
          this.setState({file2Url : thisfile.ServerRelativeUrl });
        }

        if(detailsF["TypeFile"] == "PVReactionFeu"){
          this.setState({fileName4 : thisfile.Name });
          this.setState({file4Url : thisfile.ServerRelativeUrl });
        }

      });
   
   }

    }catch {  console.log("Erreur lors du chargement des documents");  }

  if(EventRequest["Prestations_IDs"]!= null) //Chargement des prestations
   {
    let PrestaIDs = EventRequest["Prestations_IDs"].split(',');
    var ViewPrestations : Prestations[] = new Array();
    PrestaIDs.map( async (e: string )=> {
    console.log(e);
    if(e.length > 0)
    {
      const Presta = await sp.web.lists.getByTitle("Prestations").items.getById(parseInt(e)).get();
      console.log(Presta["TypePresta"]);
      
      var PrestaItem : Prestations = {
      label: Presta["TypePresta"],
      choix : 'OK',
      message :"Si vous l'avez déjà identifiée, veuillez préciser le nom et les coordonnées de la société. IMEX peut vous proposer une prestation de service. Votre Event Officer vous contactera dans ce sens.",
      messageType : 'Warning',
      precisions: false, 
      precisions_value: Presta["Precision"],
      displaydetails : true,   
      company : Presta["NomSociete"],   
      referent : (Presta["NomReferent"]!= null ? Presta["NomReferent"]  : ""),    
      referentTel : Presta["TelReferent"], 
      referentMail: Presta["MailReferent"],     
      date : null,    
      numImmatriculation: (Presta["Immatriculation"] != null ? Presta["Immatriculation"]  : ""), 
      accessParking: Presta["Parking"],     
      accesQuaiLivraison : Presta["QuaiLivraison"],   
      otherNeed: (Presta["AutresBesoin"] != null ? Presta["AutresBesoin"]  : ""),
      PanneauAffichagedisplay : false, 
      PanneauxAffichage : Presta["Potelets"],
      PanneauxNombre : Presta["NombrePotelet"],  
      Hotessedisplay: false,  
      HotesseNombre :Presta["NombreHotesse"], 
      HotesseProfile : (Presta["ProfilHotesses"]!= null ? Presta["ProfilHotesses"]  : ""),   
      HotesseVestiaire : Presta["Vestiaire"],
      HotesseUniforme:(Presta["exigenceUnifrme"]!= null ? Presta["exigenceUnifrme"]  : "")  };
    
      ViewPrestations.push(PrestaItem);
      this.setState({prestations : ViewPrestations});
    }
    });

   
   }

    //Adapter l'affichage.
    this.setState({ThisIsMyEvent : true});
    this.setState({DisplaySummary : true});
    this.setState({DisplayForm : true});
    this.setState({NoEventWithThisID : false});
    }
    else{

     this.setState({NoEventWithThisID : false});
     this.setState({ThisIsMyEvent : true});
     this.setState({DisplayForm : true});
     this.setState({DisplaySummary : false});
   }


  }

 private async _getResponsable(items: any[]) { 
    var localrespnsable = [];
    if(items.length == 0){
      this.setState({display_required:  true});
    }else {
      this.setState({display_required:  false});
      localrespnsable.push(items[0].secondaryText);
      this.setState({responsable: localrespnsable  });
      this.setState({ResponsableId : items[0].id });
    }
  }
  private async _getOrganizer(items: any[])
   { 
   var localorganizer = [];
    if(items.length == 0){
      this.setState({organizer_details:  false});
      this.setState({display_required:  true});
    }else {

         this.setState({display_required:  false});
         const propertyName = "POLEFONCTION";
         var result_Pole: any =  await sp.profiles.getUserProfilePropertyFor(("i:0#.f|membership|" + items[0].secondaryText ) , propertyName);

         const propertyName2 = "Department";
         var result_BU: any =  await sp.profiles.getUserProfilePropertyFor(("i:0#.f|membership|" + items[0].secondaryText ) , propertyName2);

         const propertyName3 = "WorkPhone";
         var result_Tel: any =  await sp.profiles.getUserProfilePropertyFor(("i:0#.f|membership|" + items[0].secondaryText ) , propertyName3);

         localorganizer.push(items[0].secondaryText );
         this.setState({organizer:  localorganizer});
         this.setState({organizer_details:  true});
         this.setState({organizer_entity: result_BU});
         this.setState({ organizer_email:  items[0].secondaryText  });  
         this.setState({ organizer_tel: result_Tel});   
         this.setState({ billing_business: result_BU});  
         this.setState({ billing_entity: result_Pole});  
         this.setState({ billing_contact: items[0].text});    
         this.setState({OrganizerId : items[0].id });
    }
  }
 private toggleHideDialog():void{

      if(!this.state.ShowDialog){
    this.setState({ShowDialog : true});
    }else{
      this.setState({ShowDialog : false});
    }
  }

  private toggleHideDialog2():void{

    if(!this.state.ShowDialog2){
  this.setState({ShowDialog2 : true});
  }else{
    this.setState({ShowDialog2 : false});
  }
}

private toggleHideDialog3():void{

  if(!this.state.ShowDialog3){
this.setState({ShowDialog3 : true});
}else{
  this.setState({ShowDialog3 : false});
}
}

private toggleHideDialog4():void{

  if(!this.state.ShowDialog4){
this.setState({ShowDialog4 : true});
}else{
  this.setState({ShowDialog4 : false});
}
}

  private Suivant():void{
    
    if(this.state.SelectedPivot == 0)
      {
        if(this.state.type.length == 0 || this.state.title.length == 0 || this.state.Description.length==0 || this.state.responsable.length == 0 || this.state.organizer.length == 0 )
          {
            this.setState({display_required : true});
            return;
          }
      }
    
    if(this.state.SelectedPivot == 1)
        {
          if(this.state.selected_espace.length == 0  )
            {
              this.setState({display_required : true});
              return;
            }else{
              this.setState({display_required : false});
            }
      }

    if(this.state.SelectedPivot == 2)
        {
          if(this.state.nb_totalParticipants == 0  )
            {
              this.setState({display_required : true});
              return;
            }else{
              this.setState({display_required : false});
            }
      }
    
     if(this.state.SelectedPivot == 3)
        {
          if(this.state.Horaires.startDate1 >= this.state.Horaires.endDate1 )
            {
              this.setState({display_required : true});
              return;
            }else{
              this.setState({display_required : false});
            }
      }

    if(this.state.SelectedPivot <6)
    {
    this.setState({SelectedPivot  : ((this.state.SelectedPivot + 1) )});
    }
    if(this.state.SelectedPivot + 1 != 6) {this.setState({showSave : false});this.setState({hideNext : false});}else{this.setState({showSave : true});this.setState({hideNext : true});}
  }

  private Precedent():void{
   
    if(this.state.SelectedPivot >0)
    {
    this.setState({SelectedPivot  : ((this.state.SelectedPivot - 1) )});
    }

    if(this.state.SelectedPivot - 1 != 6) {this.setState({showSave : false}); this.setState({hideNext : false});}else{this.setState({showSave : true});this.setState({hideNext : true});}
  }

  private Approve():void{
    this.setState({Status  : "Approuvée"});

    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
    var idEvent = parseInt(queryParameters.getValue("myeventid"));
    sp.web.lists.getByTitle("Demandes").items.getById(idEvent).update({
      Statut : "Approuvée"
    });

    this.setState({ShowDialog2 : false});


  }

  private Reject():void{
    this.setState({Status  : "Clôturée"});

    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
    var idEvent = parseInt(queryParameters.getValue("myeventid"));
    sp.web.lists.getByTitle("Demandes").items.getById(idEvent).update({
      Statut : "Clôturée"
    });

    this.setState({ShowDialog3 : false});
  }

  private Annuler():void{
    this.setState({Status  : "Demande annulée"});

    var queryParameters  = new UrlQueryParameterCollection(window.location.href);
    var idEvent = parseInt(queryParameters.getValue("myeventid"));
    sp.web.lists.getByTitle("Demandes").items.getById(idEvent).update({
      Statut : "Demande annulée"
    });

    this.setState({ShowDialog4 : false});
  }


  private async Save():Promise<void>{
    
    this.setState({showSave : false});
    this.setState({Loading : true});

    var espaces = this.state.selected_espace.map(e => e.espace).join(',');

   let itemresult = await  sp.web.lists.getByTitle("Demandes").items.add({
       Title : this.state.title,
       TypeEvent : this.state.type,
       Presentation : this.state.Description,
       ConditionEntree : this.state.condition_entree,
       ResponsableEventId : this.state.ResponsableId,
       EntiteOrganisatrice : this.state.organizer_entity,
       OrganisateurEventId : this.state.OrganizerId,
       TelResponsable : this.state.organizer_tel,
       MailResponsable : this.state.organizer_email,
       Immeuble : this.state.SelectedImmeuble,
       Ville : this.state.SelectedVille,
       Adresse : this.state.selectedAdress,
       Horaires : this.state.HoraireString,
       Espaces : espaces,
       NBCollabBNPP : this.state.nb_collab_bnpp,
       InviteVIPBNPP : this.state.nb_vip_extern_site,
       InviteVIPExterneBNPP : this.state.nb_vip_extern_bnpp,
       NBCollabExterneBNPP : this.state.nb_non_collab_bnpp,
       nbCollabBNPPExterneSite : this.state.nb_collab_bnpp_extern,
       PSH : this.state.nb_psh,
       Accompagnant : this.state.nb_mineurs,
       nbPresta : this.state.nb_presta,
       Billing_Entite : this.state.billing_entity,
       Billing_Contact : this.state.billing_contact,
       Billing_Siret : this.state.billing_siret,
       Billing_CentreCout :this.state.billing_costCenter,
       Billing_Adresse : this.state.billing_address,
       Billing_Metier : this.state.billing_business,
       DateDebut : (new Date())
    });

    let result =itemresult
    let idnewItem = result.data.Id;
    const currentitem  =  sp.web.lists.getByTitle("Demandes").items.getById(parseInt(idnewItem));

    if(this.state.fileName1.length > 0 ||this.state.fileName2.length > 0 ||this.state.fileName3.length > 0 ||this.state.fileName4.length > 0 ||this.state.fileName5.length > 0 ||this.state.fileName6.length > 0 )
    {
    // Create a folder
    var  folderName ="/sites/MyEvent/AttachmentsEvent/"+ idnewItem
    let folderAddResult = await sp.web.folders.addUsingPath(folderName);
    const fitem = await folderAddResult.folder.getItem();
  
    var idFolder : string = fitem["Id"];
    await currentitem.update({FolderAttachment_ID : String(idFolder)});

    if(this.state.fileName1.length > 0)
    {
     this.state.file1.downloadFileContent()
       .then(async r => {
         let fileresult = await sp.web.getFolderByServerRelativeUrl(folderName).files.add(this.state.fileName1, r, true);
         const item = await fileresult.file.getItem();
         await item.update({ TypeFile: "PlanPrevisionnel" });
       });
     }

    if(this.state.fileName2.length > 0)
     {
      this.state.file2.downloadFileContent()
        .then(async r => {
          let fileresult = await sp.web.getFolderByServerRelativeUrl(folderName).files.add(this.state.fileName2, r, true);
          const item = await fileresult.file.getItem();
          await item.update({ TypeFile: "PlanImplementation" });
        });
     }

    if(this.state.fileName3.length > 0)
      {
       this.state.file3.downloadFileContent()
         .then(async r => {
           let fileresult = await sp.web.getFolderByServerRelativeUrl(folderName).files.add(this.state.fileName3, r, true);
           const item = await fileresult.file.getItem();
           await item.update({ TypeFile: "ListeInvites" });
         });
     }

    if(this.state.fileName4.length > 0)
       {
        this.state.file4.downloadFileContent()
          .then(async r => {
            let fileresult = await sp.web.getFolderByServerRelativeUrl(folderName).files.add(this.state.fileName4, r, true);
            const item = await fileresult.file.getItem();
            await item.update({ TypeFile: "PVReactionFeu" });
          });
     }

    if(this.state.fileName5.length > 0)
        {
         this.state.file5.downloadFileContent()
           .then(async r => {
             let fileresult = await sp.web.getFolderByServerRelativeUrl(folderName).files.add(this.state.fileName5, r, true);
             const item = await fileresult.file.getItem();
             await item.update({ TypeFile: "ListeIntervenants" });
           });
     }

    if(this.state.fileName6.length > 0)
      {
          this.state.file6.downloadFileContent()
            .then(async r => {
              let fileresult = await sp.web.getFolderByServerRelativeUrl(folderName).files.add(this.state.fileName6, r, true);
              const item = await fileresult.file.getItem();
              await item.update({ TypeFile: "Autres" });
            });
     }
    }

   // Save Prestations
   let AllPresta = "";
   this.state.prestations.map(async (presta) => {
      if (presta.choix == "OK") {

        let date = ""; if (presta.date != null) { date = presta.date.getDate().toLocaleString(); }
        let hour = ""; if (presta.date != null) { date = presta.date.getTime().toLocaleString(); }

        let nbHotesse = 0; if (presta.HotesseNombre != '') { try { nbHotesse = parseInt(presta.HotesseNombre); } catch { } };
        let nbPanneaux = 0; if (presta.PanneauxNombre != '') { try { nbPanneaux = parseInt(presta.PanneauxNombre); } catch { } };

        let itemresult = await sp.web.lists.getByTitle("Prestations").items.add({
          Title: String(idnewItem), // Id de l'event
          TakePresta: "Oui, J'en ai besoin",
          Precision: presta.precisions_value,
          NomSociete: presta.company,
          NomReferent: presta.referent,
          TelReferent: presta.referentTel,
          MailReferent: presta.referentMail,
          Immatriculation: presta.numImmatriculation,
          Parking: presta.accessParking,
          QuaiLivraison: presta.accesQuaiLivraison,
          AutresBesoin: presta.otherNeed,
          TypePresta: presta.label,
          DatePresta: date,
          HeurePresta: hour,
          Potelets: presta.PanneauxAffichage,
          NombrePotelet: nbPanneaux,
          NombreHotesse: nbHotesse,
          Vestiaire: presta.HotesseVestiaire,
          exigenceUnifrme: presta.HotesseUniforme,
          ProfilHotesses: presta.HotesseProfile
        }).then(response =>{ 
          AllPresta += response.data.Id + ",";
          currentitem.update({Prestations_IDs : String(AllPresta)});
        });

      }
    });

    this.setState({EventCreated : true});
    this.setState({EventStatus : "En cours"});
    this.setState({Loading : false});

  }

  private _AddTimeRange():void{

    if(this.state.displayH2 == false) {this.setState({displayH2 : true}); }
    else{
      if(!this.state.displayH3) {this.setState({displayH3 : true});}
    }

  }
  private _RemoveTimeRange():void{
    if(this.state.displayH3 == true) {
      this.setState({displayH3 : false});
      var localH = this.state.Horaires;
      localH.startDate3  = null;
      localH.endDate3  = null;
      this.setState({Horaires : localH});
    }
    else{
      if(this.state.displayH2) {
        this.setState({displayH2 : false});
        var localH = this.state.Horaires;
        localH.startDate2 = null;
        localH.endDate2  = null;
        this.setState({Horaires : localH});
      }
    }

  }

  private _presentationChange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
    
    if(newValue.length == 0){
      this.setState({display_required: true});
      this.setState({Description: ""});
    }else{  
    this.setState({Description: newValue}); 
    this.setState({display_required: false});
    }
  
  }
  private _titleChange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
    
    if(newValue.length == 0){
      this.setState({display_required: true});
      this.setState({title: ""});
    }else{  
    this.setState({title: newValue}); 
    this.setState({display_required: false});
    }
  
  }  

  private _organizer_entityChange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
    
    if(newValue.length == 0){
      this.setState({display_required: true});
      this.setState({organizer_entity: ""});
    }else{  
    this.setState({organizer_entity: newValue}); 
    this.setState({display_required: false});
    }
  
  }  

  private _organizer_telChange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
    
    if(newValue.length == 0){
      this.setState({display_required: true});
      this.setState({organizer_tel: ""});
    }else{  
    this.setState({organizer_tel: newValue}); 
    this.setState({display_required: false});
    }
  
  }  

  private _organizer_emailChange(newValueInput:any):void { 
    let newValue: any =  newValueInput.target.defaultValue;
    
    if(newValue.length == 0){
      this.setState({display_required: true});
      this.setState({organizer_email: ""});
    }else{  
    this.setState({organizer_email: newValue}); 
    this.setState({display_required: false});
    }
  
  }  

private _PrestationcompanyChange(newValueInput:any):void { 
  let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.company =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations});
}

private _PrestationreferentChange(newValueInput:any):void { 
  let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.referent =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations});
}

private _PrestationreferentTelChange(newValueInput:any):void { 
  let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.referentTel =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations});
}

private _PrestationreferentMailChange(newValueInput:any):void { 
  let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.referentMail =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations});
}

private _PrestationnumImmatriculationChange(newValueInput:any):void { 
  let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.numImmatriculation =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations});
}

private _PrestationotherNeedChange(newValueInput:any):void { 
  let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.otherNeed =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations});
}
private _PrestationPrecisionChange(newValueInput:any):void { 
  let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.precisions_value =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations});
}
private _NBHotesseChange(newValueInput:any):void {  let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.HotesseNombre =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations});}

private _NBPanneauxChange(newValueInput:any):void {  let newValue: any =  newValueInput.target.defaultValue;
    var localNode = this.state.SelectedPrestation;
    localNode.PanneauxNombre =newValue;
    this.setState({SelectedPrestation : localNode});
    var localPrestations = this.state.prestations;
    localPrestations[this.state.SelectedPrestaPosition] = localNode;
    this.setState({prestations : localPrestations});}
    
  private _ProfileHotesseChange(newValueInput:any):void { let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.HotesseProfile =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations}); }

private _UniformeHotesseChange(newValueInput:any):void { 
  let newValue: any =  newValueInput.target.defaultValue;
  var localNode = this.state.SelectedPrestation;
  localNode.HotesseUniforme =newValue;
  this.setState({SelectedPrestation : localNode});
  var localPrestations = this.state.prestations;
  localPrestations[this.state.SelectedPrestaPosition] = localNode;
  this.setState({prestations : localPrestations});
}
private _typeEventChange(newValue: any): void { 
    this.setState({type: newValue.key});
  if(newValue.key.length <3){
    this.setState({display_required:true});
  }else{this.setState({display_required:false});}
}
private _EspaceonChange(ev: React.FormEvent<HTMLElement>, isChecked: boolean){
  var currentSpace = ev.currentTarget.title;

  var tempSelectedSpace = this.state.selected_espace;
  if(isChecked)
  {

    var index = this.state.espaces.map((el)=> el.espace).indexOf(currentSpace);
    var CurrentobSpace = this.state.espaces[index];
    CurrentobSpace.defaultChecked = true;
  
    if(tempSelectedSpace.length == 0){tempSelectedSpace.push(CurrentobSpace) ;}
    else{
    if( tempSelectedSpace.map((el)=> el.espace).indexOf(currentSpace)== -1)  {  tempSelectedSpace.push(CurrentobSpace) ; }}
   
  }
  else{
    var index = tempSelectedSpace.map((el)=> el.espace).indexOf(currentSpace);
    if(index > -1) {tempSelectedSpace.splice(index, 1) ;}
  }

  var totalpar = 0;
  tempSelectedSpace.map((el)=>{totalpar += el.capacite; });
  this.setState({nb_choosenPlace : totalpar});
  this.setState({selected_espace :  tempSelectedSpace});

  // Afficher les images


}

 private _Start1Change(newValue: any): void {
 var localH = this.state.Horaires;
 localH.startDate1  = newValue;
 localH.startDate1_TolocalDate = localH.startDate1.toLocaleDateString();
 localH.startDate1_TolocalTime = localH.startDate1.toLocaleTimeString().substring(0, localH.startDate1.toLocaleTimeString().length-3);
 this.setState({Horaires : localH});

 var savePlanning =  localH.startDate1_TolocalDate+ " " + localH.startDate1_TolocalTime + " -" + this.state.Horaires.endDate1_TolocalDate + " " + this.state.Horaires.endDate1_TolocalTime;
 if(this.state.displayH2)
 { savePlanning += "| " + this.state.Horaires.startDate2_TolocalDate + " " + this.state.Horaires.startDate2_TolocalTime + " -" + this.state.Horaires.endDate2_TolocalDate + " " + this.state.Horaires.endDate2_TolocalTime;}
  
 if(this.state.displayH3)
 { savePlanning += "| " + this.state.Horaires.startDate3_TolocalDate + " " + this.state.Horaires.startDate3_TolocalTime + " -" + this.state.Horaires.endDate3_TolocalDate + " " + this.state.Horaires.endDate3_TolocalTime;}

 this.setState({HoraireString : savePlanning});
}

 private _Start2Change(newValue: any): void {
  var localH = this.state.Horaires;
  localH.startDate2  = newValue;
  localH.startDate2_TolocalDate = localH.startDate2.toLocaleDateString();
  localH.startDate2_TolocalTime = localH.startDate2.toLocaleTimeString().substring(0, localH.startDate2.toLocaleTimeString().length-3);
  this.setState({Horaires : localH});

  var savePlanning =  this.state.Horaires.startDate1_TolocalDate + " " + this.state.Horaires.startDate1_TolocalTime + " -" + this.state.Horaires.endDate1_TolocalDate + " " + this.state.Horaires.endDate1_TolocalTime;

  if(this.state.displayH2)
  { savePlanning += "| " + localH.startDate2_TolocalDate + " " + localH.startDate2_TolocalTime + " -" + this.state.Horaires.endDate2_TolocalDate + " " + this.state.Horaires.endDate2_TolocalTime;}
   
  if(this.state.displayH3)
  { savePlanning += "| " + this.state.Horaires.startDate3_TolocalDate + " " + this.state.Horaires.startDate3_TolocalTime + " -" + this.state.Horaires.endDate3_TolocalDate + " " + this.state.Horaires.endDate3_TolocalTime;}
 
  this.setState({HoraireString : savePlanning});  

}


  private _Start3Change(newValue: any): void {
    var localH = this.state.Horaires;
    localH.startDate3  = newValue;
    localH.startDate3_TolocalDate = localH.startDate3.toLocaleDateString();
    localH.startDate3_TolocalTime = localH.startDate3.toLocaleTimeString().substring(0, localH.startDate3.toLocaleTimeString().length-3);
    this.setState({Horaires : localH});
    var savePlanning =  this.state.Horaires.startDate1_TolocalDate + " " + this.state.Horaires.startDate1_TolocalTime + " -" + this.state.Horaires.endDate1_TolocalDate + " " + this.state.Horaires.endDate1_TolocalTime;

    if(this.state.displayH2)
    { savePlanning += "| " +this.state.Horaires.startDate2_TolocalDate + " " + this.state.Horaires.startDate2_TolocalTime+ " -" + this.state.Horaires.endDate2_TolocalDate + " " + this.state.Horaires.endDate2_TolocalTime;}
     
    if(this.state.displayH3)
    { savePlanning += "| " + localH.startDate3_TolocalDate + " " + localH.startDate3_TolocalTime + " -" + this.state.Horaires.endDate3_TolocalDate + " " + this.state.Horaires.endDate3_TolocalTime;}
   
    this.setState({HoraireString : savePlanning});  

    }
    private _End1Change(newValue: any): void {
      var localH = this.state.Horaires;
      localH.endDate1  = newValue;
      localH.endDate1_TolocalDate = localH.endDate1.toLocaleDateString();
      localH.endDate1_TolocalTime = localH.endDate1.toLocaleTimeString().substring(0, localH.endDate1.toLocaleTimeString().length-3);
      this.setState({Horaires : localH});
      var savePlanning =  this.state.Horaires.startDate1_TolocalDate + " " + this.state.Horaires.startDate1_TolocalTime + " -" + localH.endDate1_TolocalDate + " " + localH.endDate1_TolocalTime;

    if(this.state.displayH2)
    { savePlanning += "| " +this.state.Horaires.startDate2_TolocalDate + " " + this.state.Horaires.startDate2_TolocalTime+ " -" + this.state.Horaires.endDate2_TolocalDate + " " + this.state.Horaires.endDate2_TolocalTime;}
     
    if(this.state.displayH3)
    { savePlanning += "| " + this.state.Horaires.startDate3_TolocalDate + " " + this.state.Horaires.startDate3_TolocalTime + " -" + this.state.Horaires.endDate3_TolocalDate + " " + this.state.Horaires.endDate3_TolocalTime;}
   
    this.setState({HoraireString : savePlanning});  
      }
    private _End2Change(newValue: any): void {
      var localH = this.state.Horaires;
      localH.endDate2  = newValue;
      localH.endDate2_TolocalDate = localH.endDate2.toLocaleDateString();
      localH.endDate2_TolocalTime = localH.endDate2.toLocaleTimeString().substring(0, localH.endDate2.toLocaleTimeString().length-3);
      this.setState({Horaires : localH});

      var savePlanning =  this.state.Horaires.startDate1_TolocalDate + " " + this.state.Horaires.startDate1_TolocalTime + " -" + this.state.Horaires.endDate1_TolocalDate + " " + this.state.Horaires.endDate1_TolocalTime;

      if(this.state.displayH2)
      { savePlanning += "| " +this.state.Horaires.startDate2_TolocalDate + " " + this.state.Horaires.startDate2_TolocalTime+ " -" + localH.endDate2_TolocalDate + " " + localH.endDate2_TolocalTime;}
       
      if(this.state.displayH3)
      { savePlanning += "| " + this.state.Horaires.startDate3_TolocalDate + " " + this.state.Horaires.startDate3_TolocalTime + " -" + this.state.Horaires.endDate3_TolocalDate + " " + this.state.Horaires.endDate3_TolocalTime;}
     
      this.setState({HoraireString : savePlanning});  
      }
    private _End3Change(newValue: any): void {
      var localH = this.state.Horaires;
      localH.endDate3  = newValue;
      localH.endDate3_TolocalDate = localH.endDate3.toLocaleDateString();
      localH.endDate3_TolocalTime = localH.endDate3.toLocaleTimeString().substring(0, localH.endDate3.toLocaleTimeString().length-3);
      this.setState({Horaires : localH});
      var savePlanning =  this.state.Horaires.startDate1_TolocalDate + " " + this.state.Horaires.startDate1_TolocalTime + " -" + this.state.Horaires.endDate1_TolocalDate + " " + this.state.Horaires.endDate1_TolocalTime;

      if(this.state.displayH2)
      { savePlanning += "| " +this.state.Horaires.startDate2_TolocalDate + " " + this.state.Horaires.startDate2_TolocalTime+ " -" + this.state.Horaires.endDate2_TolocalDate + " " + this.state.Horaires.endDate2_TolocalTime;}
       
      if(this.state.displayH3)
      { savePlanning += "| " + this.state.Horaires.startDate3_TolocalDate + " " + this.state.Horaires.startDate3_TolocalTime + " -" + localH.endDate3_TolocalDate + " " + localH.endDate3_TolocalTime;}
     
      this.setState({HoraireString : savePlanning});  
      }

  private _typeEntreeChange(newValue: any): void { 
    this.setState({condition_entree: newValue.key});
  if(newValue.key.length <3){
    this.setState({display_required:true});
  }else{this.setState({display_required:false});}
  }

  private _PrestaOptionChange(ev: React.FormEvent<HTMLInputElement>, option: IChoiceGroupOption): void {
    var localNode = this.state.SelectedPrestation;
    localNode.choix =option.key;
    this.setState({SelectedPrestation : localNode});
    var localPrestations = this.state.prestations;
    localPrestations[this.state.SelectedPrestaPosition] = localNode;
    this.setState({prestations : localPrestations});
  }

  private _PrestaParkingChange  (ev: React.FormEvent<HTMLInputElement>, option: IChoiceGroupOption): void {
    var localNode = this.state.SelectedPrestation;
    localNode.accessParking = (option.key == "Oui") ? true: false;
    this.setState({SelectedPrestation : localNode});
    var localPrestations = this.state.prestations;
    localPrestations[this.state.SelectedPrestaPosition] = localNode;
    this.setState({prestations : localPrestations});
  }
  private _PanneauxAffichageChange  (ev: React.FormEvent<HTMLInputElement>, option: IChoiceGroupOption): void {
    var localNode = this.state.SelectedPrestation;
    localNode.PanneauxAffichage = (option.key == "Oui") ? true: false;
    this.setState({SelectedPrestation : localNode});
    var localPrestations = this.state.prestations;
    localPrestations[this.state.SelectedPrestaPosition] = localNode;
    this.setState({prestations : localPrestations});
  }
  private _PrestaQuaiChange  (ev: React.FormEvent<HTMLInputElement>, option: IChoiceGroupOption): void {
    var localNode = this.state.SelectedPrestation;
    localNode.accesQuaiLivraison = (option.key == "Oui") ? true: false;
    this.setState({SelectedPrestation : localNode});
    var localPrestations = this.state.prestations;
    localPrestations[this.state.SelectedPrestaPosition] = localNode;
    this.setState({prestations : localPrestations});
  }
  private _PrestvestiaireChange  (ev: React.FormEvent<HTMLInputElement>, option: IChoiceGroupOption): void {
    var localNode = this.state.SelectedPrestation;
    localNode.HotesseVestiaire = (option.key == "Oui") ? true: false;
    this.setState({SelectedPrestation : localNode});
    var localPrestations = this.state.prestations;
    localPrestations[this.state.SelectedPrestaPosition] = localNode;
    this.setState({prestations : localPrestations});
  }
private _displayPrestaDetail(label: string):void{
  var index = this.state.prestations.map((el)=> el.label).indexOf(label);
  this.setState({SelectedPrestaPosition: index}); 
  this.setState({SelectedPrestation : this.state.prestations[index]});
}
private _VillesChange(newValue: any): void { 
    if(newValue.key.length <2){
      var tempImmeubles = [];
      tempImmeubles.push({key:"", text:""}) ; 
      this.state.espaces.forEach(element => { 
        tempImmeubles.push({key:element.immeuble, text:element.immeuble}) ; 
      });
      this.setState({ immeubles : tempImmeubles});
    }
    else{
      var tempImmeubles = [];
      tempImmeubles.push({key:"", text:""}) ; 
      this.state.espaces.forEach(element => { 
        if(element.ville == newValue.key){
          if( tempImmeubles.map((el)=> el.key).indexOf(element.immeuble)== -1)  {
               tempImmeubles.push({key:element.immeuble, text:element.immeuble}) ; 
          }
        }
      });
      this.setState({ immeubles : tempImmeubles});
      this.setState({pool_espace : []});
      this.setState({SelectedVille: newValue.key});
    }
  }
private _ImmeublesChange(newValue: any): void { 
    var localadr ='';
    var localVille = '';
    if(newValue.key.length >1){
   {
      var tempespaces = [];
      this.state.espaces.forEach(element => { 
        if(element.immeuble == newValue.text){
          tempespaces.push(element) ; 
          localadr = element.address;
          localVille = element.ville
        }
      });
      this.setState({ pool_espace : tempespaces});
      this.setState({selected_espace : []});
      this.setState({selectedAdress: localadr});
      this.setState({SelectedImmeuble: newValue.text});
      this.setState({SelectedVille: localVille});
     
    }
  }
}
private _billing_businessChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({billing_business: ""}); }else{  this.setState({organizer_entity: newValue});  }
 }
private _billing_entityChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({billing_entity: ""}); }else{  this.setState({billing_entity: newValue});  }
 }
private _billing_contactChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({billing_contact: ""}); }else{  this.setState({billing_contact: newValue});  }
 }
private _billing_addressChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({billing_address: ""}); }else{  this.setState({billing_address: newValue});  }
 }
private _billing_siretChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({billing_siret: ""}); }else{  this.setState({billing_siret: newValue});  }
 }
private _billing_costCenterChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({billing_costCenter: ""}); }else{  this.setState({billing_costCenter: newValue});  }
 }
 private _nb_collab_bnppChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({nb_collab_bnpp: 0}); }else{  this.setState({nb_collab_bnpp: Number(newValue)});  }

  var total : number = 0;
  total += this.state.nb_non_collab_bnpp;
  total += Number(newValue);
  total += this.state.nb_collab_bnpp_extern;
  total += this.state.nb_mineurs;
  total += this.state.nb_presta;
  total += this.state.nb_psh;
  total += this.state.nb_vip_extern_bnpp;
  total += this.state.nb_vip_extern_site;

  this.setState({nb_totalParticipants : total});

 }
 private _nb_non_collab_bnppChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({nb_non_collab_bnpp: 0}); }else{  this.setState({nb_non_collab_bnpp: Number(newValue)});   }

  var total : number = 0;
  total +=  Number(newValue);
  total += this.state.nb_collab_bnpp;
  total += this.state.nb_collab_bnpp_extern;
  total += this.state.nb_mineurs;
  total += this.state.nb_presta;
  total += this.state.nb_psh;
  total += this.state.nb_vip_extern_bnpp;
  total += this.state.nb_vip_extern_site;

  this.setState({nb_totalParticipants : total});

 }
 private _nb_vip_extern_bnppChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({nb_vip_extern_bnpp: 0}); }else{  this.setState({nb_vip_extern_bnpp: Number(newValue)});   }

  var total : number = 0;
  total += this.state.nb_non_collab_bnpp;
  total += this.state.nb_collab_bnpp;
  total += this.state.nb_collab_bnpp_extern;
  total += this.state.nb_mineurs;
  total += this.state.nb_presta;
  total += this.state.nb_psh;
  total += Number(newValue);
  total += this.state.nb_vip_extern_site;

  this.setState({nb_totalParticipants : total});

 }
 private _nb_pshChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({nb_psh: 0}); }else{  this.setState({nb_psh: Number(newValue)});   }

  var total : number = 0;
  total += this.state.nb_non_collab_bnpp;
  total += this.state.nb_collab_bnpp;
  total += this.state.nb_collab_bnpp_extern;
  total += this.state.nb_mineurs;
  total += this.state.nb_presta;
  total += Number(newValue);
  total += this.state.nb_vip_extern_bnpp;
  total += this.state.nb_vip_extern_site;

  this.setState({nb_totalParticipants : total});

 }
 private _nb_collab_bnpp_externChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({nb_collab_bnpp_extern: 0}); }else{  this.setState({nb_collab_bnpp_extern: Number(newValue)});   }

  var total : number = 0;
  total += this.state.nb_non_collab_bnpp;
  total += this.state.nb_collab_bnpp;
  total += Number(newValue);
  total += this.state.nb_mineurs;
  total += this.state.nb_presta;
  total += this.state.nb_psh;
  total += this.state.nb_vip_extern_bnpp;
  total += this.state.nb_vip_extern_site;

  this.setState({nb_totalParticipants : total});

 }
 private _nb_vip_extern_siteChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({nb_vip_extern_site: 0}); }else{  this.setState({nb_vip_extern_site: Number(newValue)});   }
  
  var total : number = 0;
  total += this.state.nb_non_collab_bnpp;
  total += this.state.nb_collab_bnpp;
  total += this.state.nb_collab_bnpp_extern;
  total += this.state.nb_mineurs;
  total += this.state.nb_presta;
  total += this.state.nb_psh;
  total += this.state.nb_vip_extern_bnpp;
  total += Number(newValue);

  this.setState({nb_totalParticipants : total});

 }
 private _nb_mineursChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({nb_mineurs: 0}); }else{  this.setState({nb_mineurs: Number(newValue)});   }

  var total : number = 0;
  total += this.state.nb_non_collab_bnpp;
  total += this.state.nb_collab_bnpp;
  total += this.state.nb_collab_bnpp_extern;
  total += Number(newValue);
  total += this.state.nb_presta;
  total += this.state.nb_psh;
  total += this.state.nb_vip_extern_bnpp;
  total += this.state.nb_vip_extern_site;

  this.setState({nb_totalParticipants : total});


 }
 private _nb_prestaChange(newValueInput:any):void {
  let newValue: any =  newValueInput.target.defaultValue;
  if(newValue.length == 0){ this.setState({nb_presta: 0}); }
  else{  this.setState({nb_presta: Number(newValue)});   }

  var total : number = 0;
  total += this.state.nb_non_collab_bnpp;
  total += this.state.nb_collab_bnpp;
  total += this.state.nb_collab_bnpp_extern;
  total += this.state.nb_mineurs;
  total += Number(newValue);
  total += this.state.nb_psh;
  total += this.state.nb_vip_extern_bnpp;
  total += this.state.nb_vip_extern_site;

  this.setState({nb_totalParticipants : total});

 }
 public async _SelectFiles1(filePickerResult: IFilePickerResult[]) {
     var fileName = filePickerResult[0].fileName;
     this.setState({fileName1 : fileName});
     this.setState({file1 : filePickerResult[0] });

 }
 public async _SelectFiles2(filePickerResult: IFilePickerResult[]) {
  var fileName = filePickerResult[0].fileName;
  this.setState({fileName2 : fileName});
  this.setState({file2 : filePickerResult[0] });
}
public async _SelectFiles3(filePickerResult: IFilePickerResult[]) {
  var fileName = filePickerResult[0].fileName;
  this.setState({fileName3 : fileName});
  this.setState({file3 : filePickerResult[0] });
}
public async _SelectFiles4(filePickerResult: IFilePickerResult[]) {
  var fileName = filePickerResult[0].fileName;
  this.setState({fileName4 : fileName});
  this.setState({file4 : filePickerResult[0] });
}
public async _SelectFiles5(filePickerResult: IFilePickerResult[]) {
  var fileName = filePickerResult[0].fileName;
  this.setState({fileName5 : fileName});
  this.setState({file5 : filePickerResult[0] });
}
public async _SelectFiles6(filePickerResult: IFilePickerResult[]) {
  var fileName = filePickerResult[0].fileName;
  this.setState({fileName6 : fileName});
  this.setState({file6 : filePickerResult[0] });
}
  public render(): React.ReactElement<IManageMyEventProps> {

    return (
      <div className={ styles.manageMyEvent }>
       <div  style={{ display: ((!this.state.DisplayForm && !this.state.DisplaySummary && this.state.ThisIsMyEvent && !this.state.NoEventWithThisID) ? 'block' : 'none'), position:'relative', margin:'auto' }}>
            <Spinner label="Chargement en cours.." />
        </div>
      <div style={{ display: ((!this.state.DisplayForm && (this.state.NoEventWithThisID || !this.state.ThisIsMyEvent)) ? 'block' : 'none') }}>
        <MessageBar messageBarType={MessageBarType.error}>
          Accès refusé.<br/>
          Aucun événement n'existe avec cette référence ou vous n'avez pas le droit d'y accèder.
        </MessageBar>
      </div>


      <div style={{ display: ((this.state.DisplayForm ) ? 'block' : 'none')}}>
      <div  className={ styles.container } style={{ display: ((this.state.stage_one) ? 'block' : 'none') }}>
        <Pivot linkFormat={PivotLinkFormat.tabs}  selectedKey={String(this.state.SelectedPivot)}   >
          {!this.state.DisplaySummary && (
          <PivotItem headerText='EVENEMENT' itemIcon='Calendar' itemKey='0'>
            <br/><br/>
            <table cellPadding='0' cellSpacing='0' width='100%'>
              <tr>
                <td width='50%' valign='top' style={{paddingRight:40}}>
                <TextField   required placeholder = "Nom de l'évènement" label="Nom de l'évènement" defaultValue={this.state.title}  onChange={this._titleChange.bind(this)}  /> <br/>
                <Dropdown label="Type" placeholder="Type" required options={EventType}  onChanged={this._typeEventChange.bind(this)} defaultSelectedKey={this.state.type} /><br/>
                <TextField   required label = "Présentation" placeholder = "Présentation" defaultValue={this.state.Description} multiline onChange={this._presentationChange.bind(this)} /> <br/>
                <ChoiceGroup  options={Entree} label="Condition d'entrée" required defaultSelectedKey={this.state.condition_entree}  onChanged={this._typeEntreeChange.bind(this)}  />
                </td>
                <td  valign='top'>
                <PeoplePicker  required={true}   context={this.props.context}  titleText='Responsable légal du métier organisateur' personSelectionLimit={1} showtooltip={false} 
                    disabled={false}  onChange={this._getResponsable.bind(this)}   ensureUser={true}   principalTypes={[PrincipalType.User]}  resolveDelay={1000} defaultSelectedUsers={this.state.responsable} />
                <br/>
                <PeoplePicker  required={true}   context={this.props.context}  titleText="Organisateur de l'évènement" personSelectionLimit={1} showtooltip={false} 
                    disabled={false}  onChange={this._getOrganizer.bind(this)}   ensureUser={true} defaultSelectedUsers={this.state.organizer}   principalTypes={[PrincipalType.User]}  resolveDelay={1000} />
                <br/>
                <div style={{ display: ((this.state.organizer_details) ? 'block' : 'none') }}>
                <TextField underlined  prefix = "Entité" defaultValue={this.state.organizer_entity} onChange={this._organizer_entityChange.bind(this)}  /> <br/>
                <TextField underlined  prefix = "Téléphone" defaultValue={this.state.organizer_tel} onChange={this._organizer_telChange.bind(this)}  /> <br/>
                <TextField underlined  prefix = "Email" defaultValue={this.state.organizer_email} onChange={this._organizer_emailChange.bind(this)}  /> <br/>
                <br/>
                <DefaultButton iconProps={ApproveIcon} text='Informations de facturation' onClick={this.toggleHideDialog.bind(this)}/>

                <Dialog hidden={!this.state.ShowDialog} modalProps={modelProps} onDismiss={this.toggleHideDialog.bind(this)} minWidth={600}>
                  <MessageBar messageBarType={MessageBarType.warning} >
                    Information de facturation, à l'intention du prestataire, si demande de devis
                  </MessageBar><br/><br/>
                    <TextField onChange={this._billing_businessChange.bind(this)}  underlined  prefix = "Entité organisatrice" defaultValue={this.state.billing_business}  /> <br/>
                    <TextField onChange={this._billing_entityChange.bind(this)}  underlined  prefix = "Métier" defaultValue={this.state.billing_entity}  /> <br/>
                    <TextField onChange={this._billing_contactChange.bind(this)}  underlined  prefix = "Contact de facturation" defaultValue={this.state.billing_contact}  /> <br/>
                    <TextField onChange={this._billing_addressChange.bind(this)}  underlined multiline  prefix = "Adresse de facturation" defaultValue={this.state.billing_address}  /> <br/>
                    <TextField onChange={this._billing_siretChange.bind(this)}  underlined  prefix = "N° SIRET" defaultValue={this.state.billing_siret}  /> <br/>
                    <TextField onChange={this._billing_costCenterChange.bind(this)}  underlined  prefix = "Centre de coût" defaultValue={this.state.billing_costCenter}  /> <br/>

                    <DialogFooter>
                      <PrimaryButton  text="Fermer" onClick={this.toggleHideDialog.bind(this)}/>
                    </DialogFooter>
                </Dialog>

                </div>
                </td>
              </tr>
            </table>
          </PivotItem>) }
          {!this.state.DisplaySummary && (
          <PivotItem headerText='LIEU'  itemIcon='CityNext'  itemKey='1'>
          <br/><br/>
            <MessageBar messageBarType={MessageBarType.warning} isMultiline>
            La capacité d'accueil maximale est donnée à titre indicatif et peut-être ajustée à la baisse en fonction des caractéristiques de l'évènement, dans le respect des contraintes de sécurité des personnes et des biens.
            </MessageBar>
          <br/>
          <table cellPadding='0' cellSpacing='0' width='100%'>
              <tr>
                <td width='40%' valign='top' style={{paddingRight:15}}>
            <Dropdown label='Ville' options={this.state.villes} onChanged={this._VillesChange.bind(this)} defaultSelectedKey={this.state.SelectedVille} /><br/>

            <Dropdown label='Immeuble' options={this.state.immeubles} required defaultSelectedKey={this.state.SelectedImmeuble}  onChanged={this._ImmeublesChange.bind(this)}/><br/>
            <div style={{ display: ((this.state.pool_espace.length > 0) ? 'block' : 'none') }}><strong>Espace(s)</strong><br/><br/></div>
            {this.state.pool_espace.map(m =>
            <div> <Checkbox label={m.espace} title={m.espace} defaultChecked={this.state.selected_espace.map((el)=> el.espace).indexOf(m.espace)> -1}  onChange={this._EspaceonChange.bind(this)} /> <div style={{backgroundColor:'#2cc185',padding:5,color:'white',float:'right', marginTop:'-25px'}}>{m.capacite} places</div><br/></div>
            )}
                       
            </td>
            <td   valign='top'>
              <div><br/>
              <MessageBar messageBarType={MessageBarType.info} isMultiline><strong>ADRESSE</strong><br/><br/>{this.state.selectedAdress}</MessageBar>
              <div>{this.state.ImagesEspaces}</div>
              </div>
            </td>
            </tr></table>
           
          </PivotItem>)}
          {!this.state.DisplaySummary && (
          <PivotItem headerText='PARTICIPANTS'  itemIcon='People'  itemKey='2'>
          <br/><br/>
          <MessageBar messageBarType={MessageBarType.warning}> Veuillez indiquer un nombre de participants</MessageBar><br/>
          <table cellPadding='0' cellSpacing='0' width='100%'>
              <tr>
                <td valign='top' style={{paddingRight:40}}>
                    <TextField onChange={this._nb_collab_bnppChange.bind(this)} label="Collaborateurs BNP Paribas du site" defaultValue={String(this.state.nb_collab_bnpp)} /><br/>
                    <TextField onChange={this._nb_non_collab_bnppChange.bind(this)} label="Invités extrieurs au groupe BNP Paribas" defaultValue={String(this.state.nb_non_collab_bnpp)} /><br/>
                    <TextField onChange={this._nb_vip_extern_bnppChange.bind(this)} label="Invités VIP extérieurs à BNP Paribas" defaultValue={String(this.state.nb_vip_extern_bnpp)} /><br/>
                    <TextField onChange={this._nb_pshChange.bind(this)} label="PSH (Personne en Situation d'Handicap)" defaultValue={String(this.state.nb_psh)} /><br/>
                </td>
                <td valign='top'>
                    <TextField onChange={this._nb_collab_bnpp_externChange.bind(this)} label="Collaborateurs BNP Paribas extérieurs au site" defaultValue={String(this.state.nb_collab_bnpp_extern)} /><br/>
                    <TextField onChange={this._nb_vip_extern_siteChange.bind(this)} label="Invités VIP BNP Paribas extérieurs au site" defaultValue={String(this.state.nb_vip_extern_site)} /><br/>
                    <TextField onChange={this._nb_mineursChange.bind(this)} label="Mineurs" defaultValue={String(this.state.nb_mineurs)} /><br/>
                    <TextField onChange={this._nb_prestaChange.bind(this)} label="Participants du prestataire extérieur" defaultValue={String(this.state.nb_presta)} /><br/>
                </td>
              </tr>
          </table>
              <table><tr><td width='70%'>
             <div style={{ display: ((this.state.nb_choosenPlace < this.state.nb_totalParticipants) ? 'block' : 'none') }}> 
              <MessageBar  messageBarType={MessageBarType.error}>Le nombre total de participants excède la capacité de l'espace : <strong>{this.state.nb_choosenPlace}</strong></MessageBar></div>
              </td>
              <td> <div style={{backgroundColor:'#2cc185',padding:6,color:'white',fontWeight:'bold'}}> TOTAL PARTICIPANTS : {this.state.nb_totalParticipants}</div></td></tr></table><br/>
              <div style={{ display: ((this.state.nb_vip_extern_bnpp + this.state.nb_mineurs + this.state.nb_non_collab_bnpp > 0) ? 'block' : 'none') }}>
                <MessageBar isMultiline messageBarType={MessageBarType.severeWarning}>Lorsqu'il y'a des invités extérieurs, l'organisateur devra transmettre la liste au plus tard 48h avant l'évènement (pour conception et préparation des badges visiteurs). Ces informations seront à transmettre à l'accueil (en mettant en copie l'Event Officer), en indiquant le nom/prénom et les coordonnées téléphoniques (mobile) de la personne qui prendra en charge les invités extérieurs.</MessageBar><br/>
                <MessageBar isMultiline messageBarType={MessageBarType.info}>Les immeubles de bureaux BNP Paribas, classés ERT*, ne sont  pas autorisés à recevoir du  public. Ils ne sont pas assujettis à la réglementation ERP*, mais ç celle du code du travail. Toute manifestation exceptionnelle, avec la présence de public, n'y est pas autorisée, et la responsabilité juridique et pénale du chef d'établissement pourrait être engagée en cas d'incident. Si toutefois vous souhaitez maintenir la manifestation avec la présence de public, celle-ci devra être validée par le responsable Métier ou son délégataire (ex : métier, entité,...). IMEX réalisera alors son analyse de risque, sur la base de la réglementation ERP applicable la plus proche de l'activité organisée, et transmettra ses préconisations au demandeur.</MessageBar>
              </div>
          </PivotItem>)}

          {!this.state.DisplaySummary && (
          <PivotItem headerText='PLANNING'  itemIcon='EventDate'  itemKey='3'>
          <br/><br/>
          <MessageBar messageBarType={MessageBarType.warning}> La saisie de date ne fait pas office de réservation. <Link href="https://roombooking.cib.echonet">Lien vers instant booing</Link></MessageBar><br/>
          <div style={{display:((!this.state.DisplaySummary) ? 'grid' : 'none'), gridColumnGap: '20px', gridTemplateColumns: '1fr 1fr'}}>
            <DateTimePicker label="Date de début" formatDate={(date: Date) => date.toLocaleDateString()} value={((this.state.Horaires != null && this.state.Horaires.startDate1 != null)? this.state.Horaires.startDate1 : (new Date(Date.now()))  )} onChange={this._Start1Change.bind(this)} showSeconds={false} minutesIncrementStep={1} showLabels={false} timeDisplayControlType={TimeDisplayControlType.Dropdown} minDate={new Date(Date.now())} key="Start1"  dateConvention={DateConvention.DateTime}   timeConvention={TimeConvention.Hours24} />
            <DateTimePicker label="Date de Fin" formatDate={(date: Date) => date.toLocaleDateString()} value={((this.state.Horaires != null && this.state.Horaires.endDate1 != null)? this.state.Horaires.endDate1 : (new Date(Date.now()))  )}  onChange={this._End1Change.bind(this)} showSeconds={false} minutesIncrementStep={1}  showLabels={false} timeDisplayControlType={TimeDisplayControlType.Dropdown} minDate={new Date(Date.now())} key="End1"  dateConvention={DateConvention.DateTime}   timeConvention={TimeConvention.Hours24} />
          </div><br/>
          <div style={{display:((this.state.displayH2) ? 'grid' : 'none'), gridColumnGap: '20px', gridTemplateColumns: '1fr 1fr'}}>
            <DateTimePicker label="Date de début" formatDate={(date: Date) => date.toLocaleDateString()}  value={((this.state.Horaires != null && this.state.Horaires.startDate2 != null)? this.state.Horaires.startDate2 : (new Date(Date.now()))  )} onChange={this._Start2Change.bind(this)} showSeconds={false} minutesIncrementStep={1} showLabels={false} timeDisplayControlType={TimeDisplayControlType.Dropdown} minDate={new Date(Date.now())} key="Start1"  dateConvention={DateConvention.DateTime}   timeConvention={TimeConvention.Hours24} />
            <DateTimePicker label="Date de Fin" formatDate={(date: Date) => date.toLocaleDateString()}  value={((this.state.Horaires != null && this.state.Horaires.endDate2 != null)? this.state.Horaires.endDate2 : (new Date(Date.now()))  )}  onChange={this._End2Change.bind(this)} showSeconds={false} minutesIncrementStep={1}  showLabels={false} timeDisplayControlType={TimeDisplayControlType.Dropdown} minDate={new Date(Date.now())} key="End1"  dateConvention={DateConvention.DateTime}   timeConvention={TimeConvention.Hours24} />
          </div><br/>
         <div style={{display:((this.state.displayH3) ? 'grid' : 'none'), gridColumnGap: '20px', gridTemplateColumns: '1fr 1fr'}}>
            <DateTimePicker label="Date de début" formatDate={(date: Date) => date.toLocaleDateString()}  value={((this.state.Horaires != null && this.state.Horaires.startDate3 != null)? this.state.Horaires.startDate3 : (new Date(Date.now()))  )} onChange={this._Start3Change.bind(this)} showSeconds={false} minutesIncrementStep={1} showLabels={false} timeDisplayControlType={TimeDisplayControlType.Dropdown} minDate={new Date(Date.now())} key="Start1"  dateConvention={DateConvention.DateTime}   timeConvention={TimeConvention.Hours24} />
            <DateTimePicker label="Date de Fin" formatDate={(date: Date) => date.toLocaleDateString()}  value={((this.state.Horaires != null && this.state.Horaires.endDate3 != null)? this.state.Horaires.endDate3 : (new Date(Date.now()))  )}  onChange={this._End3Change.bind(this)} showSeconds={false} minutesIncrementStep={1}  showLabels={false} timeDisplayControlType={TimeDisplayControlType.Dropdown} minDate={new Date(Date.now())} key="End1"  dateConvention={DateConvention.DateTime}   timeConvention={TimeConvention.Hours24} />
          </div>
          <IconButton iconProps={AddRange} onClick={this._AddTimeRange.bind(this)}  />
          <IconButton iconProps={RemoveRange} onClick={this._RemoveTimeRange.bind(this)}  />
          </PivotItem>)}

          {!this.state.DisplaySummary && (
          <PivotItem headerText='PRESTATIONS'  itemIcon='EditListPencil'  itemKey='4'>
          <br/><br/>
          <table  cellPadding='0' cellSpacing='0' width='100%'>
            <tr>
              <td width="350" valign='top'>
                 <table  cellPadding='0' cellSpacing='0' width='100%'>
                     {this.state.prestations.map(m => 
                      <tr><td width="20px">
                        <FontIcon iconName='SkypeCircleCheck' className={styles.greenIcon} style={{display:((m.choix == 'Hide' || m.choix == 'OK' )? 'block' : 'none')}}/>
                        <FontIcon iconName='ErrorBadge12' className={styles.redIcon} style={{display:((m.choix == 'NO' )? 'block' : 'none')}} />
                        <FontIcon iconName='CirclePauseSolid' className={styles.orangeIcon}  style={{display:((m.choix == 'Idle' )? 'block' : 'none')}} />
                      </td>
                      <td><ActionButton onClick={() => {this._displayPrestaDetail(m.label)}} >{m.label}</ActionButton></td></tr>)}
                 </table>
              </td>
              <td  valign='top'>
              <div style={{display : ((this.state.SelectedPrestaPosition > -1) ? 'block' : 'none')}} >
                <strong>{this.state.SelectedPrestation.label}</strong><br/><br/>
                <ChoiceGroup options={PrestaChoiceOptions} defaultSelectedKey={this.state.SelectedPrestation.choix} onChange={this._PrestaOptionChange.bind(this)}  style={{display : ((this.state.SelectedPrestation.choix != 'Hide') ? 'block' : 'none')}}  /><br/><br/>
                <div style={{display : ((this.state.SelectedPrestation.choix == "OK" || this.state.SelectedPrestation.choix == "Hide") ? 'block' : 'none')}} >
                <div style={{display : ((this.state.SelectedPrestation.message.length > 0) ? 'block' : 'none')}} >
              
                <div style={{display : ((this.state.SelectedPrestation.messageType == "Warning") ? 'block' : 'none')}} >
                <MessageBar isMultiline messageBarType={MessageBarType.warning}>
                   {this.state.SelectedPrestation.message}
                </MessageBar>
                </div>
                <div style={{display : ((this.state.SelectedPrestation.messageType == "SeverityWarning") ? 'block' : 'none')}} >
                <MessageBar isMultiline messageBarType={MessageBarType.severeWarning} >
                    {this.state.SelectedPrestation.message}
                </MessageBar>
                </div>
                
                </div>

                <div style={{display : ((this.state.SelectedPrestation.precisions) ? 'block' : 'none')}} >
                  <br/>
                  <TextField multiline placeholder='Précisions' defaultValue={this.state.SelectedPrestation.precisions_value}  onChange={this._PrestationPrecisionChange.bind(this)} />
                </div>    

                <div style={{display : ((this.state.SelectedPrestation.displaydetails) ? 'block' : 'none')}} >
                      <ActionButton iconProps={AddPresta} onClick={() => {this._show()}}  >
                          Compléter
                     </ActionButton>

                     <Panel isOpen={this.state.showPanel} type={PanelType.custom}  customWidth="700px"  onDismiss={this._hideMenu.bind(this)}  headerText={this.state.SelectedPrestation.label} isLightDismiss={true}>
                     <br/><br/>
                     <table cellPadding='0' cellSpacing='0' width='100%'>
                      <tr>
                        <td width='50%' valign='top' style={{paddingRight:20}}>
                        <TextField onChange={this._PrestationcompanyChange.bind(this)}    label="Nom de la société" defaultValue={this.state.SelectedPrestation.company}  /> <br/>
                        <TextField onChange={this._PrestationreferentChange.bind(this)}    label = "Nom/Prénom référent" defaultValue={this.state.SelectedPrestation.referent}  /> <br/>
                        <TextField onChange={this._PrestationreferentTelChange.bind(this)}    label = "Tel" defaultValue={this.state.SelectedPrestation.referentTel}  /> <br/>
                        <TextField onChange={this._PrestationreferentMailChange.bind(this)}    label = "Email" defaultValue={this.state.SelectedPrestation.referentMail}  /> <br/>
                        </td>
                        <td  valign='top'  style={{paddingRight:20}}>
                        <TextField onChange={this._PrestationnumImmatriculationChange.bind(this)}   label= "Numéro d'immatriculation" defaultValue={this.state.SelectedPrestation.numImmatriculation}  /> <br/>
                        <ChoiceGroup options={accessParking} label="Accès parking" defaultSelectedKey={(this.state.SelectedPrestation.accessParking)? "Oui": "Non"} onChange={this._PrestaParkingChange.bind(this)} styles={{ flexContainer: { display: "flex" }}}  /><br/>
                        <ChoiceGroup options={accessQuaiLivraison} label="Accès quai de livraison"  defaultSelectedKey={(this.state.SelectedPrestation.accesQuaiLivraison)? "Oui": "Non"} onChange={this._PrestaQuaiChange.bind(this)} styles={{ flexContainer: { display: "flex" }}}  /><br/>
                        <TextField onChange={this._PrestationotherNeedChange.bind(this)}    label = "Besoins spécifiques..." defaultValue={this.state.SelectedPrestation.otherNeed} multiline  /> <br/>
                        </td>
                      </tr>
                      <tr  style={{display:((this.state.SelectedPrestation.Hotessedisplay) ? 'table-row' : 'none')}}>
                        <td  valign='top'  style={{paddingRight:20}}>
                        <TextField onChange={this._NBHotesseChange.bind(this)}    label= "Nombre d'hôtes et hôtesses souhaité" defaultValue={this.state.SelectedPrestation.HotesseNombre}  /> <br/>
                        <TextField onChange={this._ProfileHotesseChange.bind(this)}    label = "Profile Hôtesses (langues souhaitées)" defaultValue={this.state.SelectedPrestation.HotesseProfile} multiline  /> <br/>
                        </td>
                        <td  valign='top'  style={{paddingRight:20}}>
                        <ChoiceGroup options={vestiaires} label="Vestiaires" defaultSelectedKey={(this.state.SelectedPrestation.HotesseVestiaire)? "Oui": "Non"} onChange={this._PrestvestiaireChange.bind(this)} styles={{ flexContainer: { display: "flex" }}}  /><br/>
                        <TextField onChange={this._UniformeHotesseChange.bind(this)}    label = "Exigence uniforme" defaultValue={this.state.SelectedPrestation.HotesseUniforme} multiline  /> <br/>
                        </td>
                      </tr>
                      <tr  style={{display:((this.state.SelectedPrestation.PanneauAffichagedisplay) ? 'table-row' : 'none')}}>
                        <td  valign='top'  style={{paddingRight:20}}>
                        <ChoiceGroup options={Panneaux} label="Mise à disposition de panneaux d'affichage sur pied" defaultSelectedKey={(this.state.SelectedPrestation.PanneauxAffichage)? "Oui": "Non"} onChange={this._PanneauxAffichageChange.bind(this)} styles={{ flexContainer: { display: "flex" }}}  /><br/>
                        <TextField onChange={this._NBPanneauxChange.bind(this)}    label = "Nombre de panneaux" defaultValue={this.state.SelectedPrestation.PanneauxNombre} /> <br/>
                        </td><td></td>
                      </tr>
                      </table>
                      <DefaultButton onClick={this._hideMenu.bind(this)}>Fermer</DefaultButton>
                    </Panel>
 
                </div>    
                </div>
                </div>
              </td>
            </tr>
          </table>
           
          </PivotItem>)}

          {!this.state.DisplaySummary && (
          <PivotItem headerText='TELECHARGEMENTS'  itemIcon='DownloadDocument'  itemKey='5'>
            <br/><br/>
          <table>
            <tr>
              <td  valign='top'>
              <FilePicker 
                  context={this.props.context}  onSave=  {this._SelectFiles1.bind(this)}  buttonClassName={styles.button}
                  buttonLabel={"Plan prévisionnel de l'évènement"}  
                  hideStockImages= {true} hideOneDriveTab={true}  hideSiteFilesTab={true} hideLocalUploadTab={false}
                  hideLocalMultipleUploadTab={true} hideRecentTab={true}  hideLinkUploadTab={true} includePageLibraries={false}  />
               <div style={{ display: ((this.state.fileName1.length > 0) ? 'block' : 'none') }}><Label>{this.state.fileName1} </Label>  <ActionButton style={{float : 'right', top : '-30px'}} iconProps={Delete} onClick={() => {this.setState({fileName1 : ""})}}></ActionButton></div>
                <br/>
              <FilePicker 
                  context={this.props.context}  onSave=  {this._SelectFiles2.bind(this)}  buttonClassName={styles.button}
                  buttonLabel={"Plan d'implementation"}  
                  hideStockImages= {true} hideOneDriveTab={true}  hideSiteFilesTab={true} hideLocalUploadTab={false}
                  hideLocalMultipleUploadTab={true} hideRecentTab={true}  hideLinkUploadTab={true} includePageLibraries={false}  />
              <div style={{ display: ((this.state.fileName2.length > 0) ? 'block' : 'none') }}><Label>{this.state.fileName2} </Label> <ActionButton style={{float : 'right', top : '-30px'}} iconProps={Delete} onClick={() => {this.setState({fileName2 : ""})}}></ActionButton></div>
              <br/>
              <FilePicker 
                  context={this.props.context}  onSave=  {this._SelectFiles3.bind(this)}  buttonClassName={styles.button}
                  buttonLabel={"Liste des invités et/ou des prestaires extérieurs"}  
                  hideStockImages= {true} hideOneDriveTab={true}  hideSiteFilesTab={true} hideLocalUploadTab={false}
                  hideLocalMultipleUploadTab={true} hideRecentTab={true}  hideLinkUploadTab={true} includePageLibraries={false}  />
              <div style={{ display: ((this.state.fileName3.length > 0) ? 'block' : 'none') }}><Label>{this.state.fileName3} </Label> <ActionButton style={{float : 'right', top : '-30px'}} iconProps={Delete} onClick={() => {this.setState({fileName3 : ""})}}></ActionButton></div>
              <br/>
              <FilePicker 
                  context={this.props.context}  onSave=  {this._SelectFiles4.bind(this)}  buttonClassName={styles.button}
                  buttonLabel={"PV de réaction au feu des matériaux utilisés"}  
                  hideStockImages= {true} hideOneDriveTab={true}  hideSiteFilesTab={true} hideLocalUploadTab={false}
                  hideLocalMultipleUploadTab={true} hideRecentTab={true}  hideLinkUploadTab={true} includePageLibraries={false}  />
              <div style={{ display: ((this.state.fileName4.length > 0) ? 'block' : 'none') }}><Label>{this.state.fileName4} </Label> <ActionButton style={{float : 'right', top : '-30px'}} iconProps={Delete} onClick={() => {this.setState({fileName4 : ""})}}></ActionButton></div>
              <br/>
              <FilePicker 
                  context={this.props.context}  onSave=  {this._SelectFiles5.bind(this)}  buttonClassName={styles.button}
                  buttonLabel={"Liste des intervenants externes"}  
                  hideStockImages= {true} hideOneDriveTab={true}  hideSiteFilesTab={true} hideLocalUploadTab={false}
                  hideLocalMultipleUploadTab={true} hideRecentTab={true}  hideLinkUploadTab={true} includePageLibraries={false}  />
              <div style={{ display: ((this.state.fileName5.length > 0) ? 'block' : 'none') }}><Label>{this.state.fileName5} </Label> <ActionButton style={{float : 'right', top : '-30px'}} iconProps={Delete} onClick={() => {this.setState({fileName5 : ""})}}></ActionButton></div>
              <br/>
              <FilePicker 
                  context={this.props.context}  onSave=  {this._SelectFiles6.bind(this)}  buttonClassName={styles.button}
                  buttonLabel={"Autres fichier"}  
                  hideStockImages= {true} hideOneDriveTab={true}  hideSiteFilesTab={true} hideLocalUploadTab={false}
                  hideLocalMultipleUploadTab={true} hideRecentTab={true}  hideLinkUploadTab={true} includePageLibraries={false}  />
              <div style={{ display: ((this.state.fileName6.length > 0) ? 'block' : 'none') }}><Label>{this.state.fileName6} </Label> <ActionButton style={{float : 'right', top : '-30px'}} iconProps={Delete} onClick={() => {this.setState({fileName6 : ""})}}></ActionButton></div>
              </td>
              <td width='60%' valign='top'>
              <MessageBar messageBarType={MessageBarType.warning} isMultiline>
                  L'implémentation du mobilier et des équipements doivent être indiqués par l'organisateur sur le(s) plan(s) transmis en précisant:<br/>
                  + Le nombre et type d'équipements utilisés et puissance électriques souhaitées<br/>
                  + Les matérieux utilisés<br/><br/>
                  Les fiches techniques, les procès verbaux de réaction au feu des matériaux et autres attestations de conformité doivent être fournis.<br/><br/>
                  Le plan transmis indiquant les emplacements des équipements devra être à l'échelle.<br/><br/>
                  Des badges d'accès seront remis par le PC Sécurité aux intervenants faisant partie de l'organisation en échange d'un justificatif d'identité.<br/><br/>
                  Interdiction d'installation d'éléments de cuisson et de réchauffe dans les espaces dédiés aux évènements.<br/><br/>
                  Respecter les zones pouvant êtres utilisées et laisser libres les couloirs d'évacuation ainsi que les issues de secours.<br/><br/>
                  Maintenir la visiblités des plans et balisages d'évacuations.<br/><br/>
                  Maintenir l'accèssibilité des extincteurs.<br/><br/>
                  Maintenir l'accèssibilité des Défibrilateurs Automatisés Externes.<br/><br/>
                  Gaffer les divers câbles au sol.<br/><br/>
                  Respecter les puissances éléctriques fournies.<br/><br/>
                  Les équipes sécurité se réservent le droit de modifier l'emplacement des divers mobiliers en cas de risque(s) pour les personnes et les biens.
              </MessageBar>
              </td>
            </tr>
          </table>
          </PivotItem>)}

          <PivotItem headerText={(this.state.DisplaySummary) ? this.state.Status: 'RÉSUMÉ'  }  itemIcon='ReceiptCheck'  itemKey='6'>
            <br/><br/>
            <table  cellPadding='0' cellSpacing='0' width='100%'>
              <tr>
                <td width='500' valign='top'>
                  <div style={{border:"1px solid #2cc185", padding:15, width: 500, marginBottom:'20px',marginRight:'20px'}}>
                     <span style={{backgroundColor:'#2cc185',padding:5,color:'white'}}>EVENEMENT</span><br/><br/>
                     <table  cellPadding='0' cellSpacing='0' width='100%'>
                        <tr> <td className={styles.tdleft}>Evènement</td><td>{this.state.title}</td></tr>
                        <tr><td className={styles.tdleft}>Type</td><td>{this.state.type}</td></tr>
                        <tr> <td className={styles.tdleft}>Condition d'entrée</td><td>{this.state.condition_entree}</td></tr>
                        <tr> <td className={styles.tdleft} valign='top'>Présentation</td><td>{this.state.Description}</td></tr>
                        <tr> <td className={styles.tdleft}>Responsable</td><td>{this.state.responsable[0]}</td></tr>
                        <tr><td className={styles.tdleft}>Organisateur</td><td>{this.state.organizer[0]}</td></tr>
                         <tr><td className={styles.tdleft}>Entité Organisateur</td><td>{this.state.organizer_entity}</td></tr>
                        <tr><td className={styles.tdleft}>Tel Organisateur</td><td>{this.state.organizer_tel}</td></tr>
                        <tr><td colSpan={2}><br/></td></tr>
                        <tr><td colSpan={2}> <span style={{color:'#2cc185'}}>Informations de facturation</span><br/></td></tr>
                        <tr><td className={styles.tdleft}>Entité organisatrice</td><td>{this.state.billing_entity}</td></tr>
                        <tr><td className={styles.tdleft}>Métier</td><td>{this.state.billing_business}</td></tr>
                        <tr><td className={styles.tdleft}>Adresse de facturation</td><td>{this.state.billing_address}</td></tr>
                        <tr><td className={styles.tdleft}>Contact de facturation</td><td>{this.state.billing_contact}</td></tr>
                        <tr><td className={styles.tdleft}>Numéro SIRET</td><td>{this.state.billing_siret}</td></tr>
                        <tr><td className={styles.tdleft}>Centre de coût</td><td>{this.state.billing_costCenter}</td></tr>
                     </table>
                  </div>
                  <div style={{border:"1px solid #2cc185", padding:15, width: 500, marginBottom:'20px',marginRight:'20px'}}>
                     <span style={{backgroundColor:'#2cc185',padding:5,color:'white'}}>PRESTATIONS CHOISIES</span><br/><br/>
                     <div><strong>Prestations obligatoires</strong> : Sécurité | Prestation de mise en propreté</div>
                     <div><strong>Autres Prestations</strong></div>
                     {this.state.prestations.map(m => 
                     <div style={{display : (m.choix =="OK" )? 'inline':'none'}}>
                     <MessageBar messageBarType={MessageBarType.info} isMultiline>{m.label}</MessageBar>
                     <div style={{display : (m.precisions_value !="" )? 'inline':'none'}}> {m.precisions_value}<br/></div>
                     <table  cellPadding='0' cellSpacing='0' width='100%'>
                        <tr style={{display : (m.company !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Société</td><td>{m.company}</td></tr>
                        <tr style={{display : (m.referent !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Référent</td><td>{m.referent} ({m.referentMail}/{m.referentTel})</td></tr>
                        <tr style={{display : (m.numImmatriculation !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Accès parking</td><td>{(m.accessParking)?"Oui":"Non"}</td></tr>
                        <tr style={{display : (m.numImmatriculation !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Quai de livraison</td><td>{(m.accesQuaiLivraison)?"Oui":"Non"}</td></tr>
                        <tr style={{display : (m.numImmatriculation !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Immatriculation</td><td>{m.numImmatriculation}</td></tr>
                        <tr style={{display : (m.otherNeed !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Autre besoins ?</td><td>{m.otherNeed}</td></tr>

                        <tr style={{display : (m.HotesseNombre !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Nombre d'hotesses</td><td>{m.HotesseNombre}</td></tr>
                        <tr style={{display : (m.HotesseProfile !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Profile des Hotesses</td><td>{m.HotesseProfile}</td></tr>
                        <tr style={{display : (m.HotesseUniforme !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Exigence uniforme</td><td>{m.HotesseUniforme}</td></tr>
                        <tr style={{display : (m.HotesseNombre !="" )? 'table-row':'none'}}><td className={styles.tdleft}>Vestiaire</td><td>{(m.HotesseVestiaire)?"Oui":"Non"}</td></tr>

                     </table>
                     <br/>
                     </div>
                     )}
                  </div>
                </td>
                <td  valign='top'>
                <div style={{border:"1px solid #2cc185", padding:15,  width: 300, marginBottom:'20px'}}>
                <span style={{backgroundColor:'#2cc185',padding:5,color:'white'}}>LIEU & PLANNING SOUHAITÉS</span><br/><br/>
                <table  cellPadding='0' cellSpacing='0' width='100%'>
                <tr> <td className={styles.tdleft}>Immeuble</td><td>{this.state.SelectedImmeuble} ({this.state.SelectedVille}) </td></tr>
                <tr> <td  valign='top' className={styles.tdleft}>Adresse</td><td>{this.state.selectedAdress}</td></tr>
                <tr><td  valign='top' className={styles.tdleft}>Espace(s)</td><td>{this.state.selected_espace.map(m => <div>{m.espace} ({m.capacite})</div>)}</td></tr>
                <tr> <td  valign='top' className={styles.tdleft}>Planning</td><td> {this.state.HoraireString.split('|').map(m => <div>{m}</div>)} </td></tr>
                </table>
              </div>
              <div style={{ border:"1px solid #2cc185", padding:15, width: 300, marginBottom:'20px'}}>
                <span style={{backgroundColor:'#2cc185',padding:5,color:'white'}}>PARTICIPANTS ({this.state.nb_totalParticipants})</span><br/><br/>
                <table  cellPadding='0' cellSpacing='0' width='100%'>
                <tr style={{display:((this.state.nb_collab_bnpp > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Collaborateurs BNP Paribas du site</td><td>{this.state.nb_collab_bnpp} </td></tr>
                <tr style={{display:((this.state.nb_collab_bnpp_extern > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Collaborateurs BNP Paribas extérieurs au site</td><td>{this.state.nb_collab_bnpp_extern} </td></tr>
                <tr style={{display:((this.state.nb_vip_extern_site > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Invités VIP BNP Paribas extérieurs au site</td><td>{this.state.nb_vip_extern_site} </td></tr>
                <tr style={{display:((this.state.nb_non_collab_bnpp > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Invités extrieurs au groupe BNP Paribas</td><td>{this.state.nb_non_collab_bnpp} </td></tr>
                <tr style={{display:((this.state.nb_vip_extern_bnpp > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Invités VIP extérieurs à BNP Paribas</td><td>{this.state.nb_vip_extern_bnpp} </td></tr>
                <tr style={{display:((this.state.nb_mineurs > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Mineurs</td><td>{this.state.nb_mineurs} </td></tr>
                <tr style={{display:((this.state.nb_psh > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>PSH (Personne en Situation d'Handicap)</td><td>{this.state.nb_psh} </td></tr>
                <tr style={{display:((this.state.nb_presta > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Participants du prestataire extérieur</td><td>{this.state.nb_presta} </td></tr>
                
                </table>
              </div>
              <div style={{display :((this.state.fileName1.length == 0 && this.state.fileName2.length == 0 && this.state.fileName3.length == 0 && this.state.fileName4.length == 0 && this.state.fileName5.length == 0 && this.state.fileName6.length == 0) ? 'none' : 'block'),border:"1px solid #2cc185", padding:15,  width: 300, marginBottom:'20px'}}>
                <span style={{backgroundColor:'#2cc185',padding:5,color:'white'}}>PIECES JOINTES</span><br/><br/>
                <table  cellPadding='0' cellSpacing='0' width='100%' style={{display : (this.state.DisplaySummary)? 'none':'block'}}>
                <tr style={{display:((this.state.fileName1.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Plan prévisionnel</td><td>{this.state.fileName1} </td></tr>
                <tr style={{display:((this.state.fileName2.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Plan d'implémentation</td><td>{this.state.fileName2} </td></tr>
                <tr style={{display:((this.state.fileName3.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Liste des invités</td><td>{this.state.fileName3} </td></tr>
                <tr style={{display:((this.state.fileName4.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>PV réaction au feu</td><td>{this.state.fileName4} </td></tr>
                <tr style={{display:((this.state.fileName5.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Liste intervenants externes</td><td>{this.state.fileName5} </td></tr>
                <tr style={{display:((this.state.fileName6.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Autres</td><td>{this.state.fileName6} </td></tr>
                </table>

                <table  cellPadding='0' cellSpacing='0' width='100%' style={{display : (this.state.DisplaySummary)? 'block':'none'}}>
                <tr style={{display:((this.state.fileName1.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Plan prévisionnel</td><td><Link target='_blank ' href={this.state.file1Url}>{this.state.fileName1}</Link> </td></tr>
                <tr style={{display:((this.state.fileName2.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Plan d'implémentation</td><td><Link target='_blank ' href={this.state.file2Url}>{this.state.fileName2}</Link> </td></tr>
                <tr style={{display:((this.state.fileName3.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Liste des invités</td><td><Link target='_blank ' href={this.state.file3Url}>{this.state.fileName3}</Link> </td></tr>
                <tr style={{display:((this.state.fileName4.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>PV réaction au feu</td><td><Link target='_blank ' href={this.state.file4Url}>{this.state.fileName4}</Link> </td></tr>
                <tr style={{display:((this.state.fileName5.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Liste intervenants externes</td><td><Link target='_blank ' href={this.state.file5Url}>{this.state.fileName5}</Link> </td></tr>
                <tr style={{display:((this.state.fileName6.length > 0) ? 'table-row' : 'none')}}> <td className={styles.tdleft2}>Autres</td><td><Link target='_blank ' href={this.state.file6Url}>{this.state.fileName6}</Link> </td></tr>
                </table>
              </div>
               </td>
              </tr>
            </table>

          </PivotItem>
        </Pivot>
        <div className={styles.Next} >
          <div style={{ display: ((this.state.DisplaySummary ) ? 'none' : 'block')}}>
          <DefaultButton text='Précédent' onClick={this.Precedent.bind(this)} iconProps={PrevIcon} style={{marginRight:20, float:'left', display: ((this.state.EventCreated) ? 'none' : 'block')}}/>
          <DefaultButton text='Suivant' onClick={this.Suivant.bind(this)} iconProps={NextIcon} style={{display: ((this.state.hideNext) ? 'none' : 'block')}}/>
          <div className={styles.errorMessage} style={{ display: ((this.state.display_required ) ? 'block' : 'none')}}>
               Merci de renseigner les champs obligatoires.
          </div>

          <DefaultButton text='ENREGISTRER' onClick={this.Save.bind(this)} iconProps={SaveIcon} style={{display: ((this.state.showSave) ? 'block' : 'none'), position:'relative',float:'right'}} />
          <div  style={{ display: ((this.state.Loading) ? 'block' : 'none'), position:'relative',float:'right' }}>
            <Spinner label="Enregistrement de votre demande en cours.." />
          </div>
          <br/><br/><br/>
          <div style={{display:((this.state.EventCreated) ? 'block' : 'none')}}>
              <MessageBar messageBarType={MessageBarType.success} >Votre demande d'événement a été transmise à l'Event Officer</MessageBar>
          </div>
        </div>
        <div style={{ display: ((this.state.DisplaySummary && this.state.IamEventOfficer) ? 'block' : 'none')}}>
        <DefaultButton text='Approuver' onClick={this.toggleHideDialog2.bind(this)} iconProps={ApprouverIcon} style={{marginRight:20, float:'left'}}/>
        <DefaultButton text='Rejeter' onClick={this.toggleHideDialog3.bind(this)} iconProps={RejectIcon} />

        <Dialog hidden={!this.state.ShowDialog2} modalProps={modelProps} onDismiss={this.toggleHideDialog2.bind(this)} minWidth={400}>
                  Merci de confirmer <strong>l'approbation</strong> de la demande.
                  <br/><br/>
            <DialogFooter>
                <PrimaryButton onClick={this.Approve.bind(this)}  text="Confirmer" />
                <DefaultButton onClick={this.toggleHideDialog2.bind(this)}  text="Annuler" />
            </DialogFooter>
        </Dialog>

        <Dialog hidden={!this.state.ShowDialog3} modalProps={modelProps} onDismiss={this.toggleHideDialog3.bind(this)} minWidth={400}>
                  Merci de confirmer le <strong>rejet</strong> de la demande.
                  <br/><br/>
            <DialogFooter>
                <PrimaryButton onClick={this.Reject.bind(this)}  text="Confirmer" />
                <DefaultButton onClick={this.toggleHideDialog3.bind(this)}  text="Annuler" />
            </DialogFooter>
        </Dialog>



        <div  style={{display: ((this.state.showSave) ? 'block' : 'none'), position:'relative',float:'right'}} ></div>
        </div>
        <div style={{ display: ((this.state.DisplaySummary && !this.state.IamEventOfficer) ? 'block' : 'none')}}>
        <DefaultButton text='Annuler la demande' onClick={this.toggleHideDialog4.bind(this)} iconProps={CancelIcon} style={{marginRight:20, float:'left'}}/>

        <Dialog hidden={!this.state.ShowDialog4} modalProps={modelProps} onDismiss={this.toggleHideDialog4.bind(this)} minWidth={400}>
                  Merci de confirmer <strong>L'annulation</strong> de la demande de réservation.
                  <br/><br/>
            <DialogFooter>
                <PrimaryButton onClick={this.Annuler.bind(this)}  text="Confirmer" />
                <DefaultButton onClick={this.toggleHideDialog4.bind(this)}  text="Annuler" />
            </DialogFooter>
        </Dialog>



        <div  style={{display: ((this.state.showSave) ? 'block' : 'none'), position:'relative',float:'right'}} ></div>
        </div>
        </div>
      </div>
      </div>
      </div>
    );
  }
}

