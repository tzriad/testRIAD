declare interface IManageMyEventWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ManageMyEventWebPartStrings' {
  const strings: IManageMyEventWebPartStrings;
  export = strings;
}
