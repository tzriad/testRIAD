import { WebPartContext } from '@microsoft/sp-webpart-base';  
export interface IManageMyEventProps {
  description: string;
  context: WebPartContext; 
}

export interface EventHoraires {
  startDate1 : Date;
  startDate1_TolocalDate :string;
  startDate1_TolocalTime :string;
  endDate1 : Date;
  endDate1_TolocalDate :string;
  endDate1_TolocalTime :string;
  startDate2 : Date;
  startDate2_TolocalDate :string;
  startDate2_TolocalTime :string;
  endDate2 : Date;
  endDate2_TolocalDate :string;
  endDate2_TolocalTime :string;
  startDate3 : Date;
  startDate3_TolocalDate :string;
  startDate3_TolocalTime :string;
  endDate3:Date;
  endDate3_TolocalDate :string;
  endDate3_TolocalTime :string;
  };

  export interface Espace {
    ville : string;
    immeuble: string;
    capacite: number;
    Desc : string;
    espace : string;
    defaultChecked:boolean;
    address : string;
    };

export interface Prestations{
    label : string;
    choix : string;  // Oui, Non, Je ne sais pas encore, Hide
    message : string;
    messageType : string;  // warning, severewarning
    precisions : boolean;
    precisions_value : string;
    displaydetails : boolean;
    company : string;
    referent : string;
    referentTel : string;
    referentMail: string;
    date : Date;
    numImmatriculation: string;
    accessParking: boolean;
    accesQuaiLivraison : boolean;
    otherNeed: string;
    PanneauAffichagedisplay : boolean;
    PanneauxAffichage : boolean;
    PanneauxNombre : string;
    Hotessedisplay: boolean;
    HotesseNombre :string;
    HotesseProfile : string;
    HotesseVestiaire : boolean;
    HotesseUniforme:string;
};